using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using Genworth_TIMES.Properties;
using Objetos;

namespace Genworth_TIMES
{
    public partial class Boton : UserControl
    {
        /// <summary>
        /// Types of buttons that can be set
        /// </summary>
        public enum Tips
        {
            Break,
            Lunch,
            Training,
            Feedback,
            Meeting,
            Aditional,
            Support,
            NonBusiness,
            AnalisisInfona,
            AnalisisING,
            Pagos,
            SubCases,
            Laserfiche,
            LaserficheComplementario,
            Otros,
            Impresion,
            Llamada,
            EnEspera,
            PhoneOut,
            DHL,
            CapturaPago,
            Reclamacion_Subsecuente,
            Seguimiento,
            PhoneIn,
            AnalisisBanamex,
            AnalisisSantander,
            RegistroSistemaCliente,
            AtencionAreaLegal,
            AtencionAreaSiniestros,
            AtencionAsegurados,
            GenworthOperaciones,
            GenworthSegurosVida,
            GenworthSegurosDa�os,
            GenworthColombia,
            Nueva_Reclamacion,
            Continuing_Claim,
            Corres,
            Pending_Claims,
            Postal_Service,
            Follow_Up,
            Additional_duties,
            Complaints
        }

        private ToolTip m_tt;
        private string m_ToolTip = "";
        public string p_ToolTip
        {
            get { return m_ToolTip; }
            set
            {
                m_ToolTip = value;
                if (m_tt == null)
                {                   
                    m_tt.InitialDelay = 0;
                }
                m_tt.SetToolTip(this, value);
            }
        }

        private Tips m_Tip;
        /// <summary>
        /// Text shown on mouse over the button
        /// </summary>
        public Tips p_Tip
        {
            get { return m_Tip; }
            set { m_Tip = value; }
        }

        
        private String m_Texto = string.Empty;
        /// <summary>
        /// text to be shown on screen
        /// </summary>
        public String p_Texto
        {
            get { return m_Texto; }
        }

        
        private Tipos m_Tipo = null;
        /// <summary>
        /// type of button
        /// </summary>
        public Tipos p_Tipos
        {
            get { return m_Tipo; }
            set { m_Tipo = value; }
        }

        private Acciones m_Accion = null;
        /// <summary>
        /// action accordling to the type of button
        /// </summary>
        public Acciones p_Accion
        {
            get { return m_Accion; }
            set { m_Accion = value; }
        }

        private bool m_Descripcion = false;
        /// <summary>
        /// button description (optional)
        /// </summary>
        public bool p_Descripcion
        {
            get { return m_Descripcion; }
            set { m_Descripcion = value; }
        }

        private int m_MaxTimeElapsed = 0;
        /// <summary>
        /// Maximum time to be elapsed in the current button action
        /// </summary>
        public int p_MaxTimeElapsed
        {
            get { return m_MaxTimeElapsed; }
            set { this.m_MaxTimeElapsed = value; }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="Tip">Set type of button</param>
        public Boton(Boton.Tips Tip)
        {
            this.p_Tip = Tip;
            //Boton();
            this.SetStyle(
                System.Windows.Forms.ControlStyles.UserPaint |
                System.Windows.Forms.ControlStyles.AllPaintingInWmPaint |
                System.Windows.Forms.ControlStyles.OptimizedDoubleBuffer,
                true);

            InitializeComponent();
            m_tt = new ToolTip();
        }

        /// <summary>Main constructor</summary>
        public Boton()
        {
            this.SetStyle(
                System.Windows.Forms.ControlStyles.UserPaint |
                System.Windows.Forms.ControlStyles.AllPaintingInWmPaint |
                System.Windows.Forms.ControlStyles.OptimizedDoubleBuffer,
                true);

            InitializeComponent();
            m_tt = new ToolTip();
        }

        /// <summary>
        /// Override general parameters
        /// </summary>
        protected override CreateParams CreateParams
        {
            get
            {
                var parms = base.CreateParams;
                parms.Style &= ~0x02000000;  // Turn off WS_CLIPCHILDREN
                return parms;
            }
        }

        /// <summary>
        /// Will create the layout of the button and paint it on screen each time is needed
        /// </summary>
        /// <param name="e">General not used</param>
        protected override void OnPaint(PaintEventArgs e)
        {
            SizeF size;
            int x = (this.Width / 2) / 2;

            RectangleF pI = new RectangleF(0, this.Height / 2, this.Width - 1, (this.Height / 2) - 1);

            StringFormat sf = new StringFormat();
            sf.Alignment = StringAlignment.Center;

            //e.Graphics.DrawRectangle(new Pen(Brushes.Red), pI.X, pI.Y, pI.Width, pI.Height);
            e.Graphics.DrawImage(_Imagen, x, 0, this.Width / 2, this.Width / 2);
            /*e.Graphics.DrawImage(_Imagen,
                                    new Rectangle(Point.Empty, _Imagen.Size),
                                    new Rectangle(Point.Empty, _Imagen.Size),
                                    GraphicsUnit.Pixel);*/

            Font f = new Font("Arial", 13, FontStyle.Regular);
            Font f2 = AppropriateFont(e.Graphics, 8, 13, pI.Size, m_Texto, f, out size);

            e.Graphics.DrawString(m_Texto, f2, Brushes.Black, pI, sf);

            f.Dispose();
            f2.Dispose();
            sf.Dispose();
            base.OnPaint(e);
        }

        /// <summary>
        /// Calculate the size of the font accordling to the button size
        /// </summary>
        /// <param name="g">Grapgic to be painted</param>
        /// <param name="minFontSize">Minimum font size in px</param>
        /// <param name="maxFontSize">maximum font size in px</param>
        /// <param name="layoutSize">Button layout size in px</param>
        /// <param name="s">Text to be displayed</param>
        /// <param name="f">Font face</param>
        /// <param name="extent">Return the Size of the button</param>
        /// <returns>Outputs the final calculated font size</returns>
        private Font AppropriateFont(Graphics g, float minFontSize,
            float maxFontSize, SizeF layoutSize, string s, Font f, out SizeF extent)
        {
            if (maxFontSize == minFontSize)
                f = new Font(f.FontFamily, minFontSize, f.Style);

            extent = g.MeasureString(s, f);

            if (maxFontSize <= minFontSize)
                return f;

            float hRatio = layoutSize.Height / extent.Height;
            float wRatio = layoutSize.Width / extent.Width;
            float ratio = (hRatio < wRatio) ? hRatio : wRatio;

            float newSize = f.Size * ratio;

            if (newSize < minFontSize)
                newSize = minFontSize;
            else if (newSize > maxFontSize)
                newSize = maxFontSize;

            f = new Font(f.FontFamily, newSize, f.Style);
            extent = g.MeasureString(s, f);

            return f;
        }

        /// <summary>
        /// Return the current Image from the resources file
        /// </summary>
        private Image _Imagen
        {
            get
            {
                Image img = null;
                switch (m_Tip)
                {
                    case Tips.Nueva_Reclamacion:
                        img = Resources._1259098306_Notepad;
                        m_Texto = "New Claim(CFIN)";
                        break;
                    case Tips.Continuing_Claim:
                        img = Resources._1259098306_Notepad;
                        m_Texto = "Continuing claim(CCIN)";
                        break;
                    case Tips.Pending_Claims:
                        img = Resources._1331763069_Hourglass;
                        m_Texto = "Pending Claims";
                        break;
                    case Tips.Corres:
                        img = Resources._1259103470_Mail;
                        m_Texto = "Corres";
                        break;
                    case Tips.Break:
                        img = Resources._1259092138_kteatime;
                        m_MaxTimeElapsed = 30;
                        m_Texto = "Break";
                        break;
                    case Tips.Lunch:
                        img = Resources._1259097371_Space_Food;
                        m_MaxTimeElapsed = 30;
                        m_Texto = "Lunch";
                        break;
                    case Tips.Training:
                        img = Resources._1259097551_ordinateur_off;
                        m_Texto = "Training";
                        break;
                    case Tips.Feedback:
                        img = Resources._1259097743_chat;
                        m_Texto = "Feedback";
                        break;
                    case Tips.Llamada:
                        img = Resources._1259097824_gnomemeeting;
                        m_Texto = "Llamada";
                        break;
                    case Tips.PhoneIn:
                        img = Resources._1259097824_gnomemeeting;
                        m_Texto = "Phone In";
                        break;
                    case Tips.Meeting:
                        img = Resources._1259258696_BeOS_people;
                        m_Texto = "Meeting";
                        break;
                    case Tips.Additional_duties:
                        img = Resources._1259097884_add1;
                        m_Texto = "Additional duties";
                        break;
                    case Tips.Aditional:
                        img = Resources._1259097884_add1;
                        m_Texto = "Additional Actions";
                        break;
                    case Tips.Support:
                        img = Resources._1259097992_Help_and_Support;
                        m_Texto = "Support";
                        break;
                    case Tips.NonBusiness:
                        img = Resources._1259098180_Clock4;
                        m_Texto = "Non Business";
                        break;
                    case Tips.AnalisisInfona:
                        m_MaxTimeElapsed = 14;
                        img = Resources._1259098306_Notepad;
                        m_Texto = "Nueva reclamaci�n INFONAVIT";
                        break;
                    case Tips.AnalisisING:
                        m_MaxTimeElapsed = 16;
                        img = Resources._1259098306_Notepad;
                        m_Texto = "Nueva reclamaci�n ING";
                        break;
                    case Tips.Pagos:
                        m_MaxTimeElapsed = 4;
                        img = Resources._1259099760_cash_register;
                        m_Texto = "Captura de pagos";
                        break;
                    case Tips.SubCases:
                        img = Resources._1259099981_Portfolio;
                        m_Texto = "SubCase";
                        break;
                    case Tips.Laserfiche:
                        img = Resources.LF__R;
                        m_Texto = "Laserfiche Nuevo";
                        break;
                    case Tips.LaserficheComplementario:
                        img = Resources.LF__R;
                        m_Texto = "Laserfiche Complemento";
                        break;
                    case Tips.Otros:
                        img = Resources._1259103435_folder_important;
                        m_Texto = "Otros";
                        break;
                    case Tips.Impresion:
                        img = Resources._1259103470_Mail;
                        m_Texto = "Impresi�n - Envio de cartas.";
                        break;
                    case Tips.EnEspera:
                        img = Resources._1259261468_waiting;
                        m_Texto = "En Espera";
                        break;
                    case Tips.Postal_Service:
                        img = Resources._1259679707_package;
                        m_Texto = "Postal Service";
                        break;
                    case Tips.DHL:
                        img = Resources._1259679707_package;
                        m_Texto = "DHL";
                        break;
                    case Tips.PhoneOut:
                        img = Resources._1259679639_contact;
                        m_Texto = "Phone Out";
                        break;
                    case Tips.CapturaPago:
                        img = Resources._1259695423_cash_register;
                        m_Texto = "Captura de Pagos";
                        break;
                    case Tips.Reclamacion_Subsecuente:
                        m_MaxTimeElapsed = 4;
                        img = Resources._1261075129_Refresh;
                        m_Texto = "Reclamaci�n Subsecuente";
                        break;
                    case Tips.Follow_Up:
                        img = Resources._1261074881_Refresh;
                        m_Texto = "Follow Up";
                        break;
                    case Tips.Seguimiento:
                        img = Resources._1261074881_Refresh;
                        m_Texto = "Seguimiento";
                        break;
                    case Tips.AnalisisBanamex:
                        img = Resources._1259098306_Notepad;
                        m_Texto = "Nueva reclamaci�n Banamex";
                        break;
                    case Tips.AnalisisSantander:
                        img = Resources._1259098306_Notepad;
                        m_Texto = "Nueva reclamaci�n Santander";
                        break;
                    case Tips.RegistroSistemaCliente:
                        img = Resources._1264703080_system_software_update;
                        m_Texto = "Registro en sistema del Cliente";
                        break;
                    case Tips.AtencionAreaLegal:
                        img = Resources._1264703672_folder_user_female;
                        m_Texto = "Atenci�n �rea legal";
                        break;
                    case Tips.AtencionAreaSiniestros:
                        img = Resources._1264703586_Book3;
                        m_Texto = "Atenci�n �rea siniestros";
                        break;
                    case Tips.AtencionAsegurados:
                        img = Resources._1264703376_edu_languages;
                        m_Texto = "Atenci�n a asegurados";
                        break;
                    case Tips.GenworthColombia:
                        img = Resources.Logo_GNW;
                        m_Texto = "Genworth Colombia";
                        break;
                    case Tips.GenworthOperaciones:
                        img = Resources.Logo_GNW;
                        m_Texto = "Genworth Operaciones";
                        break;
                    case Tips.GenworthSegurosDa�os:
                        img = Resources.Logo_GNW;
                        m_Texto = "Genworth Seguros Da�os";
                        break;
                    case Tips.GenworthSegurosVida:
                        img = Resources.Logo_GNW;
                        m_Texto = "Genworth Seguros Vida";
                        break;
                    case Tips.Complaints:
                        img = Resources._1259103435_folder_important;
                        m_Texto = "Complaints";
                        break;
                    default:
                        throw new NotImplementedException();
                }
                return img;
            }
        }

        /// <summary>
        /// 3D effect on mouse enter
        /// </summary>
        /// <param name="sender">New Object()</param>
        /// <param name="e">EventArgs.Empty</param>
        private void Boton_MouseEnter(object sender, EventArgs e)
        {
            this.BorderStyle = BorderStyle.Fixed3D;
        }

        /// <summary>
        /// 3D effect on mouse leave
        /// </summary>
        /// <param name="sender">New Object()</param>
        /// <param name="e">EventArgs.Empty</param>
        private void Boton_MouseLeave(object sender, EventArgs e)
        {
            this.BorderStyle = BorderStyle.None;
        }

        /// <summary>
        /// Initiate control
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Boton_Load(object sender, EventArgs e)
        {
            this.Invalidate();
        }
    }
}
