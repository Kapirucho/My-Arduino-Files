﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text; 
using System.Windows.Forms;
using Objetos;
using Genworth_TIMES.DataBase.TimeDataTableAdapters;

namespace Genworth_TIMES.Controles
{
    public partial class GSUsuario : UserControl
    {
        private int m_UsuarioId = int.MinValue;
        public int UsuarioId
        {
            get { return m_UsuarioId; }
            set { m_UsuarioId = value; }
        }

        private int m_DiasLaborados = int.MinValue;
        private double m_Month;
        private double m_Year;
        private int m_NumeroReclamaciones = 0;
        private int m_NumeroCCIN = 0;
        private int m_NumeroLlamadas = 0;
        private int m_Correspondencia = 0;
        private int m_Asignaciones = 0;
        private double m_Total = 0;
        private double m_CalidadClaims = 0;
        private double m_CalidadCalls = 0;

        private Usuario usr = new Usuario();


        public GSUsuario(int UsuarioId, double Month, double Year)
        {
            InitializeComponent();
            m_UsuarioId = UsuarioId;
            m_Month = Month;
            m_Year = Year;
            this.GatherUserInfo();
            this.Invalidate();
        }

        private void GatherUserInfo()
        {
            DateTime timeConsulta = new DateTime(int.Parse(m_Year.ToString()), int.Parse(m_Month.ToString()), 1);

            DataTable dtUsuario = new TIME_USUARIOSTableAdapter().GetDataById(m_UsuarioId);

            if (dtUsuario.Rows.Count != 1)
            {
                throw new Exception("No se encontro el usuario, intente de nuevo");
            }

            usr = new Usuario(dtUsuario.Rows[0]);
            dtUsuario.Dispose();

            label24.Text = usr.Nombre;

            DataTable dtUserActivity = new User_ActivityTableAdapter().GetDataByIdFecha(usr.Id, (decimal)m_Month, (decimal)m_Year);

            if (dtUserActivity.Rows.Count <= 0)
            {
                throw new Exception("El usuario no tiene datos para el mes y año seleccionados, favor de revisar.");
            }

            foreach (DataRow dr in dtUserActivity.Rows)
            {
                DateTime dtime = DateTime.Parse(dr["Activity_Date"].ToString());

                if (dtime.DayOfWeek != DayOfWeek.Saturday && dtime.DayOfWeek != DayOfWeek.Sunday)
                {
                    int salida = 0;
                    int.TryParse(dr["OP_CFIN"].ToString(), out salida);
                    m_NumeroReclamaciones += salida; salida = 0;
                    int.TryParse(dr["OP_CCIN"].ToString(), out salida);
                    m_NumeroCCIN += salida; salida = 0;
                    int.TryParse(dr["ACD_Calls"].ToString(), out salida); 
                    m_NumeroLlamadas += salida;
                    m_DiasLaborados++;
                }
            }

            label52.Text = ((double.Parse(m_NumeroReclamaciones.ToString()) * 14) / 10).ToString();
            label51.Text = ((double.Parse(m_NumeroCCIN.ToString()) * 3) / 10).ToString();
            label53.Text = ((double.Parse(m_NumeroLlamadas.ToString()) * 6) / 10).ToString();
            label32.Text = (m_DiasLaborados * 42).ToString();

            m_Total = double.Parse(label52.Text) + double.Parse(label51.Text) + double.Parse(label53.Text);// +double.Parse(label32.Text);

            DataTable dtCorrespondencia = new TIME_FLEX_DATATableAdapter().GetDataBy(usr.Id, "Correspondencia", timeConsulta);
            
            if (dtCorrespondencia.Rows.Count == 0)
            {
                if (MessageBox.Show("El usuario no tiene correspondencia, ¿es esto correcto?", "Información", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    throw new Exception("El usuario debe tener correspondencia");
                }
                else { label55.Text = "0"; }
            }
            else
            {
                m_Correspondencia = int.Parse(dtCorrespondencia.Rows[dtCorrespondencia.Rows.Count - 1]["Flex_dec_01"].ToString());
                label55.Text = m_Correspondencia.ToString();
                m_Total += double.Parse(m_Correspondencia.ToString());
            }

            DataTable dtCalidadClaims = new TIME_FLEX_DATATableAdapter().GetDataBy(usr.Id, "Calidad - Claims", timeConsulta);

            if (dtCalidadClaims.Rows.Count == 0)
            {
                if (MessageBox.Show("El usuario no tiene calificación Claims, ¿es esto correcto?", "Información", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    throw new Exception("El usuario debe tener calificación para Calidad - Claims");
                }
                else { label70.Text = "0"; label88.Text = "0"; }
            }
            else
            {
                m_CalidadClaims = double.Parse(dtCalidadClaims.Rows[dtCalidadClaims.Rows.Count - 1]["Flex_dec_01"].ToString());
                label70.Text = m_CalidadClaims.ToString();
                label88.Text = decimal.Round(((decimal)m_CalidadClaims * 20) / 100, 2).ToString();
            }

            DataTable dtCalidadCalls = new TIME_FLEX_DATATableAdapter().GetDataBy(usr.Id, "Calidad - Calls", timeConsulta);

            if (dtCalidadCalls.Rows.Count == 0)
            {
                if (MessageBox.Show("El usuario no tiene calificación Calls, ¿es esto correcto?", "Información", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    throw new Exception("El usuario debe tener calificación para Calidad - Calls");
                }
                else { label87.Text = "0"; label68.Text = "0"; }
            }
            else
            {
                m_CalidadCalls = double.Parse(dtCalidadCalls.Rows[dtCalidadCalls.Rows.Count - 1]["Flex_dec_01"].ToString());
                label68.Text = m_CalidadCalls.ToString();
                label87.Text = decimal.Round(((decimal)m_CalidadCalls * 20) / 100, 2).ToString();
            }

            label89.Text = decimal.Round(decimal.Parse(label88.Text) + decimal.Parse(label87.Text), 2).ToString();

            DataTable m_LFAsignaciones = new TIME_ASIGNACION_LASER_FICHE1TableAdapter().GetDataBy(timeConsulta.Month, timeConsulta.Year, usr.Id);
            
            if (m_LFAsignaciones.Rows.Count == 0)
            {
                if (MessageBox.Show("El usuario no tiene asignaciones, ¿es esto correcto?", "Información", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    throw new Exception("El usuario debe tener asignaciones");
                }
                else { label54.Text = "0"; }
            }
            else
            {
                m_Asignaciones = int.Parse(m_LFAsignaciones.Rows[0][0].ToString());
                label54.Text = ((double.Parse(m_Asignaciones.ToString()) * 5) / 10).ToString();
                m_Total += double.Parse(label54.Text);
            }

            DataTable m_dtPuntualidad = new TIME_CMS_LOGIN_LOGOUTTableAdapter().GetDataBy(usr.Id, timeConsulta.Month, timeConsulta.Year);
            if (m_dtPuntualidad.Rows.Count == 0)
            {
                if (MessageBox.Show("El usuario no tiene datos de puntualidad, ¿es esto correcto?", "Información", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    throw new Exception("El usuario debe de tener asignaciones");
                }
                else { label57.Text = "0"; }
            }
            else
            {
                double promedio = 0;
                int menos = 0;
                DateTime ant = new DateTime();
                foreach (DataRow dr in m_dtPuntualidad.Rows)
                {
                    DateTime tiempo = DateTime.Parse(dr["Login_Time"].ToString());
                    DateTime fecha = DateTime.Parse(dr["Logout_Date"].ToString());
                    if (ant.Month == fecha.Month && ant.Year == fecha.Year && ant.Day == fecha.Day)
                    {
                        menos++;
                    }
                    else
                    {
                        promedio += double.Parse(tiempo.TimeOfDay.TotalMinutes.ToString());
                    }
                    ant = fecha;
                }

                promedio = promedio / (m_dtPuntualidad.Rows.Count - menos);

                double diferencia;
                
                if(promedio < 580)
                {
                    diferencia = promedio - 540;
                }
                else
                {
                    diferencia = promedio - 600;
                }

                diferencia = 100 - ((diferencia * 100) / 11);

                label57.Text = decimal.Round((decimal)diferencia, 2).ToString();
                label90.Text = decimal.Round(((decimal)diferencia * 10) / 100, 2).ToString();
            }

            DataTable m_Registros = new TIME_REGISTROSTableAdapter().GetDataBy(usr.Id, timeConsulta.Month, timeConsulta.Year);

            if (m_Registros.Rows.Count == 0)
            {
                throw new Exception("El usuario no tiene registros, favor de revisar");
            }
            else
            {
                double m_training = 0;
                double m_feedback = 0;
                double m_meeting = 0;
                double m_additional = 0;

                foreach (DataRow dr in m_Registros.Rows)
                {
                    DateTime inicio = DateTime.Parse(dr["Inicio"].ToString());
                    DateTime final = DateTime.Parse(dr["Final"].ToString());
                    switch (dr["Accion"].ToString())
                    {
                        case "3":
                            m_training += final.Subtract(inicio).Minutes;
                            break;
                        case "4":
                            m_feedback += final.Subtract(inicio).Minutes;
                            break;
                        case "5":
                            m_meeting += final.Subtract(inicio).Minutes;
                            break;
                        case "6":
                            m_additional += final.Subtract(inicio).Minutes;
                            break;
                    }
                }

                m_training = (m_training / 10);// *double.Parse("5.25");
                m_feedback = (m_feedback / 10);// *double.Parse("5.25");
                m_meeting = (m_meeting / 10);// *double.Parse("5.25");
                m_additional = (m_additional / 10);// *double.Parse("5.25");

                label45.Text = decimal.Round((decimal)m_training, 2).ToString();
                label46.Text = decimal.Round((decimal)m_feedback, 2).ToString();
                label47.Text = decimal.Round((decimal)m_meeting, 2).ToString();
                label48.Text = decimal.Round((decimal)m_additional, 2).ToString();

                m_Total += m_training + m_feedback + m_meeting + m_additional;  
            }

            label49.Text = decimal.Round((decimal)m_Total).ToString();
            label61.Text = decimal.Round((((decimal)m_Total * 100) / decimal.Parse(label32.Text)), 2).ToString();
            label80.Text = decimal.Round(((decimal.Parse(label61.Text) * 50) / 100), 2).ToString();
            label75.Text = decimal.Round(decimal.Parse(label80.Text) + decimal.Parse(label89.Text) + decimal.Parse(label90.Text), 2).ToString();
        }
    }
}
