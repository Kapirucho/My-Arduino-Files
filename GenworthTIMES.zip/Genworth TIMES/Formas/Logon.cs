using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Genworth_TIMES.DataBase.TimeDataTableAdapters;
using Objetos;
using Genworth_TIMES.Properties;
using System.Net.NetworkInformation;
using System.Diagnostics;
using System.Reflection;
using System.Data.SqlClient;

namespace Genworth_TIMES {
    public partial class Logon : Form {
        private int intentos = 0;
        /// <summary>
        /// Constructor initiate object
        /// </summary>
        public Logon() {
            InitializeComponent();
            //Centramos
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.getVersion();
        }

        /// <summary>
        /// Return current asembly version
        /// </summary>
        private void getVersion()
        {
            Assembly asm = Assembly.GetExecutingAssembly();
            FileVersionInfo fvi = FileVersionInfo.GetVersionInfo(asm.Location);
            this.lblVersion.Text = "Ver." + this.Version()
                + " B." + Assembly.GetEntryAssembly().GetName().Version.ToString();
        }

        /// <summary>
        /// Application OnceClick deployment
        /// </summary>
        /// <returns>Return Application deployment version when OneClick</returns>
        private string Version()
        {
            if (System.Deployment.Application.ApplicationDeployment.IsNetworkDeployed)
            {
                return System.Deployment.Application.ApplicationDeployment.CurrentDeployment.CurrentVersion.ToString();
            }
            else
            {
                return Application.ProductVersion;
            }
        }

        /// <summary>
        /// Button to login into the system
        /// Connect to the database to check if users exist
        /// Check against Active directory for current user and password
        /// Load user general data
        /// </summary>
        /// <param name="sender">Object null</param>
        /// <param name="e">Empty</param>
        private void button1_Click(object sender, EventArgs e) {
            if (intentos == 4) {
                if (MessageBox.Show("La sesion ser� bloqueada", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop) == DialogResult.OK) {
                    this.Close();
                }
            }

            try {
                if (textBox2.Text.Trim() == string.Empty || textBox1.Text.Trim() == string.Empty) { return; }

                this.Hide();
                toolStripStatusLabel1.Text = "Conectando...";

                //agregamos conexion directa para probar servidor en leon AP003ALEO
                connectAP003ALEO();




                //DataTable dt = new TIME_USUARIOSTableAdapter().GetDataByUserPass(textBox1.Text, textBox2.Text);
                DataTable dt = new TIME_USUARIOSTableAdapter().GetDataByUserPass(textBox1.Text, textBox1.Text);
                Secure Sec = new Secure();

                if (dt.Rows.Count == 1 && Sec.LogonUser(textBox1.Text, textBox2.Text)) {
                //if (Sec.LogonUser(textBox1.Text, textBox2.Text)) {
                //if (1 == 1) {

                    DataTable dtAcc = new TIME_ACCIONESTableAdapter().GetData();
                    DataTable dtTps = new TIME_TIPOSTableAdapter().GetData();
                    DataTable dtUsrs = new TIME_USUARIOSTableAdapter().GetData();
                    Principal frm = new Principal(new Usuario(dt), new Acciones(dtAcc), new Tipos(dtTps), new Usuarios(dtUsrs));
                    dt.Dispose();
                    dtAcc.Dispose();
                    dtTps.Dispose();
                    dtUsrs.Dispose();
                    frm.ShowDialog();
                    this.Close();
                } else {
                    intentos++;
                    this.Show();
                    MessageBox.Show("Favor de revisar su usuario y/o contrase�a");
                }
            } catch (Exception Ex) {
                this.Show();
                toolStripStatusLabel1.Text = "No existe conexi�n";
                if (MessageBox.Show("El servidor no esta disponible, �Desea iniciar sesi�n remota?", "Informaci�n", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) {
                    this.Hide();
                    this.checkBox1.Checked = true;
                    this.button1_Click(sender, e);
                }
            }
        }

        /// <summary>
        /// direct connection to server in Leon Mexico, DEPRECATE
        /// </summary>
        private void connectAP003ALEO() {
            SqlDataReader resConsulta = null;
            SqlConnection conexionSQL = new SqlConnection();
            conexionSQL.ConnectionString = "Data Source=AP003ALEO;Initial Catalog=MXOSPROD;Persist Security Info=True;User ID=PRODUSR;Password=H0wUNcUL0_pn0Fzs";

            conexionSQL.Open();
            SqlCommand cmd = new SqlCommand("PRODUSR.USP_USER_PROFILE", conexionSQL);
            cmd.Parameters.Add("@opcion", SqlDbType.Int).Value = 0;
            cmd.Parameters.Add("@userid", SqlDbType.Int).Value = 0;
            cmd.Parameters.Add("@entrada", SqlDbType.Int).Value = 0;
            cmd.Parameters.Add("@sso", SqlDbType.VarChar).Value = "501299026";

            cmd.CommandTimeout = 6000;
            cmd.CommandType = CommandType.StoredProcedure;

            resConsulta = cmd.ExecuteReader();
                   
            resConsulta.Close();
            cmd.Dispose();
            conexionSQL.Close();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e) {
            Settings.Default.RemoteLocation = checkBox1.Checked;
            Settings.Default.Save();
        }

        private StringBuilder m_passcode = new StringBuilder();
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e) {
            m_passcode.Append(e.KeyChar);
            if (m_passcode.ToString() == "config") {
                Configuracion cf = new Configuracion();
                cf.ShowDialog();
            }
        }

        private void Logon_Load(object sender, EventArgs e) {

        }
    }
}