﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Genworth_TIMES.Clase;
using Objetos;

namespace Genworth_TIMES.Formas
{
    public partial class MyGlobalScore : Form
    {
        MatrizGlobalScore mgs = null;
        Usuario m_usr;
        public MyGlobalScore(Usuario usr)
        {
            InitializeComponent();
            m_usr = usr;
            this.Init();
        }

        private void Init()
        {
            try
            {
                mgs = new MatrizGlobalScore(dateTimePicker1.Value.Month, dateTimePicker1.Value.Year);
                mgs.GenerateNewChart(this.chart1);
            }
            catch (Exception Ex)
            {
                MessageBox.Show("No existe información. Error: " + Ex.Message);
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                mgs = new MatrizGlobalScore(dateTimePicker1.Value.Month, dateTimePicker1.Value.Year);
                mgs.GenerateNewChart(this.chart1);
            }
            catch (Exception Ex)
            {
                MessageBox.Show("No existe información. Error: " + Ex.Message);
            }
        }
    }
}
