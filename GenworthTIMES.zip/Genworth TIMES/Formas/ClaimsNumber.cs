﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Genworth_TIMES.Clase;
using Objetos;

namespace Genworth_TIMES.Formas
{
    public partial class ClaimsNumber : Form
    {

        private GlobalValues _GV;
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="GV">Global Values</param>
        /// <param name="WindowTitle">Window Title</param>
        public ClaimsNumber(GlobalValues GV, string WindowTitle)
        {
            InitializeComponent();
            _GV = GV;
            this.Init();
            this.Text = this.Text + " - " + WindowTitle;
        }

        /// <summary>
        /// Initiate Items
        /// </summary>
        private void Init()
        {
            int cc = 0;
            
            //this.cbDocs.Items.Add(this._GV.Documents);
            foreach (string[] a in _GV.Documents)
            {
                //this.ddCountry.DropDownItems.Add(a[0]);
                //this.ddCountry.DropDownItems[cc].Tag = a[1];
                //cc = this.cbDocs.Items.Add(a[0]);
                this.cbDocs.Items.Insert(int.Parse(a[1].ToString()) - 1, a[0]);
                //cc++;
            }
            //this.ddCountry.DropDownItemClicked += new ToolStripItemClickedEventHandler(DropDownItemClick);
        }

        private int _selectedIndex = int.MinValue;
        /// <summary>
        /// Return selectd document index
        /// </summary>
        public int SelectedIndex
        {
            get { return _selectedIndex; }
            set 
            { 
                _selectedIndex = value;
                if (value > int.MinValue)
                {
                    this.cbDocs.SelectedIndex = value;
                }
            }
        }

        private string _doc = string.Empty;
        public string Doc
        {
            get { return _doc; }
            set { _doc = value; }
        }

        public bool close_a = false;
        /// <summary>
        /// Selected index changed to determine Document combobox index
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cbDocs_SelectedIndexChanged(object sender, EventArgs e)
        {
            _selectedIndex = this.cbDocs.SelectedIndex;
            _doc = this.cbDocs.SelectedItem.ToString();
            close_a = true;
        }

        private int _ClaimNumber = int.MinValue;
        public int ClaimNumber
        {
            get { return _ClaimNumber; }
            set { _ClaimNumber = value; }
        }

        public bool close = true;
        /// <summary>
        /// Boton OK set as messagebox
        /// </summary>
        /// <param name="sender">Empty</param>
        /// <param name="e">Empty</param>
        private void btnOk_Click(object sender, EventArgs e)
        {
            int value;
            close = int.TryParse(this.txbClaimsNumber.Text, out value);
            if (close)
            {
                this._ClaimNumber = value;
            }
            else
            {
                MessageBox.Show("El número de reclamación no es valido");
            }
        }

        /// <summary>
        /// Clean text box on mouse enter
        /// </summary>
        /// <param name="sender">Empty</param>
        /// <param name="e">Empty</param>
        private void txbClaimsNumber_Click(object sender, EventArgs e)
        {
            this.txbClaimsNumber.Text = "";
        }

        /// <summary>
        /// Only allow numbers to be entered into ClaimsNumber textbox
        /// </summary>
        /// <param name="sender">Empty</param>
        /// <param name="e">Empty</param>
        private void txbClaimsNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }
    }
}
