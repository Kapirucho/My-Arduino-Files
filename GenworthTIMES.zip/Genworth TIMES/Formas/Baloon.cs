using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Genworth_TIMES
{
    public partial class Baloon : Form
    {
        public Baloon()
        {
            InitializeComponent();
            this.CalculatePosition();
            this.RandomColor();
        }

        private void CalculatePosition()
        {
            this.DesktopLocation = new Point(Screen.PrimaryScreen.WorkingArea.Width - this.Width,
                                             Screen.PrimaryScreen.WorkingArea.Height - this.Height);
        }

        public String Titulo
        {
            get { return this.Text; }
            set { this.Text = value; }
        }

        public String Mensaje
        {
            get { return this.textBox1.Text; }
            set { this.textBox1.Text = value; }
        }

        public void Mostrar(String Titulo, String Mensaje)
        {
            this.Text = Titulo;
            this.textBox1.Text = Mensaje;
            this.Show();
        }

        public void RandomColor()
        {
            this.BackColor = Color.YellowGreen;
            this.textBox1.BackColor = this.BackColor;
        }
    }
}