using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using Objetos;
using Genworth_TIMES.DataBase.TimeDataTableAdapters;

namespace Genworth_TIMES
{
    public partial class Auxiliar : Form
    {
        private Stopwatch sw = new Stopwatch();
        private Usuario _Current_User = new Usuario();// = null;
        private Acciones _Acciones = new Acciones(); // = null;
        private Tipos _Tipos = new Tipos();// null;
        private GlobalValues _Globales = null;

        private Registros _Current = new Registros();

        private Baloon bl = new Baloon();

        public enum Actividad
        {
            Inplant,
            Local,
            Admin
        }

        public Auxiliar(Usuario Usr, Acciones Acc, Tipos Tps, Actividad Act, GlobalValues GV)
        {
            _Current_User = Usr;
            _Acciones = Acc;
            _Tipos = Tps;
            _Globales = GV;
            InitializeComponent();
            this.inicialiar_botones(Act);
            this.notifyIcon1.Icon = global::Genworth_TIMES.Properties.Resources._1253933144_system_users;
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.Text = (Act == Actividad.Local ? "GNW Time Tracker - Auxiliares" : "GNW Time Tracker - Inplant");
            this.Text = (Act == Actividad.Local ? "Auxiliar" : "Inplant");

            if (Act == Actividad.Admin)
            {
                this.notifyIcon1.Text = "Administraci�n del tiempo";
                this.Text = "Administraci�n del tiempo";
            }
            this.Text += " | " + _Globales.Country + ", " + _Globales.Client;
            inicializar_botones(Act);
            
        }

        private void inicialiar_botones(Actividad Act)
        {
            if (Act == Actividad.Inplant)
            {
                //this.boton14.Visible = true;
                //this.boton15.Visible = true;
                //this.boton18.Visible = true;
                //this.boton10.p_Tip = Boton.Tips.RegistroSistemaCliente;
                //this.boton12.Visible = false;
                //this.boton20.p_Tip = Boton.Tips.EnEspera;
                //this.boton9.p_Tip = Boton.Tips.AnalisisBanamex;
                //this.boton11.p_Tip = Boton.Tips.AnalisisSantander;
            }
        }

        private void inicializar_botones(Actividad Act)
        {
            if (Act == Actividad.Admin)
            {
                foreach (Control ctl in groupBox1.Controls)
                {
                    if (ctl is Boton)
                    {
                        ((Boton)ctl).Visible = false;
                    }
                }

                foreach (Control ctl in groupBox2.Controls)
                {
                    if (ctl is Boton)
                    {
                        ((Boton)ctl).Visible = false;
                    }
                }

                groupBox2.Visible = false;
                groupBox1.Text = "Actividades";

                this.boton1.p_Tip = Boton.Tips.GenworthOperaciones;
                this.boton1.Visible = true;
                this.boton2.p_Tip = Boton.Tips.GenworthSegurosVida;
                this.boton2.Visible = true;
                this.boton3.p_Tip = Boton.Tips.GenworthSegurosDa�os;
                this.boton3.Visible = true;
                this.boton4.p_Tip = Boton.Tips.GenworthColombia;
                this.boton4.Visible = true;
                this.boton4.p_Descripcion = false;
            }
        }

        private void Asignacion()
        {
            foreach (Control ctl in groupBox1.Controls)
            {
                if (ctl is Boton)
                {
                    ((Boton)ctl).p_Accion = _Acciones;
                    ((Boton)ctl).p_Tipos = _Tipos;
                }
            }

            foreach (Control ctl in groupBox2.Controls)
            {
                if (ctl is Boton)
                {
                    ((Boton)ctl).p_Accion = _Acciones;
                    ((Boton)ctl).p_Tipos = _Tipos;
                }
            }
        }

        private bool _baloonSent = false;
        private void timer1_Tick(object sender, EventArgs e)
        {
            lblTimer.Text = sw.Elapsed.Hours.ToString() + ":" + sw.Elapsed.Minutes.ToString() + ":" + sw.Elapsed.Seconds.ToString();
            label5.Text = _SW_Break.Elapsed.Hours.ToString()
                          + ":" + _SW_Break.Elapsed.Minutes.ToString()
                          + ":" + _SW_Break.Elapsed.Seconds.ToString();
            label6.Text = _SW_Lunch.Elapsed.Hours.ToString()
                          + ":" + _SW_Lunch.Elapsed.Minutes.ToString()
                          + ":" + _SW_Lunch.Elapsed.Seconds.ToString();

            if (_Acciones.MaxElapsed != 0 && sw.Elapsed.Minutes != 0)
            {
                if (sw.Elapsed.Minutes >= _Acciones.MaxElapsed - 1 && sw.Elapsed.Minutes < _Acciones.MaxElapsed && _Acciones.MaxElapsed != 0)
                {
                    if ((this.sw.Elapsed.Seconds % 2) == 0)
                    {
                        lblTimer.ForeColor = Color.OrangeRed;
                    }
                    else
                    {
                        lblTimer.ForeColor = Color.Black;
                    }
                }
                else if (sw.Elapsed.Minutes >= _Acciones.MaxElapsed && _Acciones.MaxElapsed != 0)
                {
                    if ((this.sw.Elapsed.Seconds % 2) == 0)
                    {
                        lblTimer.ForeColor = Color.Red;
                    }
                    else
                    {
                        lblTimer.ForeColor = Color.Black;
                    }

                    if (!_baloonSent)
                    {
                        _baloonSent = true;
                        bl = new Baloon();
                        bl.Mostrar("Aviso!", "El tiempo recomendado para la tarea: " + _Acciones.Nombre + " fue superado!");
                    }
                }
                else
                {
                    lblTimer.ForeColor = Color.Black;
                    _baloonSent = false;
                }
            }
            else
            {
                lblTimer.ForeColor = Color.Black;
                if (_baloonSent)
                {
                    _baloonSent = false;
                }
            }
        }

        Stopwatch _SW_Break = new Stopwatch();
        Stopwatch _SW_Lunch = new Stopwatch();
        String _Titulo_Anterior = string.Empty;
        Boton.Tips _tip_anterior = Boton.Tips.Otros;
        
        /// <summary>
        /// Start/Stop the current action
        /// </summary>
        /// <param name="sender">Empty Object</param>
        /// <param name="e">EventArgs.Empty</param>
        public void boton1_Click(object sender, EventArgs e)
        {
            Boton btn = ((Boton)sender);
            
            //**********************************************
            _Acciones.Obtener(btn.p_Texto);
            _Tipos.Obtener(_Acciones.Tipo);

            

            /*
            if (_Acciones.Nombre == "Break")
            {
                _SW_Break.Start();
                _SW_Lunch.Stop();
            }
            else if (_Acciones.Nombre == "Lunch")
            {
                _SW_Lunch.Start();
                _SW_Break.Stop();
            }
            else
            {
                _SW_Break.Stop();
                _SW_Lunch.Stop();
            }
             */
            //**********************************************
            if (sw.IsRunning)
            {
                sw.Stop();
                _Current.Final = _Current.Inicio.Add(sw.Elapsed);
                sw.Reset();

                //if (((Boton)sender).p_Tip == Boton.Tips.PhoneIn)
                if (_tip_anterior == Boton.Tips.Pending_Claims ||
                    _tip_anterior == Boton.Tips.Continuing_Claim ||
                    _tip_anterior == Boton.Tips.Corres ||
                    _tip_anterior == Boton.Tips.Nueva_Reclamacion ||
                    _tip_anterior == Boton.Tips.Complaints)
                {
                    HandleClaimsNumber(_Titulo_Anterior);
                }

                global::Genworth_TIMES.Comunes.AddRegistro(_Current.Accion,
                                                        _Current.Tipo,
                                                        _Current.Usuario,
                                                        _Current.Inicio,
                                                        _Current.Final,
                                                        _Current.Descripcion,
                                                        _Current.ClaimsNumber,
                                                        _Current.Document,
                                                        _Globales.Country,// _Current.Country,
                                                        _Globales.Client);// _Current.Client);

                _Titulo_Anterior = btn.p_Texto;
                _tip_anterior = btn.p_Tip;
                
            }

            if (!sw.IsRunning)
            {
                _Titulo_Anterior = btn.p_Texto;
                _tip_anterior = btn.p_Tip;
                sw.Start();
            }

            //***********************************************
            _Current.Clear();
            _Current.Accion = _Acciones.Id;
            _Current.Inicio = DateTime.Now;
            _Current.Tipo = _Tipos.Id;
            _Current.Usuario = _Current_User.Id;

            _Acciones.MaxElapsed = btn.p_MaxTimeElapsed;

            Comunes.InsertOrUpdate(_Current.Inicio, (int)_Current.Accion, _Current_User.Id, _Acciones.MaxElapsed);
            
            //sw.Start();
            this.Asigna(btn.p_Texto);

            /*
            if (btn.p_Tip == Boton.Tips.PhoneIn)
            {
                //Formas.ModeloPhin mp = new Formas.ModeloPhin();
                //mp.ShowDialog();
            }
             */

            //this.ValidarDescripcion(sender);
        }

        /// <summary>
        /// Set the claim number into textbox for use in the Global Score object
        /// </summary>
        /// <param name="WindowTitle">Set the window title to the last used action</param>
        private void HandleClaimsNumber(String WindowTitle)
        {
            Formas.ClaimsNumber cn = new Formas.ClaimsNumber(_Globales, WindowTitle);
            if (cn.ShowDialog(this) == System.Windows.Forms.DialogResult.OK)
            {
                _Current.ClaimsNumber = cn.ClaimNumber;
                _Current.Country = _Globales.Country;
                _Current.Client = _Globales.Client;
                _Current.Document = cn.Doc;

                int si = cn.SelectedIndex;

                if (!cn.close || !cn.close_a)
                {
                    this.HandleClaimsNumber(WindowTitle);
                    cn.ClaimNumber = _Current.ClaimsNumber;
                    cn.SelectedIndex = si;
                }
            }
        }

        /// <summary>
        /// Validate the text description DEPRECATED
        /// </summary>
        /// <param name="sender">Object null</param>
        private void ValidarDescripcion(object sender)
        {
            if (((Boton)sender).p_Descripcion)
            {
                bool pIn = false;
                if (((Boton)sender).p_Tip == Boton.Tips.PhoneIn) { pIn = true; }

                descripcion dsc = new descripcion(pIn,((Boton)sender).p_Tip.ToString());
                
                if (dsc.ShowDialog() == DialogResult.OK)
                {
                    if (_Current.Accion == 42 || _Current.Accion == 46)
                    {
                        double d = 0;

                        if (dsc.Texto.Length > 12)
                        {
                            MessageBox.Show("El valor no puede ser mayor de 12 caracteres n�merico.");
                            this.ValidarDescripcion(sender);
                        }
                        else if (!double.TryParse(dsc.Texto, out d))
                        {
                            MessageBox.Show("El valor no puede ser alfan�merico.");
                            this.ValidarDescripcion(sender);
                        }
                        else { _Current.Descripcion = dsc.Texto; }
                    }
                    else
                    {
                        _Current.Descripcion = dsc.Texto;
                    }
                }
            }
        }

        /// <summary>
        /// Set the text for the time label
        /// </summary>
        /// <param name="Ta">Label name</param>
        private void Asigna(String Ta)
        {
            lblTarea.Text = Ta;
            lblInicio.Text = _Current.Inicio.ToShortTimeString();// DateTime.Now.ToShortTimeString();
            lblTimer.Text = "0";
        }

        /// <summary>
        /// Protect the form from unexpected close
        /// </summary>
        /// <param name="e"></param>
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            Form fcl = new Logout(_Acciones, _Tipos, _Current_User);
            if (fcl.ShowDialog() != DialogResult.OK)
            {
                e.Cancel = true;
                return;
            }
            sw.Stop();
            _Current.Final = _Current.Inicio.Add(sw.Elapsed);
            try
            {
                global::Genworth_TIMES.Comunes.AddRegistro(_Current.Accion,
                                                            _Current.Tipo,
                                                            _Current.Usuario,
                                                            _Current.Inicio,
                                                            _Current.Final,
                                                            _Current.Descripcion,
                                                            _Current.ClaimsNumber,
                                                            _Current.Document,
                                                            _Current.Country,
                                                            _Current.Client);
            }
            catch (Exception) { }
            base.OnFormClosing(e);
        }

        /// <summary>
        /// Add a record to the database with the login into screen
        /// </summary>
        /// <param name="sender">Object null</param>
        /// <param name="e">EventArgs.Empty</param>
        private void Auxiliar_Load(object sender, EventArgs e)
        {
            //new TIME_REGISTROSTableAdapter().Insert(19, 2, _Current_User.Id, DateTime.Now, DateTime.Now, "");
            global::Genworth_TIMES.Comunes.AddRegistro(19, 2, _Current_User.Id, DateTime.Now, DateTime.Now, "", -1, string.Empty, string.Empty, string.Empty);
        }
    }
}