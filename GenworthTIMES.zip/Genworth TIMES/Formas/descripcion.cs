using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Genworth_TIMES
{
    public partial class descripcion : Form
    {
        private Boolean m_PhoneIn = false;
        public descripcion(Boolean PhoneIn, string act_desc)
        {
            InitializeComponent();
            this.Text += " --->  " + act_desc.ToString();
            m_PhoneIn = PhoneIn;
            if (m_PhoneIn)
            {
                //Se manda a false directo ya no se ocupa la lista.
                //this.listBox1.Visible = true;
            }
        }
 


        public descripcion()
        {
            InitializeComponent();
        }

        public String Texto
        {
            get
            {
                if (m_PhoneIn)
                {
                    try
                    {
                        return this.listBox1.SelectedItem.ToString();
                    }
                    catch (Exception)
                    {
                        return "";
                    }
                }
                else
                {
                    return this.textBox1.Text;
                }
            }
            set
            {
                this.textBox1.Text = value;
            }
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            //if (m_PhoneIn)
            //{
            //    //this.textBox1.Text = this.listBox1.SelectedItem.ToString().Substring(0, 2).Trim();
            //}

            //if (this.textBox1.Text.Trim() == String.Empty)
            //{
            //    //MessageBox.Show("No se puede cerrar esta ventana sin poner una descripci�n");
            //    //e.Cancel = true;
            //}

            if (this.checkBox1.Checked)
            {
                if (String.IsNullOrEmpty(this.textBox1.Text.Trim()))
                {
                    MessageBox.Show("Por favor ingrese el n�mero de reclamaci�n.");
                    e.Cancel = true;
                }

                try
                {
                    double reclamacion = double.Parse(this.textBox1.Text.Trim());
                }
                catch (Exception)
                {
                    MessageBox.Show("El valor debe ser numerico.");
                    e.Cancel = true;
                }
            }
            else
            {
                if (!m_PhoneIn)
                {
                    if (string.IsNullOrEmpty(this.textBox1.Text.Trim()))
                    {
                        MessageBox.Show("No se puede cerrar esta ventana sin poner una descripci�n");
                        e.Cancel = true;
                    }
                }
            }

            //if (!m_PhoneIn)
            //{
            //    int s_numero;
            //    if (this.textBox1.Text.Trim().StartsWith("0"))
            //    {
            //        if (!int.TryParse(this.textBox1.Text.Trim().Remove(0, 1), out s_numero))
            //        {
            //            MessageBox.Show("Solo valores numericos para catalogar la llamada");
            //            e.Cancel = true;
            //        }
            //    }
            //    else if (!int.TryParse(this.textBox1.Text.Trim(), out s_numero))
            //    {
            //        MessageBox.Show("Solo valores numericos para catalogar la llamada");
            //        e.Cancel = true;
            //    }
            //}
            base.OnClosing(e);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}