using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Objetos;
using Genworth_TIMES.DataBase.TimeDataTableAdapters;

namespace Genworth_TIMES
{
    public partial class Logout : Form
    {
        private Tipos _Tps = null;
        private Acciones _Acc = null;
        private Usuario _Usr = null;

        public Logout(Acciones Acc, Tipos Tps, Usuario Usr)
        {
            InitializeComponent();
            _Tps = Tps;
            _Acc = Acc;
            _Usr = Usr;
            _Tps.Obtener("Logout");
            FillOptions();
        }

        private void FillOptions()
        {
            foreach (Object[] Dato in _Acc.Datos)
            {
                if (Convert.ToInt32(Dato[2]) == _Tps.Id)
                {
                    if (Dato[1].ToString() != "Login")
                    {
                        this.checkedListBox1.Items.Add(Dato[1].ToString());
                    }
                }
            }
        }

        private bool close = false;
        private void button1_Click(object sender, EventArgs e)
        {
            if (this.checkedListBox1.CheckedItems.Count > 1 || this.checkedListBox1.CheckedItems.Count == 0)
            {
                close = true;
                return;
            }
            else
            {
                close = false;
                _Acc.Obtener(this.checkedListBox1.SelectedItem.ToString());
                new TIME_REGISTROSTableAdapter().Insert(_Acc.Id, _Acc.Tipo, _Usr.Id, DateTime.Now, DateTime.Now, "", -1, string.Empty, string.Empty, string.Empty);
                new CurrentTableAdapter().UpdateQuery(DateTime.Now, _Acc.Id, _Usr.Id, 0);
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            e.Cancel = close;
            base.OnFormClosing(e);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            close = false;
        }
    }
}