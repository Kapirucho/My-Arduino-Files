using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Objetos;
using Genworth_TIMES.DataBase.TimeDataTableAdapters;
using System.Diagnostics;
using System.IO;
using Genworth_TIMES.Clase;
using System.Windows.Forms.DataVisualization.Charting;
using System.Collections;
using Genworth_TIMES.DataBase;
using Microsoft.VisualBasic;



namespace Genworth_TIMES {
    public partial class Supervision : Form {
        private Baloon bl = new Baloon();


        public Supervision(Usuario Usr, Acciones Acc, Tipos Tps, Usuarios Usrs) {
            InitializeComponent();
            _Current_User = Usr;
            _Acciones = Acc;
            _Tipos = Tps;
            _Usuarios = Usrs;
            //this.Carga();
            this.FillComboAsociados();
            this.Estilo();
            this.InitDgv();
            this.FillComboBox();
            //bl.Show();
            this.GetDatosAppConfig();
            this.GetUserProfile();
            this.numAnio.Value = DateTime.Now.Year;
            this.numMes.Value = DateTime.Now.Month;
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e) {
            this.numericUpDown5.Minimum = 1;
            this.numericUpDown5.Maximum = DateTime.DaysInMonth((int)this.numericUpDown2.Value, (int)this.numericUpDown1.Value);
            if (DateTime.Now.Month == (int)this.numericUpDown1.Value && DateTime.Now.Year == (int)this.numericUpDown2.Value) {
                this.numericUpDown5.Value = DateTime.Now.Month;
            }
        }

        private void FillNumerics(object sender, EventArgs e) {

        }

        private void GetUserProfile() {
            TimesDA t = new TimesDA();
            //int i = t.UpdateParameterTimes(decimal.Parse(txtAddAct.Text), decimal.Parse(txtAVG.Text));
            List<ProfileBE> lstProfile = new List<ProfileBE>();
            lstProfile = t.GetUserProfle();
            dgvPerfil.DataSource = lstProfile;



        }

        List<decimal> Numeros = new List<decimal>();

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e) {
            if (((DataGridView)sender).SelectedCells.Count <= 1) {
                Numeros.Clear();
            }

            try {
                Numeros.Add(decimal.Round(Convert.ToDecimal(((DataGridView)sender)[e.ColumnIndex, e.RowIndex].Value), 2));
            } catch (Exception) { }

            decimal uy = 0;
            try {
                foreach (decimal number in Numeros) {
                    uy += number;
                }
            } catch (Exception) { } finally {
                textBox1.Text = CalcularTiempo(uy, TiempoSeleccionado);
            }
        }

        private enum CalcTiempo {
            Segundos,
            Minutos,
            Horas
        }

        private CalcTiempo TiempoSeleccionado = CalcTiempo.Segundos;

        private void segundosToolStripMenuItem_Click(object sender, EventArgs e) {
            switch (((ToolStripMenuItem)sender).Text) {
                case "Segundos":
                    TiempoSeleccionado = CalcTiempo.Segundos;
                    break;
                case "Minutos":
                    TiempoSeleccionado = CalcTiempo.Minutos;
                    break;
                case "Horas":
                    TiempoSeleccionado = CalcTiempo.Horas;
                    break;
            }

            try {
                decimal uy = 0;
                foreach (decimal number in Numeros) {
                    uy += number;
                }
                textBox1.Text = CalcularTiempo(uy);
            } catch (Exception) { }

            foreach (ToolStripMenuItem itm in contextMenuStrip1.Items) {
                itm.Checked = false;
            }

            ((ToolStripMenuItem)sender).Checked = true;
        }

        private string CalcularTiempo(decimal Tiempo, CalcTiempo TipoTiempo) {
            String Salida = string.Empty;
            decimal calc = decimal.MinValue;
            switch (TipoTiempo) {
                case CalcTiempo.Segundos:
                    Salida = decimal.Round(decimal.Round(Tiempo, 2) * 60, 2).ToString();
                    break;
                case CalcTiempo.Minutos:
                    Salida = Tiempo.ToString();
                    break;
                case CalcTiempo.Horas:
                    calc = decimal.Round((decimal.Round(Tiempo, 2) / 60), 2);
                    Salida = decimal.Round(calc, 2).ToString();
                    break;
            }
            return Salida;
        }

        private string CalcularTiempo(decimal Tiempo) {
            return CalcularTiempo(Tiempo, TiempoSeleccionado);
        }

        private void RealTimeDataTimer_Tick(object sender, EventArgs e) {
            this.RTD();
        }

        private void RTD() {
            this.RetriveData();
            this.Iniciar();
        }

        #region Global Score

        private Hashtable m_htUsuario = new Hashtable();

        private void FillComboBox() {
            foreach (string data in Enum.GetNames(typeof(Objetos.Layouts.Formato))) {
                this.comboBox3.Items.Add(data);
            }

            DataTable dtUsuarios = new TIME_USUARIOSTableAdapter().GetData();

            this.cbAsociados.Items.Add("Todos");

            foreach (DataRow dr in dtUsuarios.Rows) {
                if (!string.IsNullOrEmpty(dr["Usrmx"].ToString()) && dr["Tipo"].ToString() != "3") {
                    m_htUsuario.Add(dr["Nombre"].ToString(), dr["Id"].ToString());
                    this.comboBox2.Items.Add(dr["Nombre"].ToString());
                    this.cbAsociados.Items.Add(dr["Nombre"].ToString());
                    this.comboBox5.Items.Add(dr["Nombre"].ToString());
                    this.comboBox6.Items.Add(dr["Nombre"].ToString());
                }
            }

            dtUsuarios.Dispose();
        }

        private void button1_Click(object sender, EventArgs e) {
            openFileDialog1.Filter = "CSV|*.csv";

            if (this.openFileDialog1.ShowDialog() == DialogResult.OK) {
                if (this.openFileDialog1.FileName == string.Empty) {
                    MessageBox.Show("Seleccione un archivo", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                this.textBox2.Text = this.openFileDialog1.FileName;

                //this.IniciarLecturaArchivos();
            }
        }

        private void button2_Click(object sender, EventArgs e) {
                this.IniciarLecturaArchivos();
        }

        private void IniciarLecturaArchivos() {
            try {
                Objetos.Layouts.Formato fm = (Objetos.Layouts.Formato)Enum.Parse(typeof(Objetos.Layouts.Formato), this.comboBox3.Text);
                int usuario = 0;
                try {
                    int.TryParse(this.m_htUsuario[this.comboBox2.Text].ToString(), out usuario);
                } catch (Exception) { }
                ReadFiles rf = new ReadFiles(this.openFileDialog1.FileName, fm, char.Parse(this.textBox3.Text), usuario, int.Parse(this.textBox4.Text));
                rf.IniciarliarObjetos();
                FileInfo fi = new FileInfo(this.openFileDialog1.FileName);
                this.listBox1.Items.Add("El archivo: " + fi.Name + ", se proceso correctamente!");
            } catch (ArgumentException) {
                MessageBox.Show("Por favor seleccione un layout", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } catch (Exception Ex) {
                MessageBox.Show(Ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e) {
            try {
                DateTime dtInsert = new DateTime(int.Parse(this.numericUpDown2.Value.ToString()),
                                                 int.Parse(this.numericUpDown1.Value.ToString()),
                                                 1);

                new TIME_FLEX_DATATableAdapter().Insert(int.Parse(this.m_htUsuario[this.comboBox5.Text].ToString()),
                                                        this.comboBox4.Text,
                                                        "",
                                                        "", "", "", "", "", "", "", "", "",
                                                        dtInsert, DateTime.Now, DateTime.Now,
                                                        DateTime.Now, DateTime.Now, 0, 0, 0, 0, 0,
                                                        decimal.Parse(this.textBox5.Text), 0, 0, 0, 0);

                MessageBox.Show("Se agrego correctamente el registro");
            } catch (Exception Ex) {
                MessageBox.Show("Se produjo un error: " + Ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e) {
            try {
                DataTable resultados = new DataTable();

                DateTime dtSelect = new DateTime(int.Parse(this.numericUpDown3.Value.ToString()),
                                                 int.Parse(this.numericUpDown4.Value.ToString()),
                                                 1);

                /*resultados = new TIME_FLEX_DATATableAdapter().GetDataBy(int.Parse(this.m_htUsuario[this.comboBox6.SelectedIndex].ToString()),
                                                            this.comboBox7.SelectedItem.ToString(),
                                                            dtSelect);*/
                if (this.comboBox6.SelectedIndex == 0)
                {
                    resultados = new TIME_FLEX_DATATableAdapter().GetDataByTodos(this.comboBox7.SelectedItem.ToString(),
                        dtSelect);
                }
                else
                {
                    resultados = new TIME_FLEX_DATATableAdapter().GetDataBy(int.Parse(this.m_htUsuario[this.comboBox6.SelectedItem.ToString()].ToString()),
                    this.comboBox7.SelectedItem.ToString(),
                    dtSelect);
                }

                try {
                    dataGridView1.Rows.Clear();
                } catch (Exception) { }

                dataGridView1.DataSource = resultados;
            } catch (Exception Ex) {
                MessageBox.Show("Error al procesar la consulta: " + Ex.Message);
            }
        }

        #endregion

        MatrizGlobalScore mgs;
        private void button5_Click(object sender, EventArgs e) {
            try {
                if (this.cbAsociados.SelectedItem.ToString() == "Todos") {
                    mgs = new MatrizGlobalScore((double)this.numMes.Value, (double)this.numAnio.Value);
                    this.MatrizGlobalScoreBindingSource.DataSource = mgs.MatrizGlobal;
                    this.rvGlobalScore.RefreshReport();
                    mgs.GenerateNewChart(this.graphGlobalScore);
                } else {
                    mgs = new MatrizGlobalScore(int.Parse(this.m_htUsuario[this.cbAsociados.Text].ToString()), (double)this.numMes.Value, (double)this.numAnio.Value);
                    this.MatrizGlobalScoreBindingSource.DataSource = mgs.MatrizGlobal;
                    this.rvGlobalScore.RefreshReport();
                    mgs.GenerateNewChart(this.graphGlobalScore);
                }
            } catch (Exception Ex) {
                MessageBox.Show(Ex.Message);
            }
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e) {
            if (comboBox4.Text.Contains("D�a")) {
                textBox5.Mask = "00/00/0000";
            } else {
                textBox5.Mask = "99999";
            }
        }

        private void GetDatosAppConfig() {
            TimesDA t = new TimesDA();
            List<ParameterBE> lstPara = new List<ParameterBE>();
            lstPara = t.GetParameterTimes();

            foreach (ParameterBE item in lstPara) {
                switch (item.Nombre) {
                    case "AddAct":
                        txtAddAct.Text = item.Valor.ToString("0");
                        break;
                    case "avg_acd_time":
                        txtAVG.Text = item.Valor.ToString("#.####");
                        break;
                    case "Corres":
                        txtCorres.Text = item.Valor.ToString("#.####");
                        break;
                    case "CFINScore":
                        txtCFINScore.Text = item.Valor.ToString("#.####");
                        break;
                    case "CCINScore":
                        txtCCINScore.Text = item.Valor.ToString("#.####");
                        break;
                }
                /*
                if (item.Nombre == "AddAct") {
                    txtAddAct.Text = item.Valor.ToString("0");
                } else {
                    txtAVG.Text = item.Valor.ToString("#.####");
                }*/

            }
        }

        private void btnGuardar_Click(object sender, EventArgs e) {
            TimesDA t = new TimesDA();
            int i = t.UpdateParameterTimes(txtAddAct.Text.ToDecimal(),
                            txtAVG.Text.ToDecimal(),
                            txtCorres.Text.ToDecimal(),
                            txtCFINScore.Text.ToDecimal(),
                            txtCCINScore.Text.ToDecimal());
            ClearText();
            GetDatosAppConfig();
            MessageBox.Show("Se actualizar�n correctamente los parametros");

        }

        private void ClearText() {
            txtAddAct.Text = string.Empty;
            txtAVG.Text = string.Empty;
        }

        private void button6_Click(object sender, EventArgs e) {

            Genworth_TIMES.Formas.Credenciales c = new Formas.Credenciales();
            c.pasado += new Formas.Credenciales.pasar(c_pasado);
            c.Show();



        }

        public void c_pasado(bool dato) {
            if (dato == true) {
                foreach (DataGridViewRow R in dgvPerfil.Rows) {
                    TimesDA t = new TimesDA();
                    t.UpdateUserProfile(int.Parse(R.Cells[4].Value.ToString()), int.Parse(R.Cells[0].Value.ToString()));

                }
                this.GetUserProfile();
                MessageBox.Show("Se actualizar�n los datos correctamente");
            } else {
                MessageBox.Show("las credenciales no son validas � no cuenta con perfil de supervisor");
            }
        }

        private void txtAddAct_TextChanged(object sender, EventArgs e) {

        }







    }
}