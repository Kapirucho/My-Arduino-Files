namespace Genworth_TIMES
{
    partial class Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Principal));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.archivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.herramientasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.auxiliaresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.banamexSantanderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.administraci�nDeTiempoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.administraci�nToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.globalScoreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.opcionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.locaci�nRemotaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.configuraci�nToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ayudaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.acercaDeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.timerLunch = new System.Windows.Forms.Timer(this.components);
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.ddCountry = new System.Windows.Forms.ToolStripDropDownButton();
            this.lblPais = new System.Windows.Forms.ToolStripLabel();
            this.ddCliente = new System.Windows.Forms.ToolStripDropDownButton();
            this.lblCliente = new System.Windows.Forms.ToolStripLabel();
            this.btnBreak = new System.Windows.Forms.ToolStripButton();
            this.btnLunch = new System.Windows.Forms.ToolStripButton();
            this.timerBreak = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.archivoToolStripMenuItem,
            this.herramientasToolStripMenuItem,
            this.opcionesToolStripMenuItem,
            this.ayudaToolStripMenuItem});
            resources.ApplyResources(this.menuStrip1, "menuStrip1");
            this.menuStrip1.Name = "menuStrip1";
            // 
            // archivoToolStripMenuItem
            // 
            this.archivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logoutToolStripMenuItem});
            this.archivoToolStripMenuItem.Name = "archivoToolStripMenuItem";
            resources.ApplyResources(this.archivoToolStripMenuItem, "archivoToolStripMenuItem");
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            resources.ApplyResources(this.logoutToolStripMenuItem, "logoutToolStripMenuItem");
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // herramientasToolStripMenuItem
            // 
            this.herramientasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.auxiliaresToolStripMenuItem,
            this.banamexSantanderToolStripMenuItem,
            this.administraci�nDeTiempoToolStripMenuItem,
            this.toolStripSeparator1,
            this.administraci�nToolStripMenuItem,
            this.globalScoreToolStripMenuItem});
            this.herramientasToolStripMenuItem.Name = "herramientasToolStripMenuItem";
            resources.ApplyResources(this.herramientasToolStripMenuItem, "herramientasToolStripMenuItem");
            // 
            // auxiliaresToolStripMenuItem
            // 
            this.auxiliaresToolStripMenuItem.Name = "auxiliaresToolStripMenuItem";
            resources.ApplyResources(this.auxiliaresToolStripMenuItem, "auxiliaresToolStripMenuItem");
            this.auxiliaresToolStripMenuItem.Click += new System.EventHandler(this.auxiliaresToolStripMenuItem_Click);
            // 
            // banamexSantanderToolStripMenuItem
            // 
            resources.ApplyResources(this.banamexSantanderToolStripMenuItem, "banamexSantanderToolStripMenuItem");
            this.banamexSantanderToolStripMenuItem.Name = "banamexSantanderToolStripMenuItem";
            this.banamexSantanderToolStripMenuItem.Click += new System.EventHandler(this.banamexSantanderToolStripMenuItem_Click);
            // 
            // administraci�nDeTiempoToolStripMenuItem
            // 
            resources.ApplyResources(this.administraci�nDeTiempoToolStripMenuItem, "administraci�nDeTiempoToolStripMenuItem");
            this.administraci�nDeTiempoToolStripMenuItem.Name = "administraci�nDeTiempoToolStripMenuItem";
            this.administraci�nDeTiempoToolStripMenuItem.Click += new System.EventHandler(this.administraci�nDeTiempoToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            resources.ApplyResources(this.toolStripSeparator1, "toolStripSeparator1");
            // 
            // administraci�nToolStripMenuItem
            // 
            this.administraci�nToolStripMenuItem.Name = "administraci�nToolStripMenuItem";
            resources.ApplyResources(this.administraci�nToolStripMenuItem, "administraci�nToolStripMenuItem");
            this.administraci�nToolStripMenuItem.Click += new System.EventHandler(this.administraci�nToolStripMenuItem_Click);
            // 
            // globalScoreToolStripMenuItem
            // 
            this.globalScoreToolStripMenuItem.Name = "globalScoreToolStripMenuItem";
            resources.ApplyResources(this.globalScoreToolStripMenuItem, "globalScoreToolStripMenuItem");
            this.globalScoreToolStripMenuItem.Click += new System.EventHandler(this.globalScoreToolStripMenuItem_Click);
            // 
            // opcionesToolStripMenuItem
            // 
            this.opcionesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.locaci�nRemotaToolStripMenuItem,
            this.toolStripSeparator2,
            this.configuraci�nToolStripMenuItem});
            this.opcionesToolStripMenuItem.Name = "opcionesToolStripMenuItem";
            resources.ApplyResources(this.opcionesToolStripMenuItem, "opcionesToolStripMenuItem");
            // 
            // locaci�nRemotaToolStripMenuItem
            // 
            this.locaci�nRemotaToolStripMenuItem.CheckOnClick = true;
            resources.ApplyResources(this.locaci�nRemotaToolStripMenuItem, "locaci�nRemotaToolStripMenuItem");
            this.locaci�nRemotaToolStripMenuItem.Name = "locaci�nRemotaToolStripMenuItem";
            this.locaci�nRemotaToolStripMenuItem.Click += new System.EventHandler(this.locaci�nRemotaToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            resources.ApplyResources(this.toolStripSeparator2, "toolStripSeparator2");
            // 
            // configuraci�nToolStripMenuItem
            // 
            this.configuraci�nToolStripMenuItem.Name = "configuraci�nToolStripMenuItem";
            resources.ApplyResources(this.configuraci�nToolStripMenuItem, "configuraci�nToolStripMenuItem");
            this.configuraci�nToolStripMenuItem.Click += new System.EventHandler(this.configuraci�nToolStripMenuItem_Click);
            // 
            // ayudaToolStripMenuItem
            // 
            this.ayudaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.acercaDeToolStripMenuItem});
            this.ayudaToolStripMenuItem.Name = "ayudaToolStripMenuItem";
            resources.ApplyResources(this.ayudaToolStripMenuItem, "ayudaToolStripMenuItem");
            // 
            // acercaDeToolStripMenuItem
            // 
            this.acercaDeToolStripMenuItem.Name = "acercaDeToolStripMenuItem";
            resources.ApplyResources(this.acercaDeToolStripMenuItem, "acercaDeToolStripMenuItem");
            this.acercaDeToolStripMenuItem.Click += new System.EventHandler(this.acercaDeToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            resources.ApplyResources(this.statusStrip1, "statusStrip1");
            this.statusStrip1.Name = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            resources.ApplyResources(this.toolStripStatusLabel1, "toolStripStatusLabel1");
            this.toolStripStatusLabel1.DoubleClick += new System.EventHandler(this.toolStripStatusLabel1_DoubleClick);
            // 
            // timerLunch
            // 
            this.timerLunch.Interval = 1000;
            this.timerLunch.Tick += new System.EventHandler(this.timerLunch_Tick);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ddCountry,
            this.lblPais,
            this.ddCliente,
            this.lblCliente,
            this.btnBreak,
            this.btnLunch});
            resources.ApplyResources(this.toolStrip1, "toolStrip1");
            this.toolStrip1.Name = "toolStrip1";
            // 
            // ddCountry
            // 
            this.ddCountry.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            resources.ApplyResources(this.ddCountry, "ddCountry");
            this.ddCountry.Name = "ddCountry";
            // 
            // lblPais
            // 
            this.lblPais.Name = "lblPais";
            resources.ApplyResources(this.lblPais, "lblPais");
            // 
            // ddCliente
            // 
            this.ddCliente.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            resources.ApplyResources(this.ddCliente, "ddCliente");
            this.ddCliente.Name = "ddCliente";
            // 
            // lblCliente
            // 
            this.lblCliente.Name = "lblCliente";
            resources.ApplyResources(this.lblCliente, "lblCliente");
            // 
            // btnBreak
            // 
            this.btnBreak.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnBreak.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            resources.ApplyResources(this.btnBreak, "btnBreak");
            this.btnBreak.Name = "btnBreak";
            this.btnBreak.Click += new System.EventHandler(this.btnBreak_Click);
            // 
            // btnLunch
            // 
            this.btnLunch.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnLunch.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            resources.ApplyResources(this.btnLunch, "btnLunch");
            this.btnLunch.Name = "btnLunch";
            this.btnLunch.Click += new System.EventHandler(this.btnLunch_Click);
            // 
            // timerBreak
            // 
            this.timerBreak.Interval = 1000;
            this.timerBreak.Tick += new System.EventHandler(this.timerBreak_Tick);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Principal
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Principal";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Shown += new System.EventHandler(this.Principal_Shown);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripMenuItem archivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem herramientasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem auxiliaresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem administraci�nToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ayudaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem acercaDeToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.Timer timerLunch;
        private System.Windows.Forms.ToolStripMenuItem opcionesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem locaci�nRemotaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem banamexSantanderToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem configuraci�nToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem globalScoreToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem administraci�nDeTiempoToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripDropDownButton ddCountry;
        //private Genworth_TIMES.Controles.ToolStripDropDownButtonUser ddCountry;
        private System.Windows.Forms.ToolStripDropDownButton ddCliente;
        private System.Windows.Forms.ToolStripLabel lblPais;
        private System.Windows.Forms.ToolStripLabel lblCliente;
        private System.Windows.Forms.ToolStripButton btnBreak;
        private System.Windows.Forms.ToolStripButton btnLunch;
        private System.Windows.Forms.Timer timerBreak;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Timer timer1;
    }
}

