using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Objetos;
using Genworth_TIMES.Properties;

namespace Genworth_TIMES {
    public partial class Configuracion : Form {
        private bool _textchanged = false;

        private Usuario m_CurrentUser = new Usuario();
        public Configuracion(Usuario User) {
            InitializeComponent();
            m_CurrentUser = User;
            if (m_CurrentUser.Admin == 1) {
                this.LeerCadenaConexionLocal();
                this.LeerCadenaConexionRemota();
            } else {
                if (MessageBox.Show("No tienes permisos para acceder a esta secci�n", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error) == DialogResult.OK) {
                    this.Close();
                }
            }
        }

        public Configuracion() {
            InitializeComponent();
            string abc = Settings.Default.ConnectionString;
            this.textBox1.Text = abc;
        }

        private void LeerCadenaConexionLocal() {
            this.textBox1.Text = Settings.Default.ConnectionString;
        }

        private void LeerCadenaConexionRemota() {
            this.textBox2.Text = Settings.Default.ConnectionProd1;
        }

        private void saveToolStripButton_Click(object sender, EventArgs e) {
            Settings.Default.ConnectionString = this.textBox1.Text;
            Settings.Default.Save();
            _textchanged = false;
        }

        private void textBox1_TextChanged(object sender, EventArgs e) {
            _textchanged = true;
        }

        protected override void OnClosing(CancelEventArgs e) {
            if (_textchanged) {
                if (MessageBox.Show("�Desea guardar los cambios?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) {
                    this.saveToolStripButton_Click(new object(), EventArgs.Empty);
                }
            }
            base.OnClosing(e);
        }

        private void button1_Click(object sender, EventArgs e) {
            this.saveToolStripButton_Click(sender, e);
            _textchanged = false;
            this.Close();
        }
    }
}