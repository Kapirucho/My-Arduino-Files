﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Objetos;
using Genworth_TIMES.DataBase;

namespace Genworth_TIMES.Formas
{
    public partial class Credenciales : Form
    {
        public delegate void pasar(Boolean dato);
        public event pasar pasado;
        
        public Credenciales()
        {
            InitializeComponent();
            
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            Secure Sec = new Secure();
            TimesDA t = new TimesDA();
            int i = t.ValidarSupervisor(textBox1.Text);
            
            if(Sec.LogonUser(textBox1.Text, textBox2.Text) && i >= 1)
            {
                pasado(true);
            }
            else
            {
                pasado(false);
            }
            
            this.Dispose();

        }

        private void Credenciales_Load(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Visible = false;
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            toolStripStatusLabel1.Visible = true;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

      
    }
}
