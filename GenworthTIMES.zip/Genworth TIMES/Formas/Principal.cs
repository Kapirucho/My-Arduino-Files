using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Objetos;
using Genworth_TIMES.Properties;
using System.Threading;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Configuration;
using System.Data.SqlClient;
using System.Diagnostics;
using Genworth_TIMES.Clase;
using Genworth_TIMES.DataBase.TimeDataTableAdapters;

namespace Genworth_TIMES {

    public partial class Principal : Form {

        public GlobalValues _GlobalValues = null;
        public MiCatalogo _Catalogo = null;

        private Usuario _Current_User = null;
        private Acciones _Acciones = null;
        private Tipos _Tipos = null;
        private Usuarios _Usuarios = null;

        private ComponentResourceManager resources = new ComponentResourceManager(typeof(Principal));

        /// <summary>
        /// Contructor, pass all objects needed to avoid reload
        /// </summary>
        /// <param name="Usr">Current user data</param>
        /// <param name="Acc">Action object</param>
        /// <param name="Tps">Type of general connection data</param>
        /// <param name="Usrs">General users data</param>
        public Principal(Usuario Usr, Acciones Acc, Tipos Tps, Usuarios Usrs) {
            InitializeComponent();
            _Current_User = Usr;
            _Acciones = Acc;
            _Tipos = Tps;
            _Usuarios = Usrs;
            _GlobalValues = new GlobalValues();

            //obtenemos la coneccion, la cadena que modifica es ConnDevelopment en propiedades del proyecto
            string conStr = ConfigurationManager.ConnectionStrings["Genworth_TIMES.Properties.Settings.MXOSPRODConnectionString"].ConnectionString;
            
            //solo identificamos el server al que se conecta
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(conStr);

            string based = string.Empty;

            //obtenemos el servidor al cual nos conectamos
            switch (builder.DataSource) {
                case "AP003ALEO":
                    this.ChangeFormColor(Color.Orange);
                    based = " TEST DB - Le�n Server AP003ALEO";
                    break;
                case "DP0016ASHA":
                    based = " PROD DB - Shannon Server DP0016ASHA";
                    break;
            }
            this.Name = based;

            MessageBox.Show("Current DB : " + based);

            //this.InitCatalog();
            this.InitMenu();

            //Actualizamos nombre de la forma
            this.Text = "Time Track  - " + this.Name;
        }

        /// <summary>
        /// DEPRECATED
        /// </summary>
        private void InitCatalog()
        {
            //this._Catalogo. = new DataBase.TimesDA().CatalogColection();
        }

        /// <summary>
        /// Initialize menu add items
        /// </summary>
        private void InitMenu()
        {
            
            DataBase.TimesDA td = new DataBase.TimesDA();
            int cc = 0;
            foreach (string[] a in td.SelectCatalog(1))
            {
                this.ddCountry.DropDownItems.Add(a[0]);
                this.ddCountry.DropDownItems[cc].Tag = a[1];
                cc++;
            }
            
            this.ddCountry.DropDownItemClicked += new ToolStripItemClickedEventHandler(DropDownItemClick);

            this._GlobalValues.Documents = td.SelectCatalog(2);
        }

        /// <summary>
        /// Initiate drop down click for all the element created on the "fly"
        /// All the elements from database will be listed and displayed on demand
        /// </summary>
        /// <param name="sender">Empty</param>
        /// <param name="e">empty</param>
        void DropDownItemClick(object sender, ToolStripItemClickedEventArgs e)
        {
            this.lblPais.Text = e.ClickedItem.Text;
            this._GlobalValues.Country = e.ClickedItem.Text;

            this.lblCliente.Text = "Seleccione un cliente";
            this._GlobalValues.Client = string.Empty;

            DataBase.TimesDA td = new DataBase.TimesDA();

            int cc = 0;
            if (this.ddCliente.DropDownItems.Count > 0)
            {
                this.ddCliente.DropDownItems.Clear();
            }

            foreach (string[] a in td.SelectClient(int.Parse(e.ClickedItem.Tag.ToString())))
            {
                this.ddCliente.DropDownItems.Add(a[0]);
                this.ddCliente.DropDownItems[cc].Tag = a[1];
                cc++;
            }
            this.ddCliente.DropDownItemClicked += new ToolStripItemClickedEventHandler(DropDownItemClienteClick);
        }

        /// <summary>
        /// Call the method checking if the specified form is already open
        /// </summary>
        /// <param name="sender">Empty</param>
        /// <param name="e">Empty</param>
        void DropDownItemClienteClick(object sender, ToolStripItemClickedEventArgs e)
        {
            this.lblCliente.Text = e.ClickedItem.Text;
            this._GlobalValues.Client = e.ClickedItem.Text;

            if (this.FormaAbierta("Auxiliar"))
            {
                this.MdiChildren[this.index_form].Close();
                this.auxiliaresToolStripMenuItem_Click(new object(), EventArgs.Empty);
            }
        }

        /// <summary>
        /// DEPRECATED
        /// </summary>
        private void FillClientMenu()
        {
            DataBase.TimesDA td = new DataBase.TimesDA();
        }

        MdiClient ctlMdi;
        /// <summary>
        /// Change parent form color to show database connection
        /// Debugger hidden
        /// </summary>
        /// <param name="Cl">Color</param>
        [DebuggerHidden()]
        private void ChangeFormColor(Color Cl) {
            foreach (Control ctl in this.Controls) {
                try {
                    ctlMdi = (MdiClient)ctl;
                    ctlMdi.BackColor = Cl;
                } catch { }
            }
        }


        private bool Cerrar = true;
        /// <summary>
        /// Handle unexpected form closing
        /// </summary>
        /// <param name="e">empty</param>
        protected override void OnFormClosing(FormClosingEventArgs e) {
            e.Cancel = Cerrar;
            base.OnFormClosing(e);
        }

        /// <summary>
        /// Manage logout, no logout can be possible if any form is open
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void logoutToolStripMenuItem_Click(object sender, EventArgs e) {
            if (MessageBox.Show("�Deseas salir de la aplicaci�n?", "Info", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK) {
                if (this.MdiChildren.Length > 0) {
                    foreach (Form f in this.MdiChildren) {
                        MessageBox.Show(new StringBuilder().AppendFormat("Primero cierre correctamente: ", f.Text).ToString());
                    }
                } else {
                    Cerrar = false;
                    this.Close();
                }
            }
        }

        /// <summary>
        /// about box
        /// </summary>
        /// <param name="sender">empty</param>
        /// <param name="e">empty</param>
        private void acercaDeToolStripMenuItem_Click(object sender, EventArgs e) {
            AboutBox1 ab = new AboutBox1();
            ab.ShowDialog();
        }

        private void administraci�nToolStripMenuItem_Click(object sender, EventArgs e) {
            if (_Current_User.Admin != 1) {
                MessageBox.Show(resources.GetString("MsgUno"), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (this.FormaAbierta("Supervision")) { return; }
            Form sup = new Supervision(_Current_User, _Acciones, _Tipos, _Usuarios);
            sup.MdiParent = this;
            sup.Show();
        }

        private AutoUpdate au = new AutoUpdate();
        private void toolStripStatusLabel1_DoubleClick(object sender, EventArgs e) {
            DialogResult dr = MessageBox.Show(resources.GetString("MsgSave"), "Info", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (dr == DialogResult.OK) {
                au.DoUpdate();
            }
        }

        private int cou = 0;
        private void timer1_Tick(object sender, EventArgs e) {
            cou += 1;
            if (cou == 3600) {
                cou = 0;
                au.FindUpdate();
                toolStripStatusLabel1.Text = au.Mensaje;
            }
        }

        private void Form1_Load(object sender, EventArgs e) {
            if (Settings.Default.RemoteLocation) {
                locaci�nRemotaToolStripMenuItem.Checked = true;
                locaci�nRemotaToolStripMenuItem.CheckState = CheckState.Checked;
            } else {
                locaci�nRemotaToolStripMenuItem.Checked = false;
                locaci�nRemotaToolStripMenuItem.CheckState = CheckState.Unchecked;
            }
        }

        private void locaci�nRemotaToolStripMenuItem_Click(object sender, EventArgs e) {
            Settings.Default.RemoteLocation = locaci�nRemotaToolStripMenuItem.Checked;
            Settings.Default.Save();
        }

        public Auxiliar aux;
        private void auxiliaresToolStripMenuItem_Click(object sender, EventArgs e) {
            if (this.FormaAbierta("Auxiliar")) { return; }
            if (_GlobalValues.Client == string.Empty || _GlobalValues.Country == string.Empty)
            {
                MessageBox.Show("Favor de seleccionar un pa�s y cliente");
                return;
            }
            aux = new Auxiliar(_Current_User, _Acciones, _Tipos, Auxiliar.Actividad.Local, this._GlobalValues);
            aux.MdiParent = this;
            aux.Show();
        }

        private void banamexSantanderToolStripMenuItem_Click(object sender, EventArgs e) {
            if (this.FormaAbierta("Inplant")) { return; }
            Form aux = new Auxiliar(_Current_User, _Acciones, _Tipos, Auxiliar.Actividad.Inplant, new GlobalValues());
            aux.MdiParent = this;
            aux.Show();
        }

        private void configuraci�nToolStripMenuItem_Click(object sender, EventArgs e) {
            if (this.FormaAbierta("Configuracion")) { return; }
            Form config = new Configuracion(_Current_User);
            config.MdiParent = this;
            config.Show();
        }

        int index_form = -1;
        private bool FormaAbierta(String FormName) {
            foreach (Form f in this.MdiChildren) {
                if (f.Name == FormName) {
                    f.Focus();
                    index_form = Array.IndexOf(this.MdiChildren, f);
                    return true;
                }
            }
            return false;
        }

        private void globalScoreToolStripMenuItem_Click(object sender, EventArgs e) {
            //if (this.FormaAbierta("Configuracion")) { return; }
            Formas.MyGlobalScore gb = new Formas.MyGlobalScore(_Current_User);
            gb.MdiParent = this;
            gb.Show();
        }

        private void administraci�nDeTiempoToolStripMenuItem_Click(object sender, EventArgs e) {
            if (this.FormaAbierta("Administraci�n del tiempo")) { return; }
            Form aux = new Auxiliar(_Current_User, _Acciones, _Tipos, Auxiliar.Actividad.Admin, this._GlobalValues);
            aux.MdiParent = this;
            aux.Show();
        }

        //Actualizamos el nombre de la forma principal para mostrar el server conectado
        private void Principal_Shown(object sender, EventArgs e) {
            //Actualizamos nombre de la forma
            this.Text = "Time Track - " + this.Name;
        }

        private void timerLunch_Tick(object sender, EventArgs e)
        {
            this.btnLunch.Text = "Lunch: " + this.swLunch.Elapsed.ToString(@"mm\:ss");
        }


        Stopwatch swLunch = new Stopwatch();
        private void btnLunch_Click(object sender, EventArgs e)
        {
            if (swBreak.IsRunning)
            {
                timerBreak.Stop();
                swBreak.Stop();
            }

            if (swLunch.IsRunning)
            {
                swLunch.Stop();
                timerLunch.Stop();
                this.ManageRetardos();
            }
            else
            {
                if (this.FormaAbierta("Auxiliar"))
                {
                    this.aux.boton1_Click(new Boton(Boton.Tips.Lunch), EventArgs.Empty);
                }
                timerLunch.Start();
                swLunch.Start();
                if (MessageBox.Show("�Termina Lunch?", "Pregunta", MessageBoxButtons.OK) == System.Windows.Forms.DialogResult.OK)
                {
                    this.btnLunch_Click(new object(), EventArgs.Empty);
                }
            }
        }

        
        private void timerBreak_Tick(object sender, EventArgs e)
        {
            this.btnBreak.Text = "Break: " + this.swBreak.Elapsed.ToString(@"mm\:ss");
        }

        Stopwatch swBreak = new Stopwatch();
        private void btnBreak_Click(object sender, EventArgs e)
        {
            if (swLunch.IsRunning)
            {
                swLunch.Stop();
                timerLunch.Stop();
            }

            if (swBreak.IsRunning)
            {
                timerBreak.Stop();
                swBreak.Stop();
                this.ManageRetardos();
            }
            else
            {
                if (this.FormaAbierta("Auxiliar"))
                {
                    this.aux.boton1_Click(new Boton(Boton.Tips.Break), EventArgs.Empty);
                }
                timerBreak.Start();
                swBreak.Start();
                if (MessageBox.Show("�Termina Break?", "Pregunta", MessageBoxButtons.OK) == System.Windows.Forms.DialogResult.OK)
                {
                    this.btnBreak_Click(new object(), EventArgs.Empty);
                }
            }
        }

        private void ManageRetardos()
        {
            int retardos = 0;
            int retardosl = 0;

            if (swBreak.Elapsed.TotalSeconds > 1800)
            {
                retardosl = (int)swBreak.Elapsed.TotalSeconds;

                retardosl -= 1800;

                if ((retardosl = retardosl / 300) > 0)
                {
                    try
                    {
                        new TIME_FLEX_DATATableAdapter().Insert(int.Parse(_Current_User.Id.ToString()),
                                                                "Retardo",
                                                                "", "", "", "", "", "", "", "", "", "",
                                                                DateTime.Now, DateTime.Now, DateTime.Now,
                                                                DateTime.Now, DateTime.Now, 0, 0, 0, 0, 0,
                                                                decimal.Parse(retardos.ToString()), 0, 0, 0, 0);
                    }
                    catch (Exception Ex)
                    {
                        MessageBox.Show("Se produjo un error: " + Ex.Message);
                    }
                }
            }

            if (swLunch.Elapsed.TotalSeconds > 1800 && swLunch.Elapsed.TotalSeconds < 3600 &&
                (_Current_User.Id == 4 || _Current_User.Id == 11))
            {
                retardosl = (int)swLunch.Elapsed.TotalSeconds;

                retardosl -= 1800;

                if ((retardosl = retardosl / 300) > 0)
                {
                    try
                    {
                        new TIME_FLEX_DATATableAdapter().Insert(int.Parse(_Current_User.Id.ToString()),
                                                                "Retardo",
                                                                "", "", "", "", "", "", "", "", "", "",
                                                                DateTime.Now, DateTime.Now, DateTime.Now,
                                                                DateTime.Now, DateTime.Now, 0, 0, 0, 0, 0,
                                                                decimal.Parse(retardosl.ToString()), 0, 0, 0, 0);
                    }
                    catch (Exception Ex)
                    {
                        MessageBox.Show("Se produjo un error: " + Ex.Message);
                    }
                }
            }
            else if (swLunch.Elapsed.TotalSeconds > 3600 && (_Current_User.Id != 4 || _Current_User.Id != 11))
            {
                retardosl = (int)swLunch.Elapsed.TotalSeconds;

                retardosl -= 3600;

                if ((retardosl = retardosl / 300) > 0)
                {
                    try
                    {
                        new TIME_FLEX_DATATableAdapter().Insert(int.Parse(_Current_User.Id.ToString()),
                                                                "Retardo",
                                                                "", "", "", "", "", "", "", "", "", "",
                                                                DateTime.Now, DateTime.Now, DateTime.Now,
                                                                DateTime.Now, DateTime.Now, 0, 0, 0, 0, 0,
                                                                decimal.Parse(retardosl.ToString()), 0, 0, 0, 0);
                    }
                    catch (Exception Ex)
                    {
                        MessageBox.Show("Se produjo un error: " + Ex.Message);
                    }
                }
            }
        }
    }
}