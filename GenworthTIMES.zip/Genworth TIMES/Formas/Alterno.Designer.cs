namespace Genworth_TIMES
{
    /// <summary>
    /// DEPRECATED
    /// </summary>
    partial class Alterno
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Alterno));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.boton17 = new Genworth_TIMES.Boton();
            this.boton1 = new Genworth_TIMES.Boton();
            this.boton8 = new Genworth_TIMES.Boton();
            this.boton2 = new Genworth_TIMES.Boton();
            this.boton7 = new Genworth_TIMES.Boton();
            this.boton3 = new Genworth_TIMES.Boton();
            this.boton6 = new Genworth_TIMES.Boton();
            this.boton4 = new Genworth_TIMES.Boton();
            this.boton5 = new Genworth_TIMES.Boton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.boton15 = new Genworth_TIMES.Boton();
            this.boton14 = new Genworth_TIMES.Boton();
            this.boton20 = new Genworth_TIMES.Boton();
            this.boton19 = new Genworth_TIMES.Boton();
            this.boton12 = new Genworth_TIMES.Boton();
            this.boton10 = new Genworth_TIMES.Boton();
            this.boton9 = new Genworth_TIMES.Boton();
            this.boton11 = new Genworth_TIMES.Boton();
            this.boton13 = new Genworth_TIMES.Boton();
            this.boton16 = new Genworth_TIMES.Boton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblTimer = new System.Windows.Forms.Label();
            this.lblTranscurrido = new System.Windows.Forms.Label();
            this.lblInicio = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblTarea = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.boton17);
            this.groupBox1.Controls.Add(this.boton1);
            this.groupBox1.Controls.Add(this.boton8);
            this.groupBox1.Controls.Add(this.boton2);
            this.groupBox1.Controls.Add(this.boton7);
            this.groupBox1.Controls.Add(this.boton3);
            this.groupBox1.Controls.Add(this.boton6);
            this.groupBox1.Controls.Add(this.boton4);
            this.groupBox1.Controls.Add(this.boton5);
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // boton17
            // 
            resources.ApplyResources(this.boton17, "boton17");
            this.boton17.Name = "boton17";
            this.boton17.p_Accion = null;
            this.boton17.p_Descripcion = false;
            this.boton17.p_MaxTimeElapsed = 0;
            this.boton17.p_Tip = Genworth_TIMES.Boton.Tips.DHL;
            this.boton17.p_Tipos = null;
            this.boton17.p_ToolTip = "";
            this.boton17.Click += new System.EventHandler(this.boton1_Click);
            // 
            // boton1
            // 
            resources.ApplyResources(this.boton1, "boton1");
            this.boton1.Name = "boton1";
            this.boton1.p_Accion = null;
            this.boton1.p_Descripcion = false;
            this.boton1.p_MaxTimeElapsed = 30;
            this.boton1.p_Tip = Genworth_TIMES.Boton.Tips.Break;
            this.boton1.p_Tipos = null;
            this.boton1.p_ToolTip = "";
            this.boton1.Click += new System.EventHandler(this.boton1_Click);
            // 
            // boton8
            // 
            resources.ApplyResources(this.boton8, "boton8");
            this.boton8.Name = "boton8";
            this.boton8.p_Accion = null;
            this.boton8.p_Descripcion = true;
            this.boton8.p_MaxTimeElapsed = 0;
            this.boton8.p_Tip = Genworth_TIMES.Boton.Tips.NonBusiness;
            this.boton8.p_Tipos = null;
            this.boton8.p_ToolTip = "";
            this.boton8.Click += new System.EventHandler(this.boton1_Click);
            // 
            // boton2
            // 
            resources.ApplyResources(this.boton2, "boton2");
            this.boton2.Name = "boton2";
            this.boton2.p_Accion = null;
            this.boton2.p_Descripcion = false;
            this.boton2.p_MaxTimeElapsed = 30;
            this.boton2.p_Tip = Genworth_TIMES.Boton.Tips.Lunch;
            this.boton2.p_Tipos = null;
            this.boton2.p_ToolTip = "";
            this.boton2.Click += new System.EventHandler(this.boton1_Click);
            // 
            // boton7
            // 
            resources.ApplyResources(this.boton7, "boton7");
            this.boton7.Name = "boton7";
            this.boton7.p_Accion = null;
            this.boton7.p_Descripcion = false;
            this.boton7.p_MaxTimeElapsed = 0;
            this.boton7.p_Tip = Genworth_TIMES.Boton.Tips.Support;
            this.boton7.p_Tipos = null;
            this.boton7.p_ToolTip = "";
            this.boton7.Click += new System.EventHandler(this.boton1_Click);
            // 
            // boton3
            // 
            resources.ApplyResources(this.boton3, "boton3");
            this.boton3.Name = "boton3";
            this.boton3.p_Accion = null;
            this.boton3.p_Descripcion = false;
            this.boton3.p_MaxTimeElapsed = 0;
            this.boton3.p_Tip = Genworth_TIMES.Boton.Tips.Training;
            this.boton3.p_Tipos = null;
            this.boton3.p_ToolTip = "";
            this.boton3.Click += new System.EventHandler(this.boton1_Click);
            // 
            // boton6
            // 
            resources.ApplyResources(this.boton6, "boton6");
            this.boton6.Name = "boton6";
            this.boton6.p_Accion = null;
            this.boton6.p_Descripcion = true;
            this.boton6.p_MaxTimeElapsed = 0;
            this.boton6.p_Tip = Genworth_TIMES.Boton.Tips.Aditional;
            this.boton6.p_Tipos = null;
            this.boton6.p_ToolTip = "";
            this.boton6.Click += new System.EventHandler(this.boton1_Click);
            // 
            // boton4
            // 
            resources.ApplyResources(this.boton4, "boton4");
            this.boton4.Name = "boton4";
            this.boton4.p_Accion = null;
            this.boton4.p_Descripcion = true;
            this.boton4.p_MaxTimeElapsed = 0;
            this.boton4.p_Tip = Genworth_TIMES.Boton.Tips.Feedback;
            this.boton4.p_Tipos = null;
            this.boton4.p_ToolTip = "";
            this.boton4.Click += new System.EventHandler(this.boton1_Click);
            // 
            // boton5
            // 
            resources.ApplyResources(this.boton5, "boton5");
            this.boton5.Name = "boton5";
            this.boton5.p_Accion = null;
            this.boton5.p_Descripcion = true;
            this.boton5.p_MaxTimeElapsed = 0;
            this.boton5.p_Tip = Genworth_TIMES.Boton.Tips.Meeting;
            this.boton5.p_Tipos = null;
            this.boton5.p_ToolTip = "";
            this.boton5.Click += new System.EventHandler(this.boton1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.boton15);
            this.groupBox2.Controls.Add(this.boton14);
            this.groupBox2.Controls.Add(this.boton20);
            this.groupBox2.Controls.Add(this.boton19);
            this.groupBox2.Controls.Add(this.boton12);
            this.groupBox2.Controls.Add(this.boton10);
            this.groupBox2.Controls.Add(this.boton9);
            this.groupBox2.Controls.Add(this.boton11);
            this.groupBox2.Controls.Add(this.boton13);
            this.groupBox2.Controls.Add(this.boton16);
            resources.ApplyResources(this.groupBox2, "groupBox2");
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.TabStop = false;
            // 
            // boton15
            // 
            resources.ApplyResources(this.boton15, "boton15");
            this.boton15.Name = "boton15";
            this.boton15.p_Accion = null;
            this.boton15.p_Descripcion = false;
            this.boton15.p_MaxTimeElapsed = 0;
            this.boton15.p_Tip = Genworth_TIMES.Boton.Tips.AtencionAsegurados;
            this.boton15.p_Tipos = null;
            this.boton15.p_ToolTip = "";
            this.boton15.Click += new System.EventHandler(this.boton1_Click);
            // 
            // boton14
            // 
            resources.ApplyResources(this.boton14, "boton14");
            this.boton14.Name = "boton14";
            this.boton14.p_Accion = null;
            this.boton14.p_Descripcion = false;
            this.boton14.p_MaxTimeElapsed = 0;
            this.boton14.p_Tip = Genworth_TIMES.Boton.Tips.AtencionAreaSiniestros;
            this.boton14.p_Tipos = null;
            this.boton14.p_ToolTip = "";
            this.boton14.Click += new System.EventHandler(this.boton1_Click);
            // 
            // boton20
            // 
            resources.ApplyResources(this.boton20, "boton20");
            this.boton20.Name = "boton20";
            this.boton20.p_Accion = null;
            this.boton20.p_Descripcion = false;
            this.boton20.p_MaxTimeElapsed = 0;
            this.boton20.p_Tip = Genworth_TIMES.Boton.Tips.AtencionAreaLegal;
            this.boton20.p_Tipos = null;
            this.boton20.p_ToolTip = "";
            this.boton20.Click += new System.EventHandler(this.boton1_Click);
            // 
            // boton19
            // 
            resources.ApplyResources(this.boton19, "boton19");
            this.boton19.Name = "boton19";
            this.boton19.p_Accion = null;
            this.boton19.p_Descripcion = false;
            this.boton19.p_MaxTimeElapsed = 0;
            this.boton19.p_Tip = Genworth_TIMES.Boton.Tips.Seguimiento;
            this.boton19.p_Tipos = null;
            this.boton19.p_ToolTip = "";
            this.boton19.Click += new System.EventHandler(this.boton1_Click);
            // 
            // boton12
            // 
            resources.ApplyResources(this.boton12, "boton12");
            this.boton12.Name = "boton12";
            this.boton12.p_Accion = null;
            this.boton12.p_Descripcion = false;
            this.boton12.p_MaxTimeElapsed = 0;
            this.boton12.p_Tip = Genworth_TIMES.Boton.Tips.EnEspera;
            this.boton12.p_Tipos = null;
            this.boton12.p_ToolTip = "";
            this.boton12.Load += new System.EventHandler(this.boton12_Load);
            this.boton12.Click += new System.EventHandler(this.boton1_Click);
            // 
            // boton10
            // 
            resources.ApplyResources(this.boton10, "boton10");
            this.boton10.Name = "boton10";
            this.boton10.p_Accion = null;
            this.boton10.p_Descripcion = false;
            this.boton10.p_MaxTimeElapsed = 0;
            this.boton10.p_Tip = Genworth_TIMES.Boton.Tips.RegistroSistemaCliente;
            this.boton10.p_Tipos = null;
            this.boton10.p_ToolTip = "";
            this.boton10.Click += new System.EventHandler(this.boton1_Click);
            // 
            // boton9
            // 
            resources.ApplyResources(this.boton9, "boton9");
            this.boton9.Name = "boton9";
            this.boton9.p_Accion = null;
            this.boton9.p_Descripcion = false;
            this.boton9.p_MaxTimeElapsed = 0;
            this.boton9.p_Tip = Genworth_TIMES.Boton.Tips.AnalisisBanamex;
            this.boton9.p_Tipos = null;
            this.boton9.p_ToolTip = "";
            this.boton9.Click += new System.EventHandler(this.boton1_Click);
            // 
            // boton11
            // 
            resources.ApplyResources(this.boton11, "boton11");
            this.boton11.Name = "boton11";
            this.boton11.p_Accion = null;
            this.boton11.p_Descripcion = false;
            this.boton11.p_MaxTimeElapsed = 0;
            this.boton11.p_Tip = Genworth_TIMES.Boton.Tips.AnalisisSantander;
            this.boton11.p_Tipos = null;
            this.boton11.p_ToolTip = "";
            this.boton11.Click += new System.EventHandler(this.boton1_Click);
            // 
            // boton13
            // 
            resources.ApplyResources(this.boton13, "boton13");
            this.boton13.Name = "boton13";
            this.boton13.p_Accion = null;
            this.boton13.p_Descripcion = false;
            this.boton13.p_MaxTimeElapsed = 4;
            this.boton13.p_Tip = Genworth_TIMES.Boton.Tips.Reclamacion_Subsecuente;
            this.boton13.p_Tipos = null;
            this.boton13.p_ToolTip = "";
            this.boton13.Click += new System.EventHandler(this.boton1_Click);
            // 
            // boton16
            // 
            resources.ApplyResources(this.boton16, "boton16");
            this.boton16.Name = "boton16";
            this.boton16.p_Accion = null;
            this.boton16.p_Descripcion = false;
            this.boton16.p_MaxTimeElapsed = 0;
            this.boton16.p_Tip = Genworth_TIMES.Boton.Tips.PhoneIn;
            this.boton16.p_Tipos = null;
            this.boton16.p_ToolTip = "";
            this.boton16.Click += new System.EventHandler(this.boton1_Click);
            // 
            // groupBox3
            // 
            resources.ApplyResources(this.groupBox3, "groupBox3");
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.lblTimer);
            this.groupBox3.Controls.Add(this.lblTranscurrido);
            this.groupBox3.Controls.Add(this.lblInicio);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.lblTarea);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.TabStop = false;
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // lblTimer
            // 
            resources.ApplyResources(this.lblTimer, "lblTimer");
            this.lblTimer.Name = "lblTimer";
            // 
            // lblTranscurrido
            // 
            resources.ApplyResources(this.lblTranscurrido, "lblTranscurrido");
            this.lblTranscurrido.Name = "lblTranscurrido";
            // 
            // lblInicio
            // 
            resources.ApplyResources(this.lblInicio, "lblInicio");
            this.lblInicio.Name = "lblInicio";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // lblTarea
            // 
            resources.ApplyResources(this.lblTarea, "lblTarea");
            this.lblTarea.Name = "lblTarea";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // notifyIcon1
            // 
            resources.ApplyResources(this.notifyIcon1, "notifyIcon1");
            // 
            // Alterno
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Alterno";
            this.ShowIcon = false;
            this.Load += new System.EventHandler(this.Auxiliar_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Boton boton1;
        private Boton boton2;
        private Boton boton3;
        private Boton boton4;
        private Boton boton5;
        private Boton boton6;
        private Boton boton7;
        private Boton boton8;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private Boton boton11;
        private Boton boton13;
        private Boton boton16;
        private Boton boton9;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTarea;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblInicio;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblTranscurrido;
        private System.Windows.Forms.Label lblTimer;
        private Boton boton10;
        private Boton boton12;
        private Boton boton17;
        private Boton boton19;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private Boton boton20;
        private Boton boton15;
        private Boton boton14;
        private System.Windows.Forms.NotifyIcon notifyIcon1;

    }
}