using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using Objetos;
using Genworth_TIMES.DataBase.TimeDataTableAdapters;

namespace Genworth_TIMES
{
    public partial class Alterno : Form
    {
        private Stopwatch sw = new Stopwatch();
        private Usuario _Current_User = new Usuario();// = null;
        private Acciones _Acciones = new Acciones(); // = null;
        private Tipos _Tipos = new Tipos();// null;

        private Registros _Current = new Registros();

        private Baloon bl = new Baloon();

		public Alterno(Usuario Usr, Acciones Acc, Tipos Tps)
        {
            _Current_User = Usr;
            _Acciones = Acc;
            _Tipos = Tps;
            InitializeComponent();
            this.notifyIcon1.Icon = global::Genworth_TIMES.Properties.Resources._1253933144_system_users;
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.Text = "GNW Time Tracker - Auxiliares";
            
            //this.Asignacion();
        }

        private void Asignacion()
        {
            foreach (Control ctl in groupBox1.Controls)
            {
                if (ctl is Boton)
                {
                    ((Boton)ctl).p_Accion = _Acciones;
                    ((Boton)ctl).p_Tipos = _Tipos;
                }
            }

            foreach (Control ctl in groupBox2.Controls)
            {
                if (ctl is Boton)
                {
                    ((Boton)ctl).p_Accion = _Acciones;
                    ((Boton)ctl).p_Tipos = _Tipos;
                }
            }
        }

        private bool _baloonSent = false;
        private void timer1_Tick(object sender, EventArgs e)
        {
            lblTimer.Text = sw.Elapsed.Hours.ToString() + ":" + sw.Elapsed.Minutes.ToString() + ":" + sw.Elapsed.Seconds.ToString();
            label5.Text = _SW_Break.Elapsed.Hours.ToString()
                          + ":" + _SW_Break.Elapsed.Minutes.ToString()
                          + ":" + _SW_Break.Elapsed.Seconds.ToString();
            label6.Text = _SW_Lunch.Elapsed.Hours.ToString()
                          + ":" + _SW_Lunch.Elapsed.Minutes.ToString()
                          + ":" + _SW_Lunch.Elapsed.Seconds.ToString();

            if (_Acciones.MaxElapsed != 0 && sw.Elapsed.Minutes != 0)
            {
                if (sw.Elapsed.Minutes >= _Acciones.MaxElapsed - 1 && sw.Elapsed.Minutes < _Acciones.MaxElapsed && _Acciones.MaxElapsed != 0)
                {
                    if ((this.sw.Elapsed.Seconds % 2) == 0)
                    {
                        lblTimer.ForeColor = Color.OrangeRed;
                    }
                    else
                    {
                        lblTimer.ForeColor = Color.Black;
                    }
                }
                else if (sw.Elapsed.Minutes >= _Acciones.MaxElapsed && _Acciones.MaxElapsed != 0)
                {
                    if ((this.sw.Elapsed.Seconds % 2) == 0)
                    {
                        lblTimer.ForeColor = Color.Red;
                    }
                    else
                    {
                        lblTimer.ForeColor = Color.Black;
                    }

                    if (!_baloonSent)
                    {
                        _baloonSent = true;
                        //this.notifyIcon1.ShowBalloonTip(20000, "Aviso!", "El tiempo recomendado para la tarea: " + _Acciones.Nombre + " fue superado!", ToolTipIcon.Warning);
                        bl = new Baloon();
                        bl.Mostrar("Aviso!", "El tiempo recomendado para la tarea: " + _Acciones.Nombre + " fue superado!");
                    }
                }
                else
                {
                    lblTimer.ForeColor = Color.Black;
                    _baloonSent = false;
                }
            }
            else
            {
                lblTimer.ForeColor = Color.Black;
                if (_baloonSent)
                {
                    _baloonSent = false;
                }
            }
        }

        Stopwatch _SW_Break = new Stopwatch();
        Stopwatch _SW_Lunch = new Stopwatch();
        private void boton1_Click(object sender, EventArgs e)
        {
            sw.Stop();
            //**********************************************
            _Acciones.Obtener(((Boton)sender).p_Texto);
            _Tipos.Obtener(_Acciones.Tipo);
            if (_Acciones.Nombre == "Break")
            {
                _SW_Break.Start();
                _SW_Lunch.Stop();
            }
            else if (_Acciones.Nombre == "Lunch")
            {
                _SW_Lunch.Start();
                _SW_Break.Stop();
            }
            else
            {
                _SW_Break.Stop();
                _SW_Lunch.Stop();
            }
            //**********************************************
            if (sw.Elapsed.TotalSeconds > 0)
            {
                _Current.Final = _Current.Inicio.Add(sw.Elapsed);
                global::Genworth_TIMES.Comunes.AddRegistro(_Current.Accion,
                                                        _Current.Tipo,
                                                        _Current.Usuario,
                                                        _Current.Inicio,
                                                        _Current.Final,
                                                        _Current.Descripcion,
                                                        _Current.ClaimsNumber,
                                                        _Current.Document,
                                                        _Current.Country,
                                                        _Current.Client);
            }
            //***********************************************
            _Current = new Registros();
            _Current.Accion = _Acciones.Id;
            _Current.Inicio = DateTime.Now;
            _Current.Tipo = _Tipos.Id;
            _Current.Usuario = _Current_User.Id;

            //CurrentTableAdapter CTA = new CurrentTableAdapter();

            _Acciones.MaxElapsed = ((Boton)sender).p_MaxTimeElapsed;

            /*int res = CTA.UpdateQuery(_Current.Inicio, (int)_Current.Accion, _Current_User.Id, _Acciones.MaxElapsed);
            if (res == 0)
            {
                res = CTA.InsertQuery(_Current.Inicio, (int)_Current.Accion, _Current_User.Id, _Acciones.MaxElapsed);
            }*/

            Comunes.InsertOrUpdate(_Current.Inicio, (int)_Current.Accion, _Current_User.Id, _Acciones.MaxElapsed);

            sw.Reset();
            sw.Start();
            this.Asigna(((Boton)sender).p_Texto);

            if (((Boton)sender).p_Descripcion)
            {
                descripcion dsc = new descripcion();
                if (dsc.ShowDialog() == DialogResult.OK)
                {
                    _Current.Descripcion = dsc.Texto;
                }
            }
        }

        private void Asigna(String Ta)
        {
            lblTarea.Text = Ta;
            lblInicio.Text = _Current.Inicio.ToShortTimeString();// DateTime.Now.ToShortTimeString();
            lblTimer.Text = "0";
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            Form fcl = new Logout(_Acciones, _Tipos, _Current_User);
            if (fcl.ShowDialog() != DialogResult.OK)
            {
                e.Cancel = true;
                return;
            }
            sw.Stop();
            _Current.Final = _Current.Inicio.Add(sw.Elapsed);
            try
            {
                global::Genworth_TIMES.Comunes.AddRegistro(_Current.Accion,
                                                        _Current.Tipo,
                                                        _Current.Usuario,
                                                        _Current.Inicio,
                                                        _Current.Final,
                                                        _Current.Descripcion,
                                                        _Current.ClaimsNumber,
                                                        _Current.Document, _Current.Country, _Current.Client);
            }
            catch (Exception) { }
            base.OnFormClosing(e);
        }

        private void Auxiliar_Load(object sender, EventArgs e)
        {
            new TIME_REGISTROSTableAdapter().Insert(19, 2, _Current_User.Id, DateTime.Now, DateTime.Now, "", -1, string.Empty, string.Empty, string.Empty);
        }

        private void boton12_Load(object sender, EventArgs e)
        {

        }
    }
}