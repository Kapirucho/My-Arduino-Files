﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.IO;
using System.Xml.Linq;

namespace Genworth_TIMES.Formas
{
    public partial class ModeloPhin : Form
    {
        public ModeloPhin()
        {
            InitializeComponent();
            this.MinimumSize = this.Size;
            this.ReadXML();
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            if (MessageBox.Show("¿Desea reiniciar la presentación?", "Pregunta", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.OK)
            {
                this.m_des_main = 0;
                this.m_des_secn = 0;
                this.ReadXML();
                e.Cancel = true;
            }
            base.OnClosing(e);
        }

        private Color Header(int Main)
        {
            switch (Main)
            {
                case 0:
                    return Color.Orange;
                case 1:
                    return Color.MediumPurple;
                case 2:
                    return Color.Blue;
                case 3:
                    return Color.LawnGreen;
                case 4:
                    return Color.Red;
                case 5:
                    return Color.Gray;
                default:
                    return Color.Beige;
            }
        }

        private void AddItemLabel(string nombre, Tipo T)
        {
            this.table.RowCount = this.table.RowCount + 1;
            int row = this.table.RowStyles.Add(new RowStyle(SizeType.Percent));
            this.table.RowStyles[row].Height = 50;

            Label l = new Label();
            l.Dock = DockStyle.Fill;
            l.ForeColor = Color.Black;

            switch (T)
            {
                case Tipo.Seccion:
                    l.BackColor = this.Header(this.m_des_main);
                    l.Font = new Font(FontFamily.GenericSansSerif, 14.25f, FontStyle.Bold);
                    l.ForeColor = Color.White;
                    l.TextAlign = ContentAlignment.MiddleCenter;
                    break;
                case Tipo.Subtitulo:
                    l.BackColor = Color.Transparent;
                    l.TextAlign = ContentAlignment.MiddleLeft;
                    l.Font = new Font(FontFamily.GenericSansSerif, 12.25f);
                    break;
            }

            l.Text = nombre;
            l.Name = "l" + this.table.RowCount.ToString();

            this.table.Controls.Add(l, 0, this.table.RowCount - 1);
        }

        private int m_numero_botones = 0;
        private void AddItemButton(string nombre, List<int> destino, Tipo T)
        {
            this.table.RowCount = this.table.RowCount + 1;
            int row = this.table.RowStyles.Add(new RowStyle(SizeType.Percent));
            this.table.RowStyles[row].Height = 50;

            Button b = new Button();
            b.Dock = DockStyle.Fill;
            b.Font = new Font(FontFamily.GenericSansSerif, 16.25f, FontStyle.Bold);
            b.ForeColor = Color.White;

            switch (T)
            {
                case Tipo.Boton:
                    b.BackColor = this.Header(this.m_numero_botones);
                    b.TextAlign = ContentAlignment.MiddleCenter;
                    break;
                case Tipo.Siguiente:
                    b.BackColor = Color.Red;
                    break;
            }

            this.m_numero_botones++;

            if (this.m_numero_botones > 5)
            {
                this.m_numero_botones = 0;
            }
            
            b.Text = nombre;
            b.Name = "b" + this.table.RowCount.ToString();
            b.Tag = destino;

            b.Click += new EventHandler(this.Button_OnClick);

            this.table.Controls.Add(b, 0, this.table.RowCount - 1);
        }

        private void Button_OnClick(object sender, EventArgs e)
        {
            try
            {
                this.m_des_main = ((List<int>)((Button)sender).Tag)[0];
                this.m_des_secn = ((List<int>)((Button)sender).Tag)[1];

                if (this.m_des_main == -1 && this.m_des_secn == -1)
                {
                    this.Close();
                }
            }
            catch (Exception Ex)
            {

            }
            this.ReadXML();
            
        }

        private enum Tipo
        {
            Seccion,
            Titulo,
            Subtitulo,
            Boton,
            Imagen,
            Siguiente
        }

        private void ManageTable()
        {
            this.table.Dispose();
            this.table = new TableLayoutPanel();

            this.table.ColumnCount = 1;
            this.table.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.table.Dock = System.Windows.Forms.DockStyle.Fill;
            this.table.Location = new System.Drawing.Point(0, 0);
            this.table.Name = "table";
            this.table.RowCount = 1;
            this.table.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.table.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 502F));
            this.table.Size = new System.Drawing.Size(937, 505);
            this.table.TabIndex = 0;

            this.panel1.Controls.Add(this.table);
        }

        private int m_des_main = 0;
        private int m_des_secn = 0;
        private void ReadXML()
        {
            this.m_numero_botones = this.m_des_main;
            XmlDocument xml = new XmlDocument();
            xml.Load("CategoriadeLlamadas.xml");

            XmlElement root = xml.DocumentElement;

            this.ManageTable();
            this.Invalidate();

            this.table.RowCount = 0;
            this.table.RowStyles.Clear();
            foreach(XmlElement nodo in root.ChildNodes)
            {
                if (nodo.Name == "Seccion")
                {
                    if (m_des_main == int.Parse(nodo.Attributes["id"].Value))
                    {
                        this.AddItemLabel(nodo.Attributes["nombre"].Value, Tipo.Seccion);
                        foreach (XmlElement Titulos in nodo.ChildNodes)
                        {
                            if (Titulos.Name == "Titulos")
                            {
                                foreach (XmlElement Titulo in Titulos.ChildNodes)
                                {
                                    if (m_des_secn == int.Parse(Titulo.Attributes["id"].Value))
                                    {
                                        //XmlNodeList nl = Titulo.GetElementsByTagName("Botones");
                                        foreach (XmlElement Subseccion in Titulo.ChildNodes)
                                        {
                                            if (Subseccion.Name == "Subtitulos")
                                            {
                                                foreach (XmlElement Items in Subseccion.ChildNodes)
                                                {
                                                    if (Items.Name == "Subtitulo")
                                                    {
                                                        if (Items.GetElementsByTagName("nombre").Item(0) != null)
                                                        {
                                                            if (Items.GetElementsByTagName("nombre").Item(0).FirstChild != null)
                                                            {
                                                                this.AddItemLabel(Items.GetElementsByTagName("nombre").Item(0).FirstChild.Value, Tipo.Subtitulo);
                                                            }
                                                        }

                                                        if (Items.GetElementsByTagName("instrucciones").Item(0) != null)
                                                        {
                                                            if (Items.GetElementsByTagName("instrucciones").Item(0).FirstChild != null)
                                                            {
                                                                this.AddItemLabel(Items.GetElementsByTagName("instrucciones").Item(0).FirstChild.Value, Tipo.Subtitulo);
                                                            }
                                                        }
                                                    }
                                                }
                                            }

                                            if (Subseccion.Name == "Botones")
                                            {
                                                foreach (XmlElement Items in Subseccion.ChildNodes)
                                                {
                                                    if (Items.Name == "boton")
                                                    {
                                                        if (Items.GetElementsByTagName("nombre").Item(0) != null)
                                                        {
                                                            if (Items.GetElementsByTagName("nombre").Item(0).FirstChild != null)
                                                            {
                                                                List<int> des = new List<int>();
                                                                if (Items.GetElementsByTagName("destino").Item(0).FirstChild != null)
                                                                {
                                                                    string[] a = Items.GetElementsByTagName("destino").Item(0).FirstChild.Value.Split(new char[] { ',' });
                                                                    des.Add(int.Parse(a[0]));
                                                                    des.Add(int.Parse(a[1]));
                                                                }

                                                                this.AddItemButton(Items.GetElementsByTagName("nombre").Item(0).FirstChild.Value, des, Tipo.Boton);
                                                            }
                                                        }
                                                    }
                                                }
                                            }

                                            if (Subseccion.Name == "Imagenes")
                                            {
                                                if (Subseccion.ChildNodes.Count > 0)
                                                {
                                                    this.table.RowCount = this.table.RowCount + 1;
                                                    int row = this.table.RowStyles.Add(new RowStyle(SizeType.Percent));
                                                    this.table.RowStyles[row].Height = 50;

                                                    TableLayoutPanel tlp = new TableLayoutPanel();
                                                    tlp.RowCount = 1;
                                                    int r = tlp.RowStyles.Add(new RowStyle(SizeType.Percent));
                                                    tlp.RowStyles[r].Height = 100;

                                                    this.table.Controls.Add(tlp);

                                                    foreach (XmlElement Items in Subseccion.ChildNodes)
                                                    {
                                                        if (Items.Name == "Imagen")
                                                        {
                                                            if (Items.GetElementsByTagName("src").Item(0) != null)
                                                            {
                                                                if (Items.GetElementsByTagName("src").Item(0).FirstChild != null)
                                                                {
                                                                    tlp.ColumnCount = tlp.ColumnCount + 1;
                                                                    int t = tlp.ColumnStyles.Add(new ColumnStyle(SizeType.Percent));
                                                                    tlp.ColumnStyles[t].Width = 50;

                                                                    PictureBox pb = new PictureBox();
                                                                    if (Items.GetElementsByTagName("src").Item(0).FirstChild.Value.ToString() == "gnwinternet1")
                                                                    {
                                                                        pb.Image = global::Genworth_TIMES.Properties.Resources.gnwinternet1;
                                                                    }
                                                                    else if (Items.GetElementsByTagName("src").Item(0).FirstChild.Value.ToString() == "gnwinternet2")
                                                                    {
                                                                        pb.Image = global::Genworth_TIMES.Properties.Resources.gnwinternet2;
                                                                    }
                                                                    else
                                                                    {
                                                                        pb.Image = global::Genworth_TIMES.Properties.Resources.formatoreclamacion;
                                                                    }
                                                                    pb.Size = new System.Drawing.Size(100, 100);
                                                                    pb.SizeMode = PictureBoxSizeMode.AutoSize;
                                                                    pb.Name = "pb" + t.ToString();
                                                                    tlp.Controls.Add(pb);
                                                                }
                                                            }

                                                            if (Items.GetElementsByTagName("commentario").Item(0) != null)
                                                            {
                                                                if (Items.GetElementsByTagName("commentario").Item(0).FirstChild != null)
                                                                {
                                                                    tlp.ColumnCount = tlp.ColumnCount + 1;
                                                                    int t = tlp.ColumnStyles.Add(new ColumnStyle(SizeType.Percent));
                                                                    tlp.ColumnStyles[t].Width = 50;

                                                                    Label l = new Label();
                                                                    l.Dock = DockStyle.Fill;
                                                                    l.Font = new Font(FontFamily.GenericSansSerif, 16.25f);
                                                                    l.ForeColor = Color.Black;
                                                                    l.BackColor = Color.Transparent;
                                                                    l.TextAlign = ContentAlignment.MiddleCenter;
                                                                    l.Name = "l" + t.ToString();
                                                                    l.Text = Items.GetElementsByTagName("commentario").Item(0).FirstChild.Value;
                                                                    tlp.Controls.Add(l);
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }

                                            if (Subseccion.Name == "Siguiente")
                                            {
                                                foreach (XmlElement Items in Subseccion.ChildNodes)
                                                {
                                                    if (Items.Name == "destino")
                                                    {
                                                        if (!string.IsNullOrEmpty(Items.InnerText))
                                                        {
                                                            List<int> des = new List<int>();

                                                            string[] a = Items.InnerText.Split(new char[] { ',' });
                                                            des.Add(int.Parse(a[0]));
                                                            des.Add(int.Parse(a[1]));

                                                            this.AddItemButton("Siguiente", des, Tipo.Boton);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                        break;
                    }
                }
            }
        }
    }
}
