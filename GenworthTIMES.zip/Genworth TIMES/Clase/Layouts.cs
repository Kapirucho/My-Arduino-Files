using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using Genworth_TIMES.DataBase.TimeDataTableAdapters;
using System.Data;
using System.Windows.Forms;

namespace Objetos {
    public interface iLayout {
        void InsertToDataBase(string[] data);
        string[] Headers { get; set; }
    }

    public class Layouts {
        #region Enunciados
        public enum Formato {
            CMS_Agent_Summary_Daily,
            Aux_Daily,
            Claim_User_Activity,
            CMS_Login_Logout,
            Laser_Fiche_Asignacion,
            FileNet_Asignacion
        }
        #endregion

        #region Agent Summary Daily
        /// <summary>
        /// Agent Summary Daily, se requiere asignar nombre de agente para que funcione
        /// </summary>
        public class CMS_ASD : iLayout {
            private TIME_AGENT_SUMMARYTableAdapter tas;
            private int m_AgentId = int.MinValue;

            public CMS_ASD(int AgentId) {
                tas = new TIME_AGENT_SUMMARYTableAdapter();
                m_AgentId = AgentId;

                if (m_AgentId == int.MinValue || m_AgentId == 0 || m_AgentId == -1) {
                    throw new Exception("Debes seleccionar un agente");
                }
            }

            #region iLayout Members

            public void InsertToDataBase(string[] data) {
                tas.Insert(m_AgentId,
                           Layouts.DarFormato(data[0].Trim()),
                           Convert.ToDecimal(data[1].Trim()),
                           data[2].Trim(),
                           data[10].Trim(),
                           data[11].Trim(),
                           data[14].Trim(),
                           data[15].Trim(),
                           data[17].Trim());
            }

            public string[] Headers {
                get { throw new NotImplementedException(); }
                set { throw new NotImplementedException(); }
            }

            #endregion
        }
        #endregion

        #region Aux Daily
        /// <summary>
        /// Aux Daily, se requiere seleccionar el agente.
        /// </summary>
        public class AD : iLayout {
            private TIME_AUX_DAILYTableAdapter tad;
            private int m_AgentId = int.MinValue;

            public AD(int AgentId) {
                tad = new TIME_AUX_DAILYTableAdapter();
                m_AgentId = AgentId;

                if (m_AgentId == int.MinValue || m_AgentId == 0 || m_AgentId == -1) {
                    throw new Exception("Debes seleccionar un agente");
                }
            }

            #region iLayout Members

            public void InsertToDataBase(string[] data) {
                tad.Insert(m_AgentId,
                           data[3].Trim(),
                           data[4].Trim(),
                           data[5].Trim(),
                           data[6].Trim(),
                           data[7].Trim(),
                           data[8].Trim(),
                           data[9].Trim(),
                           data[10].Trim(),
                           Layouts.DarFormato(data[0].Trim()));

            }

            public string[] Headers {
                get { throw new NotImplementedException(); }
                set { throw new NotImplementedException(); }
            }

            #endregion
        }
        #endregion

        #region Asignacion Filenet
        public class AFilenet : iLayout
        {
            private TIME_ASIGNACION_LASER_FICHETableAdapter talf;
            private int m_AgentId = int.MinValue;

            public AFilenet(int Agent_Id)
            {
                talf = new TIME_ASIGNACION_LASER_FICHETableAdapter();
                m_AgentId = Agent_Id;

                if (m_AgentId == int.MinValue || m_AgentId == 0 || m_AgentId == -1) {
                    throw new Exception("Debes seleccionar un agente");
                }
            }

            #region iLayout Members

            public void InsertToDataBase(string[] data) {
                if (data[1].Trim() != string.Empty) {
                    talf.Insert(m_AgentId,
                                data[9].Trim(),
                                Layouts.DarFormato(data[10].Trim()),
                                Layouts.DarFormato(data[12].Trim()),
                                Convert.ToInt32(Layouts.ConvertirA(data[0].Trim(), typeof(int))),
                                Layouts.DarFormato(data[11].Trim()),
                                data[3].Trim(),
                                "",
                                0, //Convert.ToInt32(Layouts.ConvertirA(data[8].Trim(), typeof(int))),
                                data[4].Trim(),
                                "",//data[8].Trim(),
                                "",//data[9].Trim().Replace("\\", " "),
                                data[9].Trim());
                }
            }

            private string[] m_Headers = new string[1];
            public string[] Headers {
                get { return m_Headers; }
                set { m_Headers = value; }
            }
            #endregion

        }
        #endregion

        #region Laser Fiche Asignacion
        /// <summary>
        /// Laser fiche asignacion, se requiere selccionar el agente que realizo las asignaciones.
        /// </summary>
        public class LFA : iLayout {
            private TIME_ASIGNACION_LASER_FICHETableAdapter talf;
            private int m_AgentId = int.MinValue;

            public LFA(int Agent_Id) {
                talf = new TIME_ASIGNACION_LASER_FICHETableAdapter();
                m_AgentId = Agent_Id;

                if (m_AgentId == int.MinValue || m_AgentId == 0 || m_AgentId == -1) {
                    throw new Exception("Debes seleccionar un agente");
                }
            }

            #region iLayout Members

            public void InsertToDataBase(string[] data) {
                if (data[1].Trim() != string.Empty) {
                    talf.Insert(m_AgentId,
                                data[0].Trim(),
                                Layouts.DarFormato(data[1].Trim()),
                                Layouts.DarFormato(data[2].Trim()),
                                Convert.ToInt32(Layouts.ConvertirA(data[4].Trim(), typeof(int))),
                                Layouts.DarFormato(data[5].Trim()),
                                data[3].Trim(),
                                data[6].Trim(),
                                Convert.ToInt32(Layouts.ConvertirA(data[8].Trim(), typeof(int))),
                                data[7].Trim(),
                                data[8].Trim(),
                                data[9].Trim().Replace("\\", " "),
                                data[10].Trim());
                }
            }

            private string[] m_Headers = new string[1];
            public string[] Headers {
                get { return m_Headers; }
                set { m_Headers = value; }
            }

            #endregion
        }
        #endregion

        #region Claim User Activity
        /// <summary>
        /// Claim User Activity
        /// </summary>
        public class CUA : iLayout {
            private TIME_CLAIM_USER_ACTTableAdapter tcua;

            public CUA() {
                tcua = new TIME_CLAIM_USER_ACTTableAdapter();
            }

            #region iLayout Members

            public void InsertToDataBase(string[] data) {
                List<string> cuentas = new List<string>();
                cuentas.AddRange(new string[] { "ESC_MX", "FFSMX", "JAGMX", "VMZMX" });

                if (cuentas.Contains(data[0].Trim())) {
                    return;
                }

                tcua.Insert(Layouts.DarFormato(data[2].Trim()),
                            data[0].Trim(),
                            Convert.ToDecimal(Layouts.ConvertirA(data[11], typeof(decimal)).ToString()),
                            Convert.ToDecimal(Layouts.ConvertirA(data[13], typeof(decimal)).ToString()),
                            Convert.ToDecimal(Layouts.ConvertirA(data[40], typeof(decimal)).ToString()),
                            Convert.ToDecimal(Layouts.ConvertirA(data[5], typeof(decimal)).ToString()),
                            Convert.ToDecimal(Layouts.ConvertirA(data[3], typeof(decimal)).ToString()),
                            Convert.ToDecimal(Layouts.ConvertirA(data[7], typeof(decimal)).ToString()));
            }

            public string[] Headers {
                get { throw new NotImplementedException(); }
                set { throw new NotImplementedException(); }
            }

            #endregion
        }
        #endregion

        #region CMS Agent Login Logout
        public class CMS_ALL : iLayout {
            TIME_CMS_LOGIN_LOGOUTTableAdapter tcll;
            DataTable dtUsuario = new TIME_USUARIOSTableAdapter().GetData();

            public CMS_ALL() {
                tcll = new TIME_CMS_LOGIN_LOGOUTTableAdapter();
            }

            #region iLayout Members

            public void InsertToDataBase(string[] data) {
                int UserId = 0;
                foreach (DataRow dr in dtUsuario.Rows) {
                    if (dr["Nombre_2"].ToString().ToLower() == data[0].ToLower()) {
                        UserId = Convert.ToInt32(dr["Id"].ToString());
                        break;
                    }
                }

                tcll.Insert(UserId, //0
                            data[0].Trim(),//1
                            0,//2
                            Layouts.DarFormato(data[4].Trim()),//3
                            Layouts.DarFormato(data[6].Trim()),//4
                            Layouts.DarFormato(data[7].Trim()),//5
                            data[8].Trim(),//06
                            (int)ConvertirA(data[9].Trim(), typeof(int)),//07
                            (int)ConvertirA(data[10].Trim(), typeof(int)),//08
                            (int)ConvertirA(data[11].Trim(), typeof(int)),//09
                            (int)ConvertirA(data[12].Trim(), typeof(int)),//10
                            (int)ConvertirA(data[13].Trim(), typeof(int)),//011
                            (int)ConvertirA(data[14].Trim(), typeof(int)),//012
                            (int)ConvertirA(data[15].Trim(), typeof(int)),//013
                            (int)ConvertirA(data[16].Trim(), typeof(int)),//014
                            (int)ConvertirA(data[17].Trim(), typeof(int)),//015
                            (int)ConvertirA(data[18].Trim(), typeof(int)),//016
                            (int)ConvertirA(data[19].Trim(), typeof(int)),//017
                            (int)ConvertirA(data[20].Trim(), typeof(int)),//018
                            (int)ConvertirA(data[21].Trim(), typeof(int)),//019
                            (int)ConvertirA(data[22].Trim(), typeof(int)),//020
                            (int)ConvertirA(data[23].Trim(), typeof(int)));//021
            }

            public string[] Headers {
                get { throw new NotImplementedException(); }
                set { throw new NotImplementedException(); }
            }

            #endregion
        }
        #endregion

        protected static DateTime DarFormato(string Fecha) {
            string[] fe = Fecha.Split(new char[] { '-' });

            if (fe.Length == 3) {
                int month = 0;
                if (fe[1].ToUpper() == "ENE") { month = 1; }
                if (fe[1].ToUpper() == "FEB") { month = 2; }
                if (fe[1].ToUpper() == "MAR") { month = 3; }
                if (fe[1].ToUpper() == "APR") { month = 4; }
                if (fe[1].ToUpper() == "MAY") { month = 5; }
                if (fe[1].ToUpper() == "JUN") { month = 6; }
                if (fe[1].ToUpper() == "JUL") { month = 7; }
                if (fe[1].ToUpper() == "AGO") { month = 8; }
                if (fe[1].ToUpper() == "SEP") { month = 9; }
                if (fe[1].ToUpper() == "OCT") { month = 10; }
                if (fe[1].ToUpper() == "NOV") { month = 11; }
                if (fe[1].ToUpper() == "DIC") { month = 12; }

                return new DateTime(int.Parse("20" + fe[2]), month, int.Parse(fe[0]));
            } else {
                try {
                    return DateTime.Parse(Fecha);
                } catch (Exception) {
                    throw new FormatException("La fecha no esta en el formato requerido.");
                }
            }
        }

        protected static object ConvertirA(Object Dato, Type Tipo) {
            if (Type.GetType(Dato.ToString()) == Tipo) {
                return Dato;
            }

            try {
                if (Dato.ToString().Length == 0 && Tipo == typeof(decimal)) {
                    return 0;
                } else if (Tipo == typeof(decimal)) { return decimal.Parse(Dato.ToString()); }

                if (Dato.ToString().Trim() == string.Empty && Tipo == typeof(int)) {
                    return 0;
                } else if (Tipo == typeof(int)) { return int.Parse(Dato.ToString()); }
            } catch (Exception) {
                ConvertirA("", Tipo);
            }

            return Dato;
        }
    }

    public class ReadFiles {
        private FileInfo m_FI;
        private Layouts.Formato m_Formato;
        private iLayout m_Layout;
        private char m_Separator;
        private int m_AgentId = int.MinValue;
        private int m_Header = int.MinValue;

        public ReadFiles(String FileName, Layouts.Formato Formato, char Separador, int AgentId, int Headers) {
            m_FI = new FileInfo(FileName);
            m_Formato = Formato;
            m_Separator = Separador;
            m_AgentId = AgentId;
            m_Header = Headers;
        }

        public void IniciarliarObjetos() {
            switch (m_Formato) {
                case Layouts.Formato.CMS_Agent_Summary_Daily:
                    m_Layout = new Layouts.CMS_ASD(m_AgentId);
                    break;
                case Layouts.Formato.Aux_Daily:
                    m_Layout = new Layouts.AD(m_AgentId);
                    break;
                case Layouts.Formato.Claim_User_Activity:
                    m_Layout = new Layouts.CUA();
                    break;
                case Layouts.Formato.Laser_Fiche_Asignacion:
                    m_Layout = new Layouts.LFA(m_AgentId);
                    break;
                case Layouts.Formato.CMS_Login_Logout:
                    m_Layout = new Layouts.CMS_ALL();
                    break;
                case Layouts.Formato.FileNet_Asignacion:
                    m_Layout = new Layouts.AFilenet(m_AgentId);
                    break;

            }
            IniciarLectura();
        }

        private void IniciarLectura() {
            using (StreamReader sr = new StreamReader(m_FI.FullName, Encoding.Default)) {
                string[] headers;
                for (int a = 0; a < m_Header; a++) {
                    sr.ReadLine();
                }

                while (!sr.EndOfStream) {
                    string linea = sr.ReadLine();
                    string[] data = linea.Replace("\"", "").Split(new char[] { this.m_Separator });
                    if (data.Length <= 1) {
                        if (MessageBox.Show("El archivo no contiene el separador especificado o es una cabecera, �Deseas continuar?",
                                            "Informaci�n", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.Cancel) {
                            MessageBox.Show("El proceso se interrumpio!");
                            break;
                        }
                    }

                    try {
                        m_Layout.InsertToDataBase(data);
                    } catch (FormatException Fe) {
                        if (MessageBox.Show("La linea que se esta procesando tiene un formato no valido, �Desea ignorar y continuar?", "Error", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.Cancel) {
                            MessageBox.Show("El proceso se interrumpio! Error: " + Fe.Message);
                            break;
                        }
                    }
                }
                MessageBox.Show("El proceso termino correctamente!");
            }
        }
    }
}
