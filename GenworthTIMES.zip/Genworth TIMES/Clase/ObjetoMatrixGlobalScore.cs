﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Genworth_TIMES.Clase {

    /// <summary>
    /// This object should be used as a multidimentional array to handle all the parameters needed in order to evaluate
    /// the claims associate, to define the data to group we will use PAIS, COB, USR (Country, Cover, User) as keywords
    /// TPPpcd will be filled from database, this is a defined value using PAIS, COB as keywords to be grouped
    /// Adding values for NoDocuments, PTime should be done at fly as they are SUMS that will increase over time
    /// 
    /// </summary>
    class ObjMatrixGSDetailed
    {

        public ObjMatrixGSDetailed() { }

        /// <summary>
        /// New var for the redefined new global score
        /// </summary>

        #region NewVars

        private string m_User = null;
        /// <summary>
        /// User to be analized. Ex. IRAMX
        /// </summary>
        public string User
        {
            get { return m_User; }
            set { m_User = value; }
        }


        private string m_Pais = null;
        /// <summary>
        /// Gets or Set the country for the coverture been used
        /// </summary>
        public string Pais
        {
            get { return m_Pais; }
            set { m_Pais = value; }
        }

        private string m_Cobertura = null;
        /// <summary>
        /// Get or Set Cover been analyzed
        /// </summary>
        public string Cobertura
        {
            get { return m_Cobertura; }
            set { m_Cobertura = value; }
        }

        private int m_TPPpcd = 0;
        /// <summary>
        /// Get or Set
        /// Tiempo promedio de procesamiento por cobertura y documento
        /// Average processing time by coverage and document type
        /// </summary>
        public int TPPpcd
        {
            get { return m_TPPpcd; }
            set { m_TPPpcd = value; }
        }

        private int m_NoDocumentos = 0;
        /// <summary>
        /// Gets or set total number of documents processed by document
        /// This is obtained from database grouping all the documents processed by the user using PAIS and COB as keywords
        /// </summary>
        public int NoDocumentos
        {
            get { return m_NoDocumentos; }
            set { m_NoDocumentos = value; }
        }

        private double m_pTime = 0;
        /// <summary>
        /// Processing time of the current document
        /// </summary>
        public double pTime
        {
            get { return m_pTime; }
            set { m_pTime = value; }
        }

        private double m_cUnits = 0;
        /// <summary>
        /// This only returns the Units derived from PTime
        /// Should be calculated at the end of retriveing and processing all records
        /// cUnits = Calculated Units
        /// </summary>
        public double cUnits
        {
            get { return m_cUnits; }
        }

        private double m_pUnits = 0;
        /// <summary>
        /// This only return the processing units based on NoDocuments and the real time that the user should have used
        /// This should be calculated at the end of retriving and processing all records
        /// pUnits = Processing Units
        /// "SE DEBIO TARDAR EN UNIDADES"
        /// </summary>
        public double pUnits
        {
            get { return m_pUnits; }
        }

        private double m_PorcentageTime = 0;
        /// <summary>
        /// Time consumed in the document processing expressed in porcentage
        /// </summary>
        public double PorcentageTime
        {
            get { return m_PorcentageTime; }
        }

        #endregion


        


    }

    class ObjetoMatrixGlobalScore {
        public ObjetoMatrixGlobalScore() { }

        

        /// <summary>
        /// Vars for global score
        /// </summary>
        #region Vars
        private double m_CalidadPercent = 0;
        public double CalidadPercent {
            get { return m_CalidadPercent; }
            set { m_CalidadPercent = value; }
        }

        private double m_ProductivityPercent = 0;
        public double ProductivityPercent {
            get { return m_ProductivityPercent; }
            set { m_ProductivityPercent = value; }
        }

        private double m_PuntualidadPercent = 0;
        public double PuntualidadPercent {
            get { return m_PuntualidadPercent; }
            set { m_PuntualidadPercent = value; }
        }

        private double m_GrupalPercent = 0;
        public double GrupalPercent {
            get { return m_GrupalPercent; }
            set { m_GrupalPercent = value; }
        }

        private double m_TotalPercent = 0;
        public double TotalPercent {
            get { return m_TotalPercent; }
            set { m_TotalPercent = value; }
        }
        #endregion

        #region Comunes

        private string m_Nombre = string.Empty;
        public string Nombre {
            get { return m_Nombre; }
            set { m_Nombre = value; }
        }

        private string m_TIAUser = string.Empty;
        public string TIAUser {
            get { return m_TIAUser; }
            set { m_TIAUser = value; }
        }

        private int m_DiasLaborados = 0;
        public int DiasLaborados {
            get { return m_DiasLaborados; }
            set { m_DiasLaborados = value; }
        }

        private double m_Total = 0;
        public double Total {
            get { return m_Total; }
            set { m_Total = value; }
        }

        private double m_TotalGrupal = 0;
        public double TotalGrupal {
            get { return m_TotalGrupal; }
            set { m_TotalGrupal = value; }
        }

        #endregion

        #region Puntualidad

        private double m_NumeroDeRetardos = 0;
        public double NumeroDeRetardos {
            get { return m_NumeroDeRetardos; }
            set { m_NumeroDeRetardos = value; }
        }

        private double m_PromedioRetardo = 0;
        public double PromedioRetardo {
            get { return m_PromedioRetardo; }
            set { m_PromedioRetardo = value; }
        }

        private double m_PuntualidadTarget = 0;
        public double PuntualidadTarget {
            get { return m_PuntualidadTarget; }
            set { m_PuntualidadTarget = value; }
        }

        private double m_PuntualidadReach = 0;
        public double PuntualidadReach {
            get { return m_PuntualidadReach; }
            set { m_PuntualidadReach = value; }
        }

        #endregion

        #region Calidad

        #region General

        private double m_CalidadReach = 0;
        public double CalidadReach {
            get { return m_CalidadReach; }
            set { m_CalidadReach = value; }
        }

        #endregion

        #region Target

        private double m_ClaimsTarget = 0;
        public double ClaimsTarget {
            get { return m_ClaimsTarget; }
            set { m_ClaimsTarget = value; }
        }

        private double m_CallsTarget = 0;
        public double CallsTarget {
            get { return m_CallsTarget; }
            set { m_CallsTarget = value; }
        }

        #endregion

        #region Reach

        private double m_ClaimsReach = 0;
        public double ClaimsReach {
            get { return m_ClaimsReach; }
            set { m_ClaimsReach = value; }
        }

        private double m_CallsReach = 0;
        public double CallsReach {
            get { return m_CallsReach; }
            set { m_CallsReach = value; }
        }

        #endregion

        #endregion

        #region Adicionales

        #region Score

        private double m_avg = 0;
        public double Avg {
            get { return m_avg; }
            set { m_avg = value; }
        }

        private double m_TrainingScore = 0;
        public double TrainingScore {
            get { return m_TrainingScore; }
            set { m_TrainingScore = value; }
        }

        private double m_FeedbackScore = 0;
        public double FeedbackScore {
            get { return m_FeedbackScore; }
            set { m_FeedbackScore = value; }
        }

        private double m_MeetingScore = 0;
        public double MeetingScore {
            get { return m_MeetingScore; }
            set { m_MeetingScore = value; }
        }

        private double m_AdditionalActionsScore = 0;
        public double AdditionalActionsScore {
            get { return m_AdditionalActionsScore; }
            set { m_AdditionalActionsScore = value; }
        }

        #endregion

        #endregion

        #region Productivity

        #region General

        private double m_ProductivityUnitTarget = 0;
        public double ProductivityUnitTarget {
            get { return m_ProductivityUnitTarget; }
            set { m_ProductivityUnitTarget = value; }
        }

        private double m_ProductivityScore = 0;
        public double ProductivityScore {
            get { return m_ProductivityScore; }
            set { m_ProductivityScore = value; }
        }

        private double m_ProductivityTarget = 0;
        public double ProductivityTarget {
            get { return m_ProductivityTarget; }
            set { m_ProductivityTarget = value; }
        }

        private double m_ProductivityReach = 0;
        public double ProductivityReach {
            get { return m_ProductivityReach; }
            set { m_ProductivityReach = value; }
        }

        private double m_Corres = 0;
        public double Corres {
            get { return m_Corres; }
            set { m_Corres = value; }
        }

        private double m_Pending_Claims = 0;
        public double Pending_Claims {
            get { return m_Pending_Claims; }
            set { m_Pending_Claims = value; }
        }

        private double m_Postal_Service = 0;
        public double Postal_Service {
            get { return m_Postal_Service; }
            set { m_Postal_Service = value; }
        }

        private double m_Avg_ACD_Time = 0;
        public double Avg_ACD_Time {
            get { return m_Avg_ACD_Time; }
            set { m_Avg_ACD_Time = value; }
        }

        #endregion

        #region Score

        private double m_CCINScore = 0;
        public double CCINScore {
            get { return m_CCINScore; }
            set { m_CCINScore = value; }
        }

        private double m_CFINScore = 0;
        public double CFINScore {
            get { return m_CFINScore; }
            set { m_CFINScore = value; }
        }

        private double m_ACD_CallsScore = 0;
        public double ACD_CallsScore {
            get { return m_ACD_CallsScore; }
            set { m_ACD_CallsScore = value; }
        }

        private double m_LasserFicheScore = 0;
        public double LasserFicheScore {
            get { return m_LasserFicheScore; }
            set { m_LasserFicheScore = value; }
        }

        private double m_DHLScore = 0;
        public double DHLScore {
            get { return m_DHLScore; }
            set { m_DHLScore = value; }
        }
        #endregion

        #region Target

        private double m_CCINTarget = 0;
        public double CCINTarget {
            get { return m_CCINTarget; }
            set { m_CCINTarget = value; }
        }

        private double m_CFINTarget = 0;
        public double CFINTarget {
            get { return m_CFINTarget; }
            set { m_CFINTarget = value; }
        }

        private double m_ACD_CallsTarget = 0;
        public double ACD_CallsTarget {
            get { return m_ACD_CallsTarget; }
            set { m_ACD_CallsTarget = value; }
        }

        private double m_LasserFicheTarget = 0;
        public double LasserFicheTarget {
            get { return m_LasserFicheTarget; }
            set { m_LasserFicheTarget = value; }
        }

        private double m_DHLTarget = 0;
        public double DHLTarget {
            get { return m_DHLTarget; }
            set { m_DHLTarget = value; }
        }
        #endregion

        #endregion

        #region Followup
        private double m_Seguimiento = 0;
        public double Seguimiento {
            get { return m_Seguimiento; }
            set { m_Seguimiento = value; }
        }
        private double m_Seguimiento_Pagos = 0;
        public double Seguimiento_Pagos {
            get { return m_Seguimiento_Pagos; }
            set { m_Seguimiento_Pagos = value; }
        }

        #endregion
    }
}
