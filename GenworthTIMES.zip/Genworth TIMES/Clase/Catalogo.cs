﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace Genworth_TIMES.Clase
{
    public class MiCatalogo : IEnumerable<Catalogo>
    {
        List<Catalogo> miCat = new List<Catalogo>();

        public Catalogo this[int index]
        {
            get { return miCat[index]; }
            set { miCat.Insert(index, value); }
        }

        public IEnumerator<Catalogo> GetEnumerator()
        {
            return miCat.GetEnumerator();
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }
    }

    public class Catalogo
    {
        public Catalogo()
        {
        }

        public Catalogo(int Id, string Data, int Val, int Cat, string definition)
        {
            _Id = Id;
            _data = Data;
            _val = Val;
            _cat_id = Cat;
            _Definition = definition;
        }

        private int _Id = int.MinValue;
        public int Id
        {
            get { return _Id; }
            set { _Id = value; }
        }

        private string _data = string.Empty;
        public string data
        {
            get { return _data; }
            set { _data = value; }
        }

        private int _val = int.MinValue;
        public int Val
        {
            get { return _val; }
            set { _val = value; }
        }

        private int _cat_id = int.MinValue;
        public int Cat_Id
        {
            get { return _cat_id; }
            set { _cat_id = value; }
        }

        private string _Definition = string.Empty;
        public string Definition
        {
            get { return _Definition; }
            set { _Definition = value; }
        }
    }
}
