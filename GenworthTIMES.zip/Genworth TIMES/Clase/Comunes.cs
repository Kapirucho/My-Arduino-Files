using System;
using System.Collections.Generic;
using System.Text;
using Genworth_TIMES.DataBase.TimeDataTableAdapters;
using System.Windows.Forms;

namespace Genworth_TIMES {
    class Comunes {
        private static void ChangeLocation(bool data) {
            global::Genworth_TIMES.Properties.Settings.Default.RemoteLocation = data;
            global::Genworth_TIMES.Properties.Settings.Default.Save();
        }

        public static void AddRegistro(Decimal Accion, Decimal Tipo, Decimal Usuario, DateTime Inicio, DateTime Final, String Descripcion, int ClaimNumber, string Document, string Country, string Client) {
            if (Accion == decimal.MinValue || Accion == int.MinValue) {
                return;
            }

            try {
                if (!Objetos.Network.Network.ServerAvailable()) { throw new Exception(""); }
                new TIME_REGISTROSTableAdapter().Insert(Accion, Tipo, Usuario, Inicio, Final, Descripcion, ClaimNumber, Document, Country, Client);
            } catch (Exception Ex) {
                ChangeLocation(true);
                AddRegistro(Accion, Tipo, Usuario, Inicio, Final, Descripcion, ClaimNumber, Document, Country, Client);
            }
        }

        public static void InsertOrUpdate(DateTime Inicio, int Accion, int UserId, int MaxElapsed) {
            try {
                if (!Objetos.Network.Network.ServerAvailable()) { throw new Exception(""); }
                int res = new CurrentTableAdapter().UpdateQuery(Inicio, Accion, UserId, MaxElapsed);
                if (res == 0) {
                    new CurrentTableAdapter().InsertQuery(Inicio, Accion, UserId, MaxElapsed);
                }
            } catch (Exception Ex) {
                ChangeLocation(true);
                InsertOrUpdate(Inicio, Accion, UserId, MaxElapsed);
            }
        }
    }
}
