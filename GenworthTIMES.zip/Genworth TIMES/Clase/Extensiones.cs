﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Genworth_TIMES.Clase
{
    public static class Extensiones
    {
        public static decimal ToDecimal(this String str)
        {
            if (String.IsNullOrEmpty(str)) { return 0; }
            else { 
                return decimal.Parse(str);
            }
        }

        public static int ToInt(this String str)
        {
            if(string.IsNullOrEmpty(str)) { return 0; }
            else {
                return int.Parse(str);
            }
        }
    }
}
