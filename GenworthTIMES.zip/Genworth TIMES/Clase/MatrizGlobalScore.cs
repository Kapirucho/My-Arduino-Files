﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using Objetos;
using Genworth_TIMES.DataBase.TimeDataTableAdapters;
using Genworth_TIMES.DataBase;
using System.Windows.Forms.DataVisualization.Charting;
using System.Collections;


namespace Genworth_TIMES.Clase {
    class MatrizGlobalScore {

        private int m_UsuarioId = int.MinValue;

        public int UsuarioId {
            get { return m_UsuarioId; }
            set { m_UsuarioId = value; }
        }

        private int m_DiasLaborados = 0;
        private double m_Month;
        private double m_Year;
        private int m_NumeroReclamaciones = 0;
        private int m_NumeroCCIN = 0;
        private int m_NumeroLlamadas = 0;
        private int m_Corres = 0;
        private int m_payment_benefit = 0;
        private double m_Total = 0;
        DateTime timeConsulta;
        private double m_Avg_ACD_Time;

        private Usuario usr = new Usuario();

        private ObjetoMatrixGlobalScore Matriz;

        private List<ObjetoMatrixGlobalScore> m_MatrizGlobal;
        public List<ObjetoMatrixGlobalScore> MatrizGlobal {
            get { return m_MatrizGlobal; }
        }

        public MatrizGlobalScore(int UsuarioId, double Month, double Year) {
            this.m_MatrizGlobal = new List<ObjetoMatrixGlobalScore>();
            Matriz = new ObjetoMatrixGlobalScore();
            Matriz.Avg_ACD_Time = m_Avg_ACD_Time;


            m_UsuarioId = UsuarioId;
            m_Month = Month;
            m_Year = Year;
            Avg_HandlingTime();

            this.GatherBulkUserInfo();
            this.CalcularScoreGrupal();
        }

        public MatrizGlobalScore(double Month, double Year) {
            m_MatrizGlobal = new List<ObjetoMatrixGlobalScore>();

            TIME_USUARIOSTableAdapter tuta = new TIME_USUARIOSTableAdapter();

            Usuarios usrs = new Usuarios(tuta.GetData());

            m_Month = Month;
            m_Year = Year;

            Avg_HandlingTime();

            foreach (Usuario us in usrs._Usuarios) {
                try {
                    if (us.Tipo != 3) {
                        //if (Month >= 7 && us.TIAUser == "IRCMX")
                        //{

                        //}
                        //else
                        //{
                        m_UsuarioId = us.Id;
                        Matriz = new ObjetoMatrixGlobalScore();
                        Matriz.Avg_ACD_Time = m_Avg_ACD_Time;
                        this.GatherBulkUserInfo(us);
                        m_MatrizGlobal.Add(Matriz);
                        //}
                    }
                } catch (Exception Ex) {
                    string Mensaje = Ex.Message;
                }
            }

            this.CalcularScoreGrupal();
        }

        private void Avg_HandlingTime() {
            TIME_USUARIOSTableAdapter tuta = new TIME_USUARIOSTableAdapter();

            Usuarios usrs = new Usuarios(tuta.GetData());

            int m_Count_Avg = 0;

            foreach (Usuario usre in usrs._Usuarios) {
                // obtener los datos de los ultimos tres meses
                // ej... marzo traer( dic, ene, feb)
                DataTable dtUserActivity = new TIME_CLAIM_USER_ACT1TableAdapter().getData1((int)m_Month, (int)m_Year, usre.Id);

                foreach (DataRow dr in dtUserActivity.Rows) {
                    DateTime dtime = DateTime.Parse(dr["Activity_Date"].ToString());

                    // se quita los fines de semana para que tome todos los registros ingresados en el archivo
                    // Hlopez
                    // 09 abril 2013  
                    //  if (dtime.DayOfWeek != DayOfWeek.Saturday && dtime.DayOfWeek != DayOfWeek.Sunday)
                    //  {
                    //Avg_ACD_Time
                    try {
                        string tie = dr["Avg_ACD_Time"].ToString();
                        string[] sep = tie.Split(new char[] { ':' });

                        int minutos;

                        if (sep.Length > 1) {
                            minutos = int.Parse(sep[0].ToInt().ToString()) * 60 + int.Parse(sep[1].ToInt().ToString());
                        } else {
                            minutos = int.Parse(tie.Split(new char[] { '.' })[0]) / 60;
                        }

                        m_Avg_ACD_Time += minutos;

                        m_Count_Avg++;
                    } catch { m_Avg_ACD_Time += 0; }

                    //m_DiasLaborados++;
                }
                // }
                dtUserActivity.Dispose();
            }

            m_Avg_ACD_Time = AVG("avg_acd_time"); //6.8; //(m_Avg_ACD_Time / 60) / m_Count_Avg;

        }

        public double AVG(string m_tipos) {
            TimesDA t = new TimesDA();
            return t.GetAVG_ACT(m_tipos);

        }

        public void GenerateNewChart(Chart graphica) {
            graphica.Series.Clear();

            graphica.Series.Add("Productivity");
            graphica.Series.Add("Calls Quality");
            graphica.Series.Add("Claims Quality");
            graphica.Series.Add("Puntuality");
            graphica.Series.Add("Gap");

            Font fo = new Font(FontFamily.GenericSansSerif, 10, FontStyle.Regular, GraphicsUnit.Pixel);

            int counter = 0;
            foreach (ObjetoMatrixGlobalScore data in this.MatrizGlobal) {
                int pointc = graphica.Series["Productivity"].Points.AddY(data.ProductivityReach);
                int pointa = graphica.Series["Calls Quality"].Points.AddY(data.CallsReach);
                int pointd = graphica.Series["Claims Quality"].Points.AddY(data.ClaimsReach);
                int pointe = graphica.Series["Puntuality"].Points.AddY(data.PuntualidadReach);

                int pointb = graphica.Series["Gap"].Points.AddY(100 - data.Total);

                graphica.Series["Productivity"].Points[pointa].AxisLabel = data.TIAUser;


                //graphica.Series["Productivity"].Points[pointa].Label = data.TIAUser;

                string groupname = "Group" + counter.ToString();
                graphica.Series["Productivity"]["StackedGroupName"] = groupname;
                graphica.Series["Calls Quality"]["StackedGroupName"] = groupname;
                graphica.Series["Claims Quality"]["StackedGroupName"] = groupname;
                graphica.Series["Puntuality"]["StackedGroupName"] = groupname;
                graphica.Series["Gap"]["StackedGroupName"] = groupname;

                counter++;
            }

            foreach (Series sr in graphica.Series) {
                sr.ChartType = SeriesChartType.StackedColumn100;
                sr.IsValueShownAsLabel = true;
                sr.Font = fo;
            }

            foreach (Legend lg in graphica.Legends) {
                //lg.Enabled = false;
                lg.Font = fo;
            }

            foreach (ChartArea ca in graphica.ChartAreas) {
                ca.AxisX.LabelStyle.IsStaggered = true;
                ca.AxisX.TitleFont = fo;
            }

            graphica.ChartAreas[0].AxisX.ScrollBar.Size = 10;
            graphica.ChartAreas[0].AxisX.ScrollBar.ButtonStyle = ScrollBarButtonStyles.SmallScroll;
            graphica.ChartAreas[0].AxisX.ScrollBar.IsPositionedInside = true;

        }

        private void CalcularScoreGrupal() {
            double UnitTargetGrupal = 0;

            UnitTargetGrupal = (42 * this.m_MatrizGlobal[0].DiasLaborados) * this.m_MatrizGlobal.Count;

            //UnitTargetGrupal = UnitTargetGrupal - (Matriz.LasserFicheScore + Matriz.DHLScore);

            double unitreach = 0;
            foreach (ObjetoMatrixGlobalScore oMatriz in this.m_MatrizGlobal) {
                unitreach += oMatriz.CFINScore + oMatriz.CCINScore + oMatriz.ACD_CallsScore + oMatriz.AdditionalActionsScore;
            }

            double ScoreGrupal = (unitreach * 100) / UnitTargetGrupal;

            double tot = (ScoreGrupal * 15) / 100;

            foreach (ObjetoMatrixGlobalScore oMatriz in this.m_MatrizGlobal) {
                oMatriz.TotalGrupal = ScoreGrupal; //15;
                oMatriz.TotalPercent = tot;
            }
        }

        private void GatherBulkUserInfo() {
            ConsultaUsuario();
            this.GatherBulkUserInfo(usr);
            this.m_MatrizGlobal.Add(Matriz);
        }

        private void GatherBulkUserInfo(Usuario User) {
            usr = User;

            m_DiasLaborados = 0;
            m_NumeroReclamaciones = 0;
            m_NumeroCCIN = 0;
            m_NumeroLlamadas = 0;
            m_Total = 0;

            timeConsulta = new DateTime(int.Parse(m_Year.ToString()), int.Parse(m_Month.ToString()), 1);

            Matriz.Nombre = usr.Nombre;
            Matriz.TIAUser = usr.TIAUser;

            //Avg_HandlingTime();

            UserActivity();
            UserCorrespondencia();
            UserCalidadClaims();
            UserCalidadCalls();
            UserAsignaciones();
            UserRegistros();
            UserPuntualidad();

            // se comenta para no afectar para solo contabilizar alex alvarez
            // 11 abril 2013 
            //m_Total += Matriz.Seguimiento;// +((timeConsulta.Month == 2 || timeConsulta.Month == 1) && timeConsulta.Year == 2012 ? 0 : Matriz.Seguimiento_Pagos);

            m_Total += Matriz.Pending_Claims;
            //m_Total += Matriz.LasserFicheScore;

            //************************CALCULO PARA RESTAR SCORE DE Lasser Fiche************************************
            double m_lf = ((Matriz.LasserFicheScore * 10) / 60) / 24;

            double m_put = Matriz.ProductivityUnitTarget / 42;

            //m_put -= m_lf;

            // se comenta para no afectar para solo contabilizar alex alvarez 
            // 11 abril 2013 
            // CFIN Units | CCIN Units | ACD Units | Corres | Pending Claims	| Additional Activities		

            // m_Total += Matriz.LasserFicheScore;

            Matriz.ProductivityUnitTarget = m_put * 42;
            //************************END CALCULO PARA RESTAR SCORE DE Lasser Fiche************************************

            //double ab = Convert.ToDouble(new TIME_REGISTROS1TableAdapter().GetDiscount((decimal)timeConsulta.Month, (decimal)timeConsulta.Year, (decimal)User.Id));

            //Matriz.ProductivityUnitTarget = (Matriz.ProductivityUnitTarget - (ab / 60 / 10) < 0 ? Matriz.ProductivityUnitTarget : Matriz.ProductivityUnitTarget - (ab / 60 / 10));

            //Matriz.ProductivityUnitTarget = Matriz.ProductivityUnitTarget - (Matriz.LasserFicheScore + Matriz.DHLScore);

            Matriz.ProductivityScore = m_Total;

            if (Matriz.ProductivityUnitTarget == 0) {
                Matriz.ProductivityTarget = 0;
            } else {
                Matriz.ProductivityTarget = (m_Total * 100) / Matriz.ProductivityUnitTarget;
            }
            Matriz.ProductivityReach = (Matriz.ProductivityTarget * 45) / 100;

            //Matriz.ProductivityScore = Matriz.ProductivityScore - (Matriz.LasserFicheScore / 10);

            if (Matriz.ProductivityReach > 45) {
                Matriz.ProductivityReach = 45;
            }

            Matriz.Total = Matriz.PuntualidadReach + Matriz.CalidadReach + Matriz.ProductivityReach;
        }


        double m_retardos_lonche = 0;
        double m_retardos_lonche_min = 0;
        private void UserRegistros() {
            TIME_REGISTROS1TableAdapter trta = new TIME_REGISTROS1TableAdapter();

            TimeData.TIME_REGISTROS1DataTable m_Registros = trta.GetDataBy((decimal)usr.Id, (decimal)timeConsulta.Month, (decimal)timeConsulta.Year);

            m_retardos_lonche = 0;
            m_retardos_lonche_min = 0;
            //TimeData.TIME_FLEX_DATADataTable m_Registros = tfda.GetDataBy(usr.Id, "Retardo", timeConsulta);

            if (m_Registros.Rows.Count == 0) {
                Matriz.TrainingScore = 0;
                Matriz.FeedbackScore = 0;
                Matriz.MeetingScore = 0;
                Matriz.AdditionalActionsScore = 0;
            } else {
                double m_training = 0;
                double m_feedback = 0;
                double m_meeting = 0;
                double m_additional = 0;
                double m_segui = 0;
                double m_segui_pago = 0;
                double m_postal_service = 0;
                double m_pending_claims = 0;
                double m_correspondencia = 0;
                int m_pending_count = 0;


                Hashtable htDates = new Hashtable();
                int count = 0;
                int count_add = 0;
                foreach (DataRow dr in m_Registros.Rows) {
                    DateTime inicio = DateTime.Parse(dr["Inicio"].ToString());
                    DateTime final = DateTime.Parse(dr["Final"].ToString());

                    switch (dr["Accion"].ToString()) {
                        case "1":
                        case "2":
                            switch (usr.Id) {

                                case 23:
                                    if (final.Subtract(inicio).TotalMinutes > 35) {
                                        m_retardos_lonche += 1;
                                        m_retardos_lonche_min += Math.Abs(final.Subtract(inicio).TotalMinutes - 30);
                                    }
                                    break;
                                default:
                                    if (final.Subtract(inicio).TotalMinutes > 65) {
                                        m_retardos_lonche += 1;
                                        m_retardos_lonche_min += Math.Abs(final.Subtract(inicio).TotalMinutes - 60);
                                    }
                                    break;
                            }
                            break;
                        case "3":
                            m_training += final.Subtract(inicio).TotalMinutes;
                            break;
                        case "4":
                            m_feedback += final.Subtract(inicio).TotalMinutes;
                            break;
                        case "5":
                            m_meeting += final.Subtract(inicio).TotalMinutes;
                            break;
                        case "44":
                        case "6":
                            m_additional += final.Subtract(inicio).TotalMinutes;
                            count_add++;
                            break;
                        case "46":
                        case "28":
                            m_segui += final.Subtract(inicio).TotalMinutes;

                            break;
                        case "29":
                            m_segui_pago += final.Subtract(inicio).TotalMinutes;
                            break;
                        case "42":
                            m_pending_claims += final.Subtract(inicio).TotalMinutes;

                            if (!htDates.Contains(inicio)) {
                                m_pending_count++;
                            } else {
                                htDates.Add(count++, inicio);
                            }

                            break;
                        case "45":
                            m_postal_service += final.Subtract(inicio).TotalMinutes;
                            break;
                        case "43":
                            //m_Corres += final.Subtract(inicio).Minutes;
                            m_correspondencia++;
                            break;
                    }
                }
                Matriz.TrainingScore = (m_training / 10);
                Matriz.FeedbackScore = (m_feedback / 10);
                Matriz.MeetingScore = (m_meeting / 10);
                Matriz.AdditionalActionsScore = (m_additional / 10);
                Matriz.Seguimiento = (m_segui / 10);
                Matriz.Seguimiento_Pagos = (m_segui_pago / 10);
                Matriz.Pending_Claims = (m_pending_claims / 10);
                Matriz.Postal_Service = (m_postal_service / 10);
                Matriz.DHLScore = (m_postal_service / 10);
                //Matriz.Corres = ((m_correspondencia * 3.5) / 10);
            }

            /*
            m_Total += Matriz.TrainingScore
                    + Matriz.FeedbackScore
                    + Matriz.MeetingScore
                    + Matriz.AdditionalActionsScore
                    + Matriz.Postal_Service;*/
            if (AVG("AddAct") == 0) {
                m_Total += Matriz.AdditionalActionsScore + Matriz.TrainingScore + Matriz.FeedbackScore + Matriz.MeetingScore + Matriz.Postal_Service + Matriz.Seguimiento;
                Matriz.Avg = Matriz.AdditionalActionsScore + Matriz.TrainingScore + Matriz.FeedbackScore + Matriz.MeetingScore + Matriz.Postal_Service + Matriz.Seguimiento; //AVG("AddAct"); 
            } else {
                m_Total = AVG("AddAct") + m_Total;
                Matriz.Avg = AVG("AddAct");
            }

            // m_Total += m_Total;//AVG("AddAct"); 
            m_Registros.Dispose();
        }

        /// <summary>
        /// Fecha Modificacion: 08-Mayo-2013
        /// Usuario: Hugo Lopez
        /// 
        /// </summary>
        private void UserPuntualidad() {
            DataTable m_dtPuntualidad = new TIME_CMS_LOGIN_LOGOUTTableAdapter().GetDataBy(usr.Id, timeConsulta.Month, timeConsulta.Year);

            m_DiasLaborados = (int)new TIME_AGENT_SUMMARYTableAdapter().GetDataByUser(usr.Id, timeConsulta.Month, timeConsulta.Year);

            Matriz.DiasLaborados = m_DiasLaborados;

            Matriz.ProductivityUnitTarget = m_DiasLaborados * 42;

            if (m_dtPuntualidad.Rows.Count == 0) {
                Matriz.PuntualidadTarget = 0;
                Matriz.PuntualidadReach = 0;
                Matriz.NumeroDeRetardos = 0;
                Matriz.PromedioRetardo = 0;
            } else {

                double promedio = 0;
                double dub600 = 0;
                double dub540 = 0;

                TimesDA t = new TimesDA();
                int retardos_aux_daily = t.UserDelays(usr.Id, timeConsulta.Month, timeConsulta.Year);

                //promedio += m_retardos_lonche_min;
                promedio += retardos_aux_daily;

                DateTime tiempo, fecha;
                int Hor_ent = 0;

                int i_600 = 0;
                int i_540 = 0;

                List<DateTime> _FechasProcesadas = new List<DateTime>();

                foreach (DataRow dr in m_dtPuntualidad.Rows) {
                    tiempo = DateTime.Parse(dr["Login_Time"].ToString());
                    fecha = DateTime.Parse(dr[6].ToString());
                    Hor_ent = int.Parse(dr["Horario_Ent"].ToString());

                    dub600 = (tiempo.TimeOfDay.TotalMinutes - 605) % 605; //10
                    dub540 = (tiempo.TimeOfDay.TotalMinutes - 545) % 545; //9

                    if (fecha.DayOfWeek != DayOfWeek.Sunday && tiempo.DayOfWeek != DayOfWeek.Saturday
                        && tiempo.TimeOfDay.TotalMinutes < 1080 && !_FechasProcesadas.Contains(fecha)) {
                        _FechasProcesadas.Add(fecha);


                        //if (Math.Abs(dub600) > Math.Abs(dub540) && Hor_ent == 0)
                        // se comento la linea anterior ya que solo calculaba en segundos la hora de entra
                        // y se agrego el perfil al asuario para validar que este autorizado de entrar a las 10 ó 9
                        if (Hor_ent == 0) {
                            //if (tiempo.TimeOfDay.TotalMinutes > 545)
                            if (tiempo.TimeOfDay.TotalSeconds > 32700) //32700
                            {
                                promedio += dub540;
                                i_540++;
                            }
                        } else {
                            //if (tiempo.TimeOfDay.TotalMinutes > 605)
                            if (tiempo.TimeOfDay.TotalSeconds > 36300) //36300
                            {
                                promedio += dub600;
                                i_600++;
                            }
                        }
                    }
                }

                Matriz.PuntualidadTarget = Matriz.DiasLaborados;

                //Matriz.NumeroDeRetardos += m_retardos_lonche;
                Matriz.NumeroDeRetardos += retardos_aux_daily;


                if (i_540 > i_600) {
                    Matriz.NumeroDeRetardos += i_540;
                    promedio = promedio / Matriz.NumeroDeRetardos;

                    if (Matriz.NumeroDeRetardos > 3) { Matriz.PuntualidadReach = 0; } else { Matriz.PuntualidadReach = 100; }
                    //else if (i_540 >= 2 && i_540 < 3) { Matriz.PuntualidadReach = 50; }
                    //else if (i_540 >= 0 && i_540 < 1) { Matriz.PuntualidadReach = 100; }
                } else {
                    Matriz.NumeroDeRetardos += i_600;
                    promedio = promedio / Matriz.NumeroDeRetardos;

                    if (Matriz.NumeroDeRetardos > 3) { Matriz.PuntualidadReach = 0; } else { Matriz.PuntualidadReach = 100; }
                    //else if (i_600 >= 2 && i_600 < 3) { Matriz.PuntualidadReach = 50; }
                    //else if (i_600 >= 0 && i_600 <= 1) { Matriz.PuntualidadReach = 100; }
                }

                if (Matriz.NumeroDeRetardos > 3) {
                    Matriz.PuntualidadReach = 0;
                }

                DataTable Retardos = new TIME_FLEX_DATATableAdapter().GetDataBy(usr.Id, "Retardo", timeConsulta);

                Matriz.PuntualidadReach = (Matriz.PuntualidadReach * 10) / 100;

                Matriz.PromedioRetardo = (double.IsNaN(promedio) ? 0 : promedio);
            }

            m_dtPuntualidad.Dispose();
        }

        private void UserAsignaciones() {
            DataTable m_LFAsignaciones = new TIME_ASIGNACION_LASER_FICHE1TableAdapter().GetDataBy(timeConsulta.Month, timeConsulta.Year, usr.Id);

            if (m_LFAsignaciones.Rows.Count == 0) {
                Matriz.LasserFicheScore = 0;
            } else {
                decimal promedio = (decimal)new TIME_REGISTROS1TableAdapter().GetPromedio(timeConsulta.Year, timeConsulta.Month);

                double sala = double.Parse(m_LFAsignaciones.Rows[0][1].ToString());
                Matriz.LasserFicheScore = ((sala * 3.5) / 10);
                // regresar al calculo anterio
                // Matriz.LasserFicheScore = ((sala * (double)promedio) / 10);
            }

            m_LFAsignaciones.Dispose();
        }

        private void UserCalidadCalls() {
            DataTable dtCalidadCalls = new TIME_FLEX_DATATableAdapter().GetDataBy(usr.Id, "Calidad - Calls", timeConsulta);

            if (dtCalidadCalls.Rows.Count == 0) {
                Matriz.CallsTarget = 0;
                Matriz.CallsReach = 0;
            } else {
                Matriz.CallsTarget = double.Parse(dtCalidadCalls.Rows[dtCalidadCalls.Rows.Count - 1]["Flex_dec_01"].ToString());
                Matriz.CallsReach = (Matriz.CallsTarget * 22.5) / 95;
            }

            if (Matriz.CallsReach > 22.5) {
                Matriz.CallsReach = 22.5;
            }

            if (Matriz.ClaimsReach > 22.5) {
                Matriz.ClaimsReach = 22.5;
            }

            Matriz.CalidadReach = Matriz.CallsReach + Matriz.ClaimsReach;

            dtCalidadCalls.Dispose();
        }

        private void UserCalidadClaims() {
            DataTable dtCalidadClaims = new TIME_FLEX_DATATableAdapter().GetDataBy(usr.Id, "Calidad - Claims", timeConsulta);

            if (dtCalidadClaims.Rows.Count == 0) {
                Matriz.ClaimsTarget = 0;
                Matriz.ClaimsReach = 0;
            } else {
                Matriz.ClaimsTarget = double.Parse(dtCalidadClaims.Rows[dtCalidadClaims.Rows.Count - 1]["Flex_dec_01"].ToString());
                Matriz.ClaimsReach = (Matriz.ClaimsTarget * 22.5) / 97;
            }

            dtCalidadClaims.Dispose();
        }

        private void UserCorrespondencia() {
            DataTable dtCorrespondencia = new TIME_FLEX_DATATableAdapter().GetDataBy(usr.Id, "Correspondencia", timeConsulta);

            if (dtCorrespondencia.Rows.Count == 0) {
                Matriz.DHLScore = 0;
            } else {
                Matriz.DHLScore = double.Parse(dtCorrespondencia.Rows[dtCorrespondencia.Rows.Count - 1]["Flex_dec_01"].ToString());
            }

            dtCorrespondencia.Dispose();
        }



        private void UserActivity() {
            DataTable dtUserActivity = new TIME_CLAIM_USER_ACT1TableAdapter().GetData((decimal)m_Month, (decimal)m_Year, usr.Id);

            if (dtUserActivity.Rows.Count <= 0) {
                throw new Exception("El usuario no tiene datos para el mes y año seleccionados, favor de revisar.");
            }

            m_NumeroReclamaciones = 0;
            m_NumeroCCIN = 0;
            m_NumeroLlamadas = 0;
            m_payment_benefit = 0;

            double m_FAXIN = 0;
            double m_EMIN = 0;
            double m_LTIN = 0;

            foreach (DataRow dr in dtUserActivity.Rows) {
                DateTime dtime = DateTime.Parse(dr["Activity_Date"].ToString());

                // valida que solo sea dia habil
                // Usuario.: hlopez. 
                // Modificacion: 09 abril 2013
                //if (dtime.DayOfWeek != DayOfWeek.Saturday && dtime.DayOfWeek != DayOfWeek.Sunday)
                //{
                try { m_NumeroReclamaciones += int.Parse(dr["OP_CFIN"].ToString()); } catch { m_NumeroReclamaciones += 0; }

                try { m_NumeroCCIN += int.Parse(dr["OP_CCIN"].ToString()); } catch { m_NumeroCCIN += 0; }

                try { m_NumeroLlamadas += int.Parse(dr["ACD_Calls"].ToString()); } catch { m_NumeroLlamadas += 0; }

                try { m_payment_benefit += int.Parse(dr["Payment_Benefit"].ToString()); } catch { m_payment_benefit += 0; }

                try { m_FAXIN += int.Parse(dr["OP_FAXIN"].ToString()); } catch { m_FAXIN += 0; }

                try { m_EMIN += int.Parse(dr["OP_EMIN"].ToString()); } catch { m_EMIN += 0; }

                try { m_LTIN += int.Parse(dr["OP_LTIN"].ToString()); } catch { m_LTIN += 0; }
                //}
            }

            
            //Matriz.Corres = ((m_FAXIN + m_EMIN + m_LTIN) * 3.5) / 10;
            //Omar 20 Oct 2014: Actualizamos
            Matriz.Corres = ((m_FAXIN + m_EMIN + m_LTIN) * 16) / 10; //Corres

            //Matriz.CFINScore = (m_NumeroReclamaciones * 14) / 10;
            //Omar 20 Oct 2014: Actualizamos
            Matriz.CFINScore = (m_NumeroReclamaciones * 31) / 10; //CFIN

            //Matriz.CCINScore = ((m_NumeroCCIN + m_payment_benefit) * 3.5) / 10;
            //Omar 20 Oct 2014: Actualizamos
            Matriz.CCINScore = ((m_NumeroCCIN + m_payment_benefit) * 16) / 10; //CCIN

            Matriz.Avg_ACD_Time = (m_NumeroLlamadas * m_Avg_ACD_Time) / 600;

            Matriz.ACD_CallsScore = (m_NumeroLlamadas * m_Avg_ACD_Time) / 10;// (m_NumeroLlamadas * Matriz.Avg_ACD_Time) / 10;

            m_Total += Matriz.CFINScore + Matriz.CCINScore + Matriz.ACD_CallsScore + Matriz.Corres;

            dtUserActivity.Dispose();
        }

        private void ConsultaUsuario() {
            timeConsulta = new DateTime(int.Parse(m_Year.ToString()), int.Parse(m_Month.ToString()), 1);

            DataTable dtUsuario = new TIME_USUARIOSTableAdapter().GetDataById(m_UsuarioId);

            if (dtUsuario.Rows.Count != 1) {
                throw new Exception("No se encontro el usuario, intente de nuevo");
            }

            usr = new Usuario(dtUsuario.Rows[0]);

            Matriz.Nombre = usr.Nombre;
            Matriz.TIAUser = usr.TIAUser;

            dtUsuario.Dispose();
        }
    }
}