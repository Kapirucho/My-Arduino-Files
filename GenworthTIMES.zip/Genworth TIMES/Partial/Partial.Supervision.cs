using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Data;
using Genworth_TIMES.DataBase.TimeDataTableAdapters;
using Objetos;
using System.IO;
using System.Drawing;
using Genworth_TIMES.DataBase;

namespace Genworth_TIMES
{
    /// <summary>
    /// Objetos Compartidos
    /// </summary>
    partial class Supervision
    {
        private Usuario _Current_User = null;
        private Acciones _Acciones = null;
        private Tipos _Tipos = null;
        private Usuarios _Usuarios = null;
    }

    /// <summary>
    /// Partial Class for Users
    /// </summary>
    partial class Supervision
    {
        private void FillComboAsociados()
        {
            comboBox1.Items.Clear();
            comboBox1.Items.Add("Todos");
            foreach (Usuario Usr in _Usuarios._Usuarios)
            {
                comboBox1.Items.Add(Usr.Nombre);
            }
        }

        /// <summary>
        /// Deprecated Function, not deleted for future reference!
        /// </summary>
        /*
        private void Carga()
        {
            DateTime Inicial = dateTimePicker1.Value.AddDays(-5);
            DateTime Final = dateTimePicker1.Value.AddDays(2);
            Object[] coleccion;
            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Clear();
            dataGridView1.Columns.Add("Nombre", "Nombre");
            dataGridView1.Columns.Add("Id", "Id");
            dataGridView1.Columns[1].ReadOnly = true;
            dataGridView1.Columns[1].Visible = false;
            TimeSpan ts = Final.Subtract(Inicial);
            for (int b = 0; b < ts.Days; b++)
            {
                dataGridView1.Columns.Add(Inicial.AddDays(b).ToShortDateString(), Inicial.AddDays(b).ToShortDateString());
            }
            foreach (Usuario Usr in _Usuarios._Usuarios)
            {
                DataTable dt = new TIME_REC_POR_DIATableAdapter().GetData(Usr.Id, Inicial, Final);
                coleccion = new object[dataGridView1.Columns.Count];
                coleccion[0] = Usr.Nombre;
                coleccion[1] = Usr.Id;
                if (dt.Rows.Count > 0)
                {
                    for (int c = 2; c <= dataGridView1.Columns.Count; c++)
                    {
                        for (int a = 1; a <= dt.Rows.Count; a++)
                        {
                            try
                            {
                                if (DateTime.Parse(dataGridView1.Columns[c].Name).DayOfYear == ((DateTime)dt.Rows[a - 1]["Fecha"]).DayOfYear)
                                {
                                    String sd = dt.Rows[a - 1]["Fecha"].ToString();
                                    coleccion[c] = dt.Rows[a - 1]["Valor"].ToString();
                                }
                                else
                                {
                                    coleccion[c] = "";
                                }
                            }
                            catch (Exception) { }
                        }
                    }
                }
                else
                {
                    for (int v = 2; v < dataGridView1.Columns.Count; v++)
                    {
                        coleccion[v] = "";
                    }
                }
                dataGridView1.Rows.Add(coleccion);
            }
        }
        

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            //this.Carga();
        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1[e.ColumnIndex, e.RowIndex].Value.ToString() == "") { return; }
            DateTime dtime = Convert.ToDateTime(dataGridView1.Columns[e.ColumnIndex].Name);
            int Valor = Convert.ToInt32(dataGridView1[e.ColumnIndex, e.RowIndex].Value);
            int UserId = Convert.ToInt32(dataGridView1[1, e.RowIndex].Value);
            if (!Actualizar)
            {
                new TIME_REC_POR_DIATableAdapter().Insert1(Valor, dtime, UserId);
            }
            else
            {
                new TIME_REC_POR_DIATableAdapter().Update1(Valor, dtime, UserId);
                Actualizar = false;
            }
        }

        private bool Actualizar = false;
        private void dataGridView1_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dataGridView1[e.ColumnIndex, e.RowIndex].Value.ToString() != "")
            {
                Actualizar = true;
            }
        }
         * */
    }

    /// <summary>
    /// Partial Class for Reportes
    /// </summary>
    partial class Supervision
    {
        /// <summary>
        /// Estilo Inicial para datagridview2
        /// </summary>
        private void Estilo()
        {
            DataTable dt = new TIME_ACCIONESTableAdapter().GetHeaders();
            this.dataGridView2.Columns.Add("Fecha", "Fecha");
            this.dataGridView2.Columns.Add("Asociado", "Asociado");
            foreach (DataRow dr in dt.Rows)
            {
                this.dataGridView2.Columns.Add(dr["Nombre"].ToString(), dr["Nombre"].ToString());
            }
            dt.Dispose();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            dateTimePicker2_ValueChanged(sender, e);
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "" || comboBox1.Text == "Todos")
            {
                this.LoadData();
            }
            else
            {
                this.LoadDataForUser();
            }
        }

        private void LoadDataForUser()
        {
            dataGridView2.Rows.Clear();
            //DataTable dt = new ReporteoTableAdapter().GetDataByDate(dateTimePicker2.Value, dateTimePicker3.Value);

            Object[] Datos = new Object[dataGridView2.Columns.Count];
            DataTable dt = new DataTable();

            DateTime Inicio = Convert.ToDateTime(dateTimePicker2.Value.ToShortDateString());
            DateTime Final = Convert.ToDateTime(dateTimePicker3.Value.ToShortDateString()).AddDays(1);

            Usuario _usr = null;

            foreach (Usuario usr in _Usuarios._Usuarios)
            {
                if (usr.Nombre == comboBox1.Text)
                {
                    _usr = usr;
                    break;
                }
            }

            try
            {
                this.LoadDataForUser(_usr, Datos, dt, Inicio, Final);
            }
            catch (Exception) { }
            finally
            {
                dt.Dispose();
                Datos = null;
            }
        }

        private void LoadDataForUser(Usuario _usr, Object[] Datos, DataTable dt, DateTime Inicio, DateTime Final)
        {
            dt.Clear();
            dt = new ReportGetDataByUserAndDateTableAdapter().GetData(_usr.Id, Inicio, Final);
            if (dt.Rows.Count > 0)
            {
                List<String> fechas = new List<string>();

                for (int a = 0; a < dt.Rows.Count; a++)
                {
                    if (!fechas.Contains(dt.Rows[a]["Fecha"].ToString()))
                    {
                        fechas.Add(dt.Rows[a]["Fecha"].ToString());
                    }
                }

                foreach (String Fecha in fechas)
                {
                    Datos = new Object[dataGridView2.Columns.Count];

                    Datos[0] = Fecha;
                    Datos[1] = _usr.Nombre;

                    foreach (DataGridViewColumn dgvc in dataGridView2.Columns)
                    {
                        for (int a = 0; a < dt.Rows.Count; a++)
                        {
                            if (Fecha == dt.Rows[a]["Fecha"].ToString())
                            {
                                if (dt.Rows[a]["Accion"].ToString() == dgvc.Name)
                                {
                                    Datos[dgvc.Index] = decimal.Round(Convert.ToDecimal(Convert.ToDecimal(dt.Rows[a]["Diferencia"].ToString()) / 60), 3);
                                }
                            }
                        }
                    }

                    dataGridView2.Rows.Add(Datos);
                }
                fechas = null;
            }
        }

        private void LoadData()
        {
            dataGridView2.Rows.Clear();

            Object[] Datos = new Object[dataGridView2.Columns.Count];
            DataTable dt = new DataTable();

            DateTime Inicio = Convert.ToDateTime(dateTimePicker2.Value.ToShortDateString());
            DateTime Final = Convert.ToDateTime(dateTimePicker3.Value.ToShortDateString()).AddDays(1);

            foreach (Usuario Usr in _Usuarios._Usuarios)
            {
                try
                {
                    this.LoadDataForUser(Usr, Datos, dt, Inicio, Final);
                }
                catch (Exception) { }
                finally
                {
                    dt.Dispose();
                    Datos = null;
                }
            }
        }
    }

    /// <summary>
    /// Partial Class for data export
    /// </summary>
    partial class Supervision
    {
        private void exportarACSVToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FileStream FileCreated;
            saveFileDialog1.Filter = "CSV File|*.csv";
            saveFileDialog1.FileName = comboBox1.Text.Replace(" ", "_") + "_" + dateTimePicker2.Value.ToShortDateString().Replace("/", "") + "_" + dateTimePicker3.Value.ToShortDateString().Replace("/", "");
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                if (saveFileDialog1.FileName != "")
                {
                    try
                    {
                        FileCreated = (FileStream)saveFileDialog1.OpenFile();

                        using (StreamWriter sw = new StreamWriter(FileCreated, Encoding.Default))
                        {
                            StringBuilder sb = new StringBuilder();

                            foreach (DataGridViewColumn Cl in dataGridView2.Columns)
                            {
                                sb.Append(Cl.Name + "|");
                            }
                            sw.WriteLine(sb.ToString());

                            foreach (DataGridViewRow Row in dataGridView2.Rows)
                            {
                                sb = new StringBuilder();
                                foreach (DataGridViewCell obj in Row.Cells)
                                {
                                    try
                                    {
                                        if (obj.Value == null)
                                        {
                                            sb.Append("|");
                                        }
                                        else
                                        {
                                            sb.Append(obj.Value.ToString() + "|");
                                        }
                                    }
                                    catch (Exception) { }
                                }
                                sw.WriteLine(sb.ToString());
                            }
                        }
                        MessageBox.Show("El archivo se creo correctamente");
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Hubo un error al guardar el archivo, intente de nuevo");
                    }
                }
            }
        }
    }

    /// <summary>
    /// Porcion para acciones en tiempo real
    /// </summary>
    partial class Supervision
    {
        enum RTStatus
        {
            Normal,
            Advertencia,
            Peligro
        }

        private TimeData.CurrentDataTable _RealTimeData = new TimeData.CurrentDataTable();
        private TimeData.CurrentDataTable RealTimeData
        {
            get
            {
                return _RealTimeData;
            }
        }

        private RTStatus _Estatus = RTStatus.Normal;

        private void Iniciar()
        {
            this.dgv_realtime.Rows.Clear();
            if (this.RealTimeData.Rows.Count > 0)
            {
                this.dgv_realtime.Rows.Add(this.RealTimeData.Rows.Count);
                for (int a = 0; a < this.RealTimeData.Rows.Count; a++)
                {
                    this.dgv_realtime.Rows[a].Cells["Inicio"].Value = this.RealTimeData.Rows[a]["Start"];
                    this.dgv_realtime.Rows[a].Cells["Elapsed"].Value = this.FormatElapsed(DateTime.Now.Subtract((DateTime)this.RealTimeData.Rows[a]["Start"]), (int)this.RealTimeData.Rows[a]["MaxTime"]);
                    this.dgv_realtime.Rows[a].Cells["Accion"].Value = this.RealTimeData.Rows[a]["Nombre"];
                    this.dgv_realtime.Rows[a].Cells["Usuario"].Value = this.RealTimeData.Rows[a]["Usuario"];
                    if (_Estatus != RTStatus.Normal)
                    {
                        if (_Estatus == RTStatus.Advertencia)
                        {
                            this.dgv_realtime.Rows[a].DefaultCellStyle.BackColor = Color.Yellow;
                        }
                        else if (_Estatus == RTStatus.Peligro)
                        {
                            this.dgv_realtime.Rows[a].DefaultCellStyle.BackColor = Color.Red;
                        }
                    }
                }
            }
        }

        private String FormatElapsed(TimeSpan ts, int MaxTime)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(ts.Days.ToString() + ":");
            sb.Append(ts.Hours.ToString() + ":");
            sb.Append(ts.Minutes.ToString() + ":");
            sb.Append(ts.Seconds.ToString());
            if (ts.Minutes >= MaxTime - 1 && ts.Minutes < MaxTime && MaxTime != 0)
            {
                _Estatus = RTStatus.Advertencia;
            }
            else if (ts.Minutes >= MaxTime && MaxTime != 0)
            {
                _Estatus = RTStatus.Peligro;
            }
            else
            {
                _Estatus = RTStatus.Normal;
            }
            return sb.ToString();
        }

        private void RetriveData()
        {
            new CurrentTableAdapter().Fill(_RealTimeData);
        }

        private void InitDgv()
        {
            this.dgv_realtime.Columns.Add("Usuario", "Usuario");
            this.dgv_realtime.Columns.Add("Inicio", "Inicio");
            this.dgv_realtime.Columns.Add("Elapsed", "Tiempo Transcurrido");
            this.dgv_realtime.Columns.Add("Accion", "Acci�n");
        }
    }
}
