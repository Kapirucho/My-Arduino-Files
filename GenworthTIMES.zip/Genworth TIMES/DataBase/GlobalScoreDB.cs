﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Genworth.Data;
using DatosDA;

namespace Genworth_TIMES.DataBase
{
    class GlobalScoreDB : DatosDA.BaseDA
    {
        public GlobalScoreDB()
            : base()
        {

        }
    }
}
