﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Genworth_TIMES.DataBase {
    public class ParameterBE {
        private string m_nombre;
        private decimal m_valor;

        public decimal Valor {
            get { return m_valor; }
            set { m_valor = value; }
        }

        public string Nombre {
            get { return m_nombre; }
            set { m_nombre = value; }
        }



    }
}
