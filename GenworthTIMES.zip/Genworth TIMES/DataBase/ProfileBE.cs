﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Genworth_TIMES.DataBase {
    public class ProfileBE {
        private int m_UserId;
        private string m_Nombre = string.Empty;
        private string m_SSO = string.Empty;
        private string m_TIA_User = string.Empty;
        private int m_Entrada;

        public int UserId {
            get { return m_UserId; }
            set { m_UserId = value; }
        }
        public string Nombre {
            get { return m_Nombre; }
            set { m_Nombre = value; }
        }
        public string SSO {
            get { return m_SSO; }
            set { m_SSO = value; }
        }


        public string TIA_User {
            get { return m_TIA_User; }
            set { m_TIA_User = value; }
        }
        public int Entrada {
            get { return m_Entrada; }
            set { m_Entrada = value; }
        }
    }
}
