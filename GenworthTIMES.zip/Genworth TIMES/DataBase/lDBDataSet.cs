﻿namespace Genworth_TIMES.DataBase {
    
    
    public partial class lDBDataSet {
        partial class TIME_USUARIOSDataTable {
        }
    }
}

namespace Genworth_TIMES.DataBase.lDBDataSetTableAdapters {
    
    
    public partial class TIME_ACCIONESTableAdapter {
    }
}

namespace Genworth_TIMES.lDBDataSetTableAdapters {
    partial class ReporteTableAdapter {
    }

    partial class TIME_LOGINTableAdapter {
    }
    
    
    public partial class TIME_USUARIOSTableAdapter {
    }
}
