﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DatosDA;
using System.Data.SqlClient;
using System.Data;
using Genworth.Data;
using Genworth_TIMES.Clase;


namespace Genworth_TIMES.DataBase {
    public class TimesDA : BaseDA {
        public TimesDA() : base() {
        }
        public List<ParameterBE> GetParameterTimes() {
            IDataReader reader;

            CreateParameterCollection();
            AddParameter("@opcion", SqlDbType.TinyInt, ParameterDirection.Input, 1);
            reader = SqlHelper.ExecuteReader(connectionString, CommandType.StoredProcedure, "PRODUSR.USP_GET_PARAMETROS", Parameters);

            List<ParameterBE> lst = new List<ParameterBE>();

            while (reader.Read()) {
                ParameterBE p = new ParameterBE();
                p.Nombre = reader["Nombre"].ToString();
                p.Valor = decimal.Parse(reader["Valor"].ToString());
                lst.Add(p);
            }

            return lst;
        }

        public List<Catalogo> CatalogColection()
        {
            string sql = "SELECT * FROM dbo.vw_catalog";

            this.CreateTransaction();
            this.CreateSqlCommand(sql, false);

            DataTable dt = SqlHelper.ExecuteQuery(this.transaction, CommandType.Text, this.command);

            List<Catalogo> ct = new List<Catalogo>();
            for (int a = 0; a < dt.Rows.Count; a++)
            {
                //s.Add(new string[] { dt.Rows[a]["DATA"].ToString(), dt.Rows[a]["VALUE"].ToString() });
                ct.Add(new Catalogo(int.Parse(dt.Rows[a]["ID"].ToString()),
                                    dt.Rows[a]["DATA"].ToString(),
                                    int.Parse(dt.Rows[a]["VALUE"].ToString()),
                                    int.Parse(dt.Rows[a]["CATALOG_ID"].ToString()),
                                    dt.Rows[a]["DEFINITION"].ToString()));
            }

            return ct;
        }

        public List<string[]> SelectClient(int Value)
        {
            string sql = "SELECT * FROM dbo.vw_catalog where CATALOG_ID = @Cat and VALUE = @Val";

            CreateParameterCollection();
            AddParameter("@Cat", SqlDbType.Int, ParameterDirection.Input, 4);
            AddParameter("@Val", SqlDbType.Int, ParameterDirection.Input, Value);

            this.CreateTransaction();
            this.CreateSqlCommand(sql);
            DataTable dt = SqlHelper.ExecuteQuery(this.transaction, CommandType.Text, this.command);

            List<string[]> s = new List<string[]>();

            for (int a = 0; a < dt.Rows.Count; a++)
            {
                s.Add(new string[] { dt.Rows[a]["DATA"].ToString(), dt.Rows[a]["VALUE"].ToString() });
            }

            return s;
        }

        public List<string[]> SelectCatalog(int Cat)
        {
            string sql = "SELECT * FROM dbo.vw_catalog where CATALOG_ID = @Cat";

            CreateParameterCollection();
            AddParameter("@Cat", SqlDbType.Int, ParameterDirection.Input, Cat);

            this.CreateTransaction();
            this.CreateSqlCommand(sql);
            DataTable dt = SqlHelper.ExecuteQuery(this.transaction, CommandType.Text, this.command);

            List<string[]> s = new List<string[]>();

            for (int a = 0; a < dt.Rows.Count; a++)
            {
                s.Add(new string[]{dt.Rows[a]["DATA"].ToString(), dt.Rows[a]["VALUE"].ToString()});
            }

            return s;
        }

        public int UpdateParameterTimes(decimal Activities, decimal AVG, decimal Corres, decimal CFINScore, decimal CCINScore)
        {

            CreateParameterCollection();
            AddParameter("@opcion", SqlDbType.TinyInt, ParameterDirection.Input, 2);
            AddParameter("@activities", SqlDbType.Decimal, ParameterDirection.Input, Activities);
            AddParameter("@corres", SqlDbType.Decimal, ParameterDirection.Input, Corres);
            AddParameter("@cfinscore", SqlDbType.Decimal, ParameterDirection.Input, CFINScore);
            AddParameter("@ccinscore", SqlDbType.Decimal, ParameterDirection.Input, CCINScore);
            AddParameter("@avg", SqlDbType.Decimal, ParameterDirection.Input, AVG);

            int i = SqlHelper.ExecuteNonQuery(connectionString, CommandType.StoredProcedure, "USP_GET_PARAMETROS", Parameters);

            return i;
        }
        public double GetAVG_ACT(string nombre) {
            IDataReader reader;

            CreateParameterCollection();
            AddParameter("@opcion", SqlDbType.TinyInt, ParameterDirection.Input, 3);
            AddParameter("@nombre", SqlDbType.NVarChar, ParameterDirection.Input, nombre);

            reader = SqlHelper.ExecuteReader(connectionString, CommandType.StoredProcedure, "PRODUSR.USP_GET_PARAMETROS", Parameters);

            double avg = 0;

            while (reader.Read()) {
                avg = double.Parse(reader["Valor"].ToString());
            }
            return avg;


        }

        public List<ProfileBE> GetUserProfle() {
            IDataReader reader;

            CreateParameterCollection();
            AddParameter("@opcion", SqlDbType.TinyInt, ParameterDirection.Input, 1);
            reader = SqlHelper.ExecuteReader(connectionString, CommandType.StoredProcedure, "PRODUSR.USP_USER_PROFILE", Parameters);

            List<ProfileBE> lst = new List<ProfileBE>();

            while (reader.Read()) {
                ProfileBE p = new ProfileBE();
                p.UserId = int.Parse(reader["Id"].ToString());
                p.Nombre = reader["Nombre"].ToString();
                p.SSO = reader["Usuario"].ToString();
                p.TIA_User = reader["Usrmx"].ToString();
                p.Entrada = int.Parse(reader["Entrada"].ToString());
                lst.Add(p);
            }

            return lst;
        }

        public int UpdateUserProfile(int Entrada, int UserId) {
            CreateParameterCollection();
            AddParameter("@opcion", SqlDbType.TinyInt, ParameterDirection.Input, 2);
            AddParameter("@userid", SqlDbType.Int, ParameterDirection.Input, UserId);
            AddParameter("@entrada", SqlDbType.Int, ParameterDirection.Input, Entrada);

            int i = SqlHelper.ExecuteNonQuery(connectionString, CommandType.StoredProcedure, "PRODUSR.USP_USER_PROFILE", Parameters);

            return i;
        }

        public int ValidarSupervisor(string sso) {
            IDataReader reader;

            CreateParameterCollection();
            AddParameter("@opcion", SqlDbType.TinyInt, ParameterDirection.Input, 3);
            AddParameter("@sso", SqlDbType.NVarChar, ParameterDirection.Input, sso);

            reader = SqlHelper.ExecuteReader(connectionString, CommandType.StoredProcedure, "PRODUSR.USP_USER_PROFILE", Parameters);

            int res = 0;

            while (reader.Read()) {
                res = int.Parse(reader["existe"].ToString());
            }
            return res;


        }

        public int UserDelays(int UserId, int Mes, int Anio) {
            IDataReader reader;

            CreateParameterCollection();
            AddParameter("@opcion", SqlDbType.TinyInt, ParameterDirection.Input, 1);
            AddParameter("@userid", SqlDbType.Int, ParameterDirection.Input, UserId);
            AddParameter("@mes", SqlDbType.Int, ParameterDirection.Input, Mes);
            AddParameter("@anio", SqlDbType.Int, ParameterDirection.Input, Anio);



            reader = SqlHelper.ExecuteReader(connectionString, CommandType.StoredProcedure, ".USP_USER_DELAYS", Parameters);

            int res = 0;

            while (reader.Read()) {
                res = int.Parse(reader["Retardos_LB"].ToString());
            }
            return res;
        }




    }
}
