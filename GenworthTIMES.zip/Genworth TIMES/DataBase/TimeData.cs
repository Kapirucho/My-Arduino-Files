﻿namespace Genworth_TIMES.DataBase
{


    partial class TimeData
    {
        partial class TIME_USUARIOSDataTable {
        }
    
        partial class TIME_CLAIM_USER_ACT1DataTable
        {
        }
    
        partial class TIME_CMS_LOGIN_LOGOUTDataTable
        {
        }
    
        partial class TIME_REGISTROSDataTable
        {
        }
    }
}

namespace Genworth_TIMES.DataBase.TimeDataTableAdapters {
    partial class TIME_CMS_LOGIN_LOGOUTTableAdapter
    {
    }
    
    
    public partial class TIME_REGISTROS1TableAdapter {
    }
}


