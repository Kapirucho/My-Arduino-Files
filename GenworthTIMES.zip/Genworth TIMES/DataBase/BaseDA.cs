﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DatosDA {
    public abstract class BaseDA {
        #region Attributes
        private SqlConnection connection;
        protected string connectionString;


        protected bool isTransaction;
        protected SqlTransaction transaction;

        protected List<SqlParameter> parameters;

        protected SqlCommand command;

        #endregion
        #region Constructors
        /// <summary>
        /// Constructor for new database
        /// </summary>
        protected BaseDA() {
            //string instancia = ConfigurationManager.AppSettings["dbInstance"];
            connectionString = ConfigurationManager.ConnectionStrings["Genworth_TIMES.Properties.Settings.MXOSPRODConnectionString"].ConnectionString;

        }
        #endregion

        #region Properties
        /// <summary>
        /// New transaction
        /// </summary>
        public IDbTransaction Transaction {
            get { return transaction; }
            set {
                transaction = (SqlTransaction)value;
                this.isTransaction = true;
            }
        }
        /// <summary>
        /// Sql Connection
        /// </summary>
        public IDbConnection Connection {
            get { return connection; }
            set { connection = (SqlConnection)value; }
        }
        /// <summary>
        /// Sql Parameters
        /// </summary>
        protected SqlParameter[] Parameters {
            get {
                return parameters.ToArray();
            }
        }
        /// <summary>
        /// Is SQL Transaction
        /// </summary>
        public bool IsTransaction {
            get { return isTransaction; }
        }
        #endregion
        #region Methods
        protected void CreateParameterCollection() {
            parameters = new List<SqlParameter>();

        }

        /// <summary>
        /// Add parameter to sql
        /// </summary>
        /// <param name="name">Parameter name</param>
        /// <param name="type">parameter SQL DbType</param>
        /// <param name="size">Parameter size</param>
        /// <param name="direction">In or Out Parameter</param>
        /// <param name="value">Parameter Value</param>
        protected void AddParameter(string name, SqlDbType type, int size, ParameterDirection direction, object value) {
            SqlParameter param = new SqlParameter(name, type, size);
            param.Direction = direction;
            param.Value = value;
            parameters.Add(param);
        }

        //SqlParameter("@ESTATUSORDENCOMPRA", SqlDbType.NVarChar, 10);
        /// <summary>
        /// Add parameter without size
        /// </summary>
        /// <param name="name">parameter name</param>
        /// <param name="type">parameter type</param>
        /// <param name="direction">parameter direction in or out</param>
        /// <param name="value">parameter value</param>
        protected void AddParameter(string name, SqlDbType type, ParameterDirection direction, object value) {
            SqlParameter param = new SqlParameter(name, type);
            param.Direction = direction;
            param.Value = value;
            parameters.Add(param);
        }

        /// <summary>
        /// Add parameter
        /// </summary>
        /// <param name="parameter">Sqlparameter data</param>
        protected void AddParameter(SqlParameter parameter) {
            parameters.Add(parameter);

        }

        /// <summary>
        /// Create sql command from
        /// </summary>
        /// <param name="query">Query text</param>
        /// <param name="Params">has parameters?</param>
        public void CreateSqlCommand(String query, Boolean Params = true)
        {
            command = new SqlCommand(query);
            if (Params)
            {
                command.Parameters.AddRange(this.Parameters);
            }
            
        }

        /// <summary>
        /// Create new transaction
        /// </summary>
        public void CreateTransaction() {


            connection = new SqlConnection(connectionString);
            connection.Open();
            Transaction = connection.BeginTransaction();
        }

        /// <summary>
        /// Cancel transaction and rolback
        /// </summary>
        public void CancelTransaction() {
            if (transaction != null && connection != null) {
                if (connection.State == ConnectionState.Open) {
                    transaction.Rollback();
                    connection.Close();
                } else
                    throw new ApplicationException("Se requiere una conexion y transaccion validas.");
            } else
                throw new ApplicationException("Se requiere una conexion y transaccion validas.");

        }

        /// <summary>
        /// Commit transaction
        /// </summary>
        public void CommitTransaction() {
            if (transaction != null && connection != null) {
                if (connection.State == ConnectionState.Open) {
                    transaction.Commit();
                    connection.Close();
                } else
                    throw new ApplicationException("Se requiere una conexion y transaccion validas.");
            } else
                throw new ApplicationException("Se requiere una conexion y transaccion validas.");

        }
        #endregion
    }
}
