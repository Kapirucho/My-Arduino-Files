
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, and Azure
-- --------------------------------------------------
-- Date Created: 11/24/2010 13:29:12
-- Generated from EDMX file: C:\Documents and Settings\430002893\My Documents\Visual Studio 2010\Projects\Genworth TIMES\Genworth TIMES\Model1.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [MXOSDEVL];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK_TIME_AGENT_SUMMARY_TIME_AGENT_SUMMARY]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TIME_AGENT_SUMMARY] DROP CONSTRAINT [FK_TIME_AGENT_SUMMARY_TIME_AGENT_SUMMARY];
GO

-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[TIME_ACCIONES]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TIME_ACCIONES];
GO
IF OBJECT_ID(N'[MXOSDEVLModelStoreContainer].[TIME_ACCIONES_BACK]', 'U') IS NOT NULL
    DROP TABLE [MXOSDEVLModelStoreContainer].[TIME_ACCIONES_BACK];
GO
IF OBJECT_ID(N'[dbo].[TIME_AGENT_SUMMARY]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TIME_AGENT_SUMMARY];
GO
IF OBJECT_ID(N'[dbo].[TIME_ASIGNACION_LASER_FICHE]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TIME_ASIGNACION_LASER_FICHE];
GO
IF OBJECT_ID(N'[dbo].[TIME_AUX_DAILY]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TIME_AUX_DAILY];
GO
IF OBJECT_ID(N'[dbo].[TIME_CLAIM_USER_ACT]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TIME_CLAIM_USER_ACT];
GO
IF OBJECT_ID(N'[dbo].[TIME_CMS_LOGIN_LOGOUT]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TIME_CMS_LOGIN_LOGOUT];
GO
IF OBJECT_ID(N'[MXOSDEVLModelStoreContainer].[TIME_CURRENT]', 'U') IS NOT NULL
    DROP TABLE [MXOSDEVLModelStoreContainer].[TIME_CURRENT];
GO
IF OBJECT_ID(N'[dbo].[TIME_FLEX_DATA]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TIME_FLEX_DATA];
GO
IF OBJECT_ID(N'[MXOSDEVLModelStoreContainer].[TIME_REC_POR_DIA]', 'U') IS NOT NULL
    DROP TABLE [MXOSDEVLModelStoreContainer].[TIME_REC_POR_DIA];
GO
IF OBJECT_ID(N'[MXOSDEVLModelStoreContainer].[TIME_REGISTROS]', 'U') IS NOT NULL
    DROP TABLE [MXOSDEVLModelStoreContainer].[TIME_REGISTROS];
GO
IF OBJECT_ID(N'[dbo].[TIME_TIPOS]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TIME_TIPOS];
GO
IF OBJECT_ID(N'[dbo].[TIME_USUARIOS]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TIME_USUARIOS];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'TIME_ACCIONES'
CREATE TABLE [dbo].[TIME_ACCIONES] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Nombre] varchar(50)  NOT NULL,
    [Tipo] decimal(18,0)  NULL,
    [msrepl_tran_version] uniqueidentifier  NOT NULL
);
GO

-- Creating table 'TIME_ACCIONES_BACK'
CREATE TABLE [dbo].[TIME_ACCIONES_BACK] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Nombre] varchar(50)  NOT NULL,
    [Tipo] decimal(18,0)  NULL
);
GO

-- Creating table 'TIME_AGENT_SUMMARY'
CREATE TABLE [dbo].[TIME_AGENT_SUMMARY] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Usuario] int  NULL,
    [Date] datetime  NULL,
    [ACD_Calls] decimal(18,0)  NULL,
    [Avg_ACD_Time] varchar(50)  NULL,
    [ACD_Time] varchar(50)  NULL,
    [ACW_Time] varchar(50)  NULL,
    [AUX_Time] varchar(50)  NULL,
    [Avail_Time] varchar(50)  NULL,
    [Staffed_Time] varchar(50)  NULL,
    [msrepl_tran_version] uniqueidentifier  NOT NULL
);
GO

-- Creating table 'TIME_ASIGNACION_LASER_FICHE'
CREATE TABLE [dbo].[TIME_ASIGNACION_LASER_FICHE] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Fk_Usuario_Id] int  NULL,
    [Nombre] varchar(50)  NULL,
    [Fecha_Recepcion_CFIN] datetime  NULL,
    [Fecha_de_creacion] datetime  NULL,
    [Creado_por_SSO] int  NULL,
    [Ultima_Modificacion] datetime  NULL,
    [Enviado_por] varchar(50)  NULL,
    [Volumen] varchar(50)  NULL,
    [Paginas] int  NULL,
    [Nombre_de_plantilla] varchar(50)  NULL,
    [Ruta] varchar(50)  NULL,
    [Etiquetas] varchar(max)  NULL,
    [Cliente] varchar(50)  NULL,
    [msrepl_tran_version] uniqueidentifier  NOT NULL
);
GO

-- Creating table 'TIME_AUX_DAILY'
CREATE TABLE [dbo].[TIME_AUX_DAILY] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Usuario] int  NOT NULL,
    [Time_in_0] varchar(50)  NULL,
    [Time_in_Break] varchar(50)  NULL,
    [Time_in_Lunch] varchar(50)  NULL,
    [Time_in_Training] varchar(50)  NULL,
    [Time_in_Feedback] varchar(50)  NULL,
    [Time_in_Meeting] varchar(50)  NULL,
    [Time_in_Additional] varchar(50)  NULL,
    [Time_in_Activities] varchar(50)  NULL,
    [Date] datetime  NULL,
    [msrepl_tran_version] uniqueidentifier  NOT NULL
);
GO

-- Creating table 'TIME_CLAIM_USER_ACT'
CREATE TABLE [dbo].[TIME_CLAIM_USER_ACT] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Activity_Date] datetime  NULL,
    [Userid] varchar(50)  NULL,
    [OP_CFIN] decimal(18,0)  NULL,
    [OP_CCIN] decimal(18,0)  NULL,
    [msrepl_tran_version] uniqueidentifier  NOT NULL
);
GO

-- Creating table 'TIME_CMS_LOGIN_LOGOUT'
CREATE TABLE [dbo].[TIME_CMS_LOGIN_LOGOUT] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Fk_Usuario_Id] int  NULL,
    [Agent_Name] varchar(50)  NULL,
    [Extn] int  NULL,
    [Login_Time] datetime  NULL,
    [Logout_Time] datetime  NULL,
    [Logout_Date] datetime  NULL,
    [Logout_Reason] varchar(50)  NULL,
    [Skill_1] int  NULL,
    [Skill_2] int  NULL,
    [Skill_3] int  NULL,
    [Skill_4] int  NULL,
    [Skill_5] int  NULL,
    [Skill_6] int  NULL,
    [Skill_7] int  NULL,
    [Skill_8] int  NULL,
    [Skill_9] int  NULL,
    [Skill_10] int  NULL,
    [Skill_11] int  NULL,
    [Skill_12] int  NULL,
    [Skill_13] int  NULL,
    [Skill_14] int  NULL,
    [Skill_15] int  NULL,
    [msrepl_tran_version] uniqueidentifier  NOT NULL
);
GO

-- Creating table 'TIME_CURRENT'
CREATE TABLE [dbo].[TIME_CURRENT] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Start] datetime  NOT NULL,
    [Accion_Id] int  NOT NULL,
    [Usuario_Id] int  NOT NULL,
    [MaxTime] int  NOT NULL
);
GO

-- Creating table 'TIME_FLEX_DATA'
CREATE TABLE [dbo].[TIME_FLEX_DATA] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Fk_User_Id] int  NULL,
    [Identifier] varchar(50)  NOT NULL,
    [Flex_char_01] varchar(50)  NULL,
    [Flex_char_02] varchar(50)  NULL,
    [Flex_char_03] varchar(50)  NULL,
    [Flex_char_04] varchar(50)  NULL,
    [Flex_char_05] varchar(50)  NULL,
    [Flex_char_06] varchar(50)  NULL,
    [Flex_char_07] varchar(50)  NULL,
    [Flex_char_08] varchar(50)  NULL,
    [Flex_char_09] varchar(50)  NULL,
    [Flex_char_10] varchar(50)  NULL,
    [Flex_date_01] datetime  NULL,
    [Flex_date_02] datetime  NULL,
    [Flex_date_03] datetime  NULL,
    [Flex_date_04] datetime  NULL,
    [Flex_date_05] datetime  NULL,
    [Flex_num_01] int  NULL,
    [Flex_num_02] int  NULL,
    [Flex_num_03] int  NULL,
    [Flex_num_04] int  NULL,
    [Flex_num_05] int  NULL,
    [Flex_dec_01] decimal(18,2)  NULL,
    [Flex_dec_02] decimal(18,2)  NULL,
    [Flex_dec_03] decimal(18,2)  NULL,
    [Flex_dec_04] decimal(18,2)  NULL,
    [Flex_dec_05] decimal(18,2)  NULL,
    [msrepl_tran_version] uniqueidentifier  NOT NULL
);
GO

-- Creating table 'TIME_REC_POR_DIA'
CREATE TABLE [dbo].[TIME_REC_POR_DIA] (
    [Id] decimal(18,0) IDENTITY(1,1) NOT NULL,
    [Valor] decimal(3,0)  NOT NULL,
    [Fecha] datetime  NOT NULL,
    [Usuario] decimal(18,0)  NOT NULL
);
GO

-- Creating table 'TIME_REGISTROS'
CREATE TABLE [dbo].[TIME_REGISTROS] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Accion] decimal(18,0)  NOT NULL,
    [Tipo] decimal(18,0)  NOT NULL,
    [Usuario] decimal(18,0)  NOT NULL,
    [Inicio] datetime  NOT NULL,
    [Final] datetime  NOT NULL,
    [Descripcion] varchar(max)  NOT NULL
);
GO

-- Creating table 'TIME_TIPOS'
CREATE TABLE [dbo].[TIME_TIPOS] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Nombre] varchar(50)  NOT NULL,
    [msrepl_tran_version] uniqueidentifier  NOT NULL
);
GO

-- Creating table 'TIME_USUARIOS'
CREATE TABLE [dbo].[TIME_USUARIOS] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Nombre] varchar(50)  NOT NULL,
    [Usuario] varchar(50)  NOT NULL,
    [Password] varchar(50)  NOT NULL,
    [Admin] int  NOT NULL,
    [Tipo] decimal(18,0)  NULL,
    [Usrmx] varchar(50)  NULL,
    [Nombre_2] varchar(50)  NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [Id] in table 'TIME_ACCIONES'
ALTER TABLE [dbo].[TIME_ACCIONES]
ADD CONSTRAINT [PK_TIME_ACCIONES]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id], [Nombre] in table 'TIME_ACCIONES_BACK'
ALTER TABLE [dbo].[TIME_ACCIONES_BACK]
ADD CONSTRAINT [PK_TIME_ACCIONES_BACK]
    PRIMARY KEY CLUSTERED ([Id], [Nombre] ASC);
GO

-- Creating primary key on [Id] in table 'TIME_AGENT_SUMMARY'
ALTER TABLE [dbo].[TIME_AGENT_SUMMARY]
ADD CONSTRAINT [PK_TIME_AGENT_SUMMARY]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'TIME_ASIGNACION_LASER_FICHE'
ALTER TABLE [dbo].[TIME_ASIGNACION_LASER_FICHE]
ADD CONSTRAINT [PK_TIME_ASIGNACION_LASER_FICHE]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'TIME_AUX_DAILY'
ALTER TABLE [dbo].[TIME_AUX_DAILY]
ADD CONSTRAINT [PK_TIME_AUX_DAILY]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'TIME_CLAIM_USER_ACT'
ALTER TABLE [dbo].[TIME_CLAIM_USER_ACT]
ADD CONSTRAINT [PK_TIME_CLAIM_USER_ACT]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'TIME_CMS_LOGIN_LOGOUT'
ALTER TABLE [dbo].[TIME_CMS_LOGIN_LOGOUT]
ADD CONSTRAINT [PK_TIME_CMS_LOGIN_LOGOUT]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id], [Start], [Accion_Id], [Usuario_Id], [MaxTime] in table 'TIME_CURRENT'
ALTER TABLE [dbo].[TIME_CURRENT]
ADD CONSTRAINT [PK_TIME_CURRENT]
    PRIMARY KEY CLUSTERED ([Id], [Start], [Accion_Id], [Usuario_Id], [MaxTime] ASC);
GO

-- Creating primary key on [Id] in table 'TIME_FLEX_DATA'
ALTER TABLE [dbo].[TIME_FLEX_DATA]
ADD CONSTRAINT [PK_TIME_FLEX_DATA]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id], [Valor], [Fecha], [Usuario] in table 'TIME_REC_POR_DIA'
ALTER TABLE [dbo].[TIME_REC_POR_DIA]
ADD CONSTRAINT [PK_TIME_REC_POR_DIA]
    PRIMARY KEY CLUSTERED ([Id], [Valor], [Fecha], [Usuario] ASC);
GO

-- Creating primary key on [Id], [Accion], [Tipo], [Usuario], [Inicio], [Final], [Descripcion] in table 'TIME_REGISTROS'
ALTER TABLE [dbo].[TIME_REGISTROS]
ADD CONSTRAINT [PK_TIME_REGISTROS]
    PRIMARY KEY CLUSTERED ([Id], [Accion], [Tipo], [Usuario], [Inicio], [Final], [Descripcion] ASC);
GO

-- Creating primary key on [Id] in table 'TIME_TIPOS'
ALTER TABLE [dbo].[TIME_TIPOS]
ADD CONSTRAINT [PK_TIME_TIPOS]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'TIME_USUARIOS'
ALTER TABLE [dbo].[TIME_USUARIOS]
ADD CONSTRAINT [PK_TIME_USUARIOS]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [Id] in table 'TIME_AGENT_SUMMARY'
ALTER TABLE [dbo].[TIME_AGENT_SUMMARY]
ADD CONSTRAINT [FK_TIME_AGENT_SUMMARY_TIME_AGENT_SUMMARY]
    FOREIGN KEY ([Id])
    REFERENCES [dbo].[TIME_AGENT_SUMMARY]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------