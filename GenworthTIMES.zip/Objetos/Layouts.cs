using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Genworth_TIMES {
    interface iLayout {
        void InsertToDataBase(string[] data);
    }

    class Layouts {
        #region Enunciados
        public enum Formato {
            CMS_Agent_Summary_Daily,
            Aux_Daily,
            Claim_User_Activity,
            CMS_Login_Logout,
            Laser_Fiche_Asignacion
        }
        #endregion

        #region Agent Summary Daily
        /// <summary>
        /// Agent Summary Daily
        /// </summary>
        public class CMS_ASD : iLayout {
            public CMS_ASD() {

            }

            #region iLayout Members

            public void InsertToDataBase(string[] data) {

            }

            #endregion
        }
        #endregion

        #region Aux Daily
        /// <summary>
        /// Aux Daily
        /// </summary>
        public class AD : iLayout {

            #region iLayout Members

            public void InsertToDataBase(string[] data) {
                throw new Exception("The method or operation is not implemented.");
            }

            #endregion
        }
        #endregion

        #region SLA Global Score
        /// <summary>
        /// SLA Global Score
        /// </summary>
        public class LFA : iLayout {

            #region iLayout Members

            public void InsertToDataBase(string[] data) {
                throw new Exception("The method or operation is not implemented.");
            }

            #endregion
        }
        #endregion

        #region Claim User Activity
        /// <summary>
        /// Claim User Activity
        /// </summary>
        public class CUA : iLayout {

            #region iLayout Members

            public void InsertToDataBase(string[] data) {
                throw new Exception("The method or operation is not implemented.");
            }

            #endregion
        }
        #endregion

        #region CMS Agent Login Logout
        public class CMS_ALL : iLayout {

            #region iLayout Members

            public void InsertToDataBase(string[] data) {
                throw new Exception("The method or operation is not implemented.");
            }

            #endregion
        }
        #endregion
    }

    class ReadFiles {
        private FileInfo m_FI;
        private Layouts.Formato m_Formato;
        private iLayout m_Layout;
        private char m_Separator;
        public ReadFiles(String FileName, Layouts.Formato Formato, char Separador) {
            m_FI = new FileInfo(FileName);
            m_Formato = Formato;
            m_Separator = Separador;
        }

        private void IniciarliarObjetos() {
            switch (m_Formato) {
                case Layouts.Formato.CMS_Agent_Summary_Daily:
                    m_Layout = new Layouts.CMS_ASD();
                    break;
                case Layouts.Formato.Aux_Daily:
                    m_Layout = new Layouts.AD();
                    break;
                case Layouts.Formato.Claim_User_Activity:
                    m_Layout = new Layouts.CUA();
                    break;
                case Layouts.Formato.Laser_Fiche_Asignacion:
                    m_Layout = new Layouts.LFA();
                    break;
                case Layouts.Formato.CMS_Login_Logout:
                    m_Layout = new Layouts.CMS_ALL();
                    break;
            }
        }

        private void IniciarLectura() {
            using (StreamReader sr = new StreamReader(m_FI.FullName)) {
                while (!sr.EndOfStream) {
                    string[] data = sr.ReadLine().Split(new char[] { this.m_Separator });
                    m_Layout.InsertToDataBase(data);
                }
            }
        }
    }
}
