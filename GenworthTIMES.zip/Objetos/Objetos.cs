using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;

namespace Objetos {

    /// <summary>
    /// Global variables needed to update info into database
    /// </summary>
    public class GlobalValues
    {
        private List<string[]> _Documents;
        /// <summary>
        /// List of documents for global score
        /// </summary>
        public List<string[]> Documents
        {
            get { return _Documents; }
            set { _Documents = value; }
        }

        private string _Country = string.Empty;
        /// <summary>
        /// current country
        /// </summary>
        public string Country
        {
            get { return _Country; }
            set { _Country = value; }
        }

        private string _Client = string.Empty;
        /// <summary>
        /// current client 
        /// </summary>
        public string Client
        {
            get { return _Client; }
            set { _Client = value; }
        }
    }

    /// <summary>
    /// Records per day
    /// </summary>
    public class RecsPerDia {
        private List<RecPerDia> _Datos = new List<RecPerDia>();
        /// <summary>
        /// List all data per day
        /// </summary>
        public List<RecPerDia> Datos {
            get { return _Datos; }
            set { _Datos = value; }
        }

        /// <summary>
        /// Contructor
        /// </summary>
        public RecsPerDia() { }

        /// <summary>
        /// Retrive records per day
        /// </summary>
        /// <param name="Datos">Data</param>
        public RecsPerDia(DataTable Datos) {
            _Datos.Clear();
            for (int a = 0; a < Datos.Rows.Count; a++) {
                _Datos.Add(new RecPerDia(Convert.ToInt32(Datos.Rows[a]["Id"]),
                                         Convert.ToInt32(Datos.Rows[a]["Valor"]),
                                         Convert.ToDateTime(Datos.Rows[a]["Fecha"]),
                                         Convert.ToInt32(Datos.Rows[a]["Usuario"])));
            }
        }
    }

    
    /// <summary>
    /// Specific object for records
    /// </summary>
    public class RecPerDia {
        private int _Id = int.MinValue;
        /// <summary>
        /// Id for the record
        /// </summary>
        public int Id {
            get { return _Id; }
            set { _Id = value; }
        }

        private int _Valor = int.MinValue;
        /// <summary>
        /// Record value
        /// </summary>
        public int Valor {
            get { return _Valor; }
            set { _Valor = value; }
        }

        private DateTime _dtime = DateTime.MinValue;
        /// <summary>
        /// Record date
        /// </summary>
        public DateTime Fecha {
            get { return _dtime; }
            set { _dtime = value; }
        }

        private int _Usuario = int.MinValue;
        /// <summary>
        /// Record user
        /// </summary>
        public int Usuario {
            get { return _Usuario; }
            set { _Usuario = value; }
        }

        /// <summary>
        /// contructor
        /// </summary>
        public RecPerDia() { }

        /// <summary>
        /// overload contructor
        /// </summary>
        /// <param name="in_Id">Id</param>
        /// <param name="in_Value">Value</param>
        /// <param name="in_Fecha">Date</param>
        /// <param name="in_Usuario">User</param>
        public RecPerDia(int in_Id, int in_Value, DateTime in_Fecha, int in_Usuario) {
            _Id = in_Id;
            _Valor = in_Value;
            _dtime = in_Fecha;
            _Usuario = in_Usuario;
        }
    }

    /// <summary>
    /// Users list
    /// </summary>
    public class Usuarios {
        private List<Usuario> __Usuarios = new List<Usuario>();
        /// <summary>
        /// User list
        /// </summary>
        public List<Usuario> _Usuarios {
            get { return __Usuarios; }
        }

        /// <summary>
        /// retrive users data from database
        /// </summary>
        /// <param name="Datos">Datatable with user data</param>
        public Usuarios(DataTable Datos) {
            for (int a = 0; a < Datos.Rows.Count; a++) {
                __Usuarios.Add(new Usuario(Datos.Rows[a]));
            }
        }
    }

    /// <summary>
    /// Class user
    /// </summary>
    public class Usuario {

        private int _Id = int.MinValue;
        /// <summary>
        /// id
        /// </summary>
        public int Id {
            get { return _Id; }
            set { _Id = value; }
        }

        private string _Nombre = string.Empty;
        /// <summary>
        /// Name
        /// </summary>
        public string Nombre {
            get { return _Nombre; }
            set { _Nombre = value; }
        }

        private string _User = string.Empty;
        /// <summary>
        /// Username
        /// </summary>
        public string User {
            get { return _User; }
            set { _User = value; }
        }

        private string _Password = string.Empty;
        /// <summary>
        /// Password
        /// </summary>
        public string Password {
            get { return _Password; }
            set { _Password = value; }
        }

        private int _Admin = int.MinValue;
        /// <summary>
        /// Admin value 1 = true
        /// </summary>
        public int Admin {
            get { return _Admin; }
            set { _Admin = value; }
        }

        private int _Tipo = 0;
        /// <summary>
        /// User type
        /// </summary>
        public int Tipo {
            get { return _Tipo; }
            set { _Tipo = value; }
        }

        private string _TIAUser = string.Empty;
        /// <summary>
        /// TIA Username
        /// </summary>
        public string TIAUser {
            get { return _TIAUser; }
            set { _TIAUser = value; }
        }

        /// <summary>
        /// Contructor
        /// </summary>
        public Usuario() {
        }

        /// <summary>
        /// Contructor
        /// </summary>
        /// <param name="Datos"> Datatable containing all data</param>
        public Usuario(DataTable Datos) {
            if (Datos.Rows.Count == 1) {
                _Id = Convert.ToInt32(Datos.Rows[0]["Id"].ToString());
                _Nombre = Datos.Rows[0]["Nombre"].ToString();
                _User = Datos.Rows[0]["Usuario"].ToString();
                _Password = Datos.Rows[0]["Password"].ToString();
                _Admin = Convert.ToInt32(Datos.Rows[0]["Admin"].ToString());
                _Tipo = Convert.ToInt32(Datos.Rows[0]["Tipo"].ToString());
                _TIAUser = Datos.Rows[0]["Usrmx"].ToString();
            }
            Datos.Dispose();
        }

        /// <summary>
        /// Overload
        /// </summary>
        /// <param name="Datos">Datarow with single user data</param>
        public Usuario(DataRow Datos) {
            _Id = Convert.ToInt32(Datos["Id"].ToString());
            _Nombre = Datos["Nombre"].ToString();
            _User = Datos["Usuario"].ToString();
            _Password = Datos["Password"].ToString();
            _Admin = Convert.ToInt32(Datos["Admin"].ToString());
            _Tipo = Convert.ToInt32(Datos["Tipo"].ToString());
            _TIAUser = Datos["Usrmx"].ToString();
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="__Id">Id</param>
        /// <param name="__Nombre">name</param>
        /// <param name="__Usuario">User</param>
        /// <param name="__Password">Password</param>
        /// <param name="__Admin">Admin</param>
        public Usuario(int __Id, string __Nombre, string __Usuario, string __Password, int __Admin) {
            _Id = __Id;
            _Nombre = __Nombre;
            _User = __Usuario;
            _Password = __Password;
            _Admin = __Admin;
        }
    }

    /// <summary>
    /// Public class records
    /// </summary>
    public class Registros {
        private decimal _Accion = decimal.MinValue;
        public decimal Accion {
            get { return _Accion; }
            set { _Accion = value; }
        }

        private decimal _Tipo = decimal.MinValue;
        public decimal Tipo {
            get { return _Tipo; }
            set { _Tipo = value; }
        }

        private decimal _Usuario = decimal.MinValue;
        public decimal Usuario {
            get { return _Usuario; }
            set { _Usuario = value; }
        }

        private DateTime _Inicio = DateTime.MinValue;
        public DateTime Inicio {
            get { return _Inicio; }
            set { _Inicio = value; }
        }

        private DateTime _Final = DateTime.MinValue;
        public DateTime Final {
            get { return _Final; }
            set { _Final = value; }
        }

        private String _Descripcion = String.Empty;
        public String Descripcion {
            get { return _Descripcion; }
            set { _Descripcion = value; }
        }

        private int _ClaimNumber = int.MinValue;
        public int ClaimsNumber
        {
            get { return _ClaimNumber; }
            set { _ClaimNumber = value; }
        }

        private string _Document = string.Empty;
        public string Document
        {
            get { return _Document; }
            set { _Document = value; }
        }

        private string _Country = string.Empty;

        public string Country
        {
            get { return _Country; }
            set { _Country = value; }
        }

        private string _Client = string.Empty;

        public string Client
        {
            get { return _Client; }
            set { _Client = value; }
        }
        

        public Registros() { }

        public Registros(decimal __Accion, decimal __Tipo, decimal __Usuario, DateTime __Inicio, DateTime __Final, int __ClaimNumber) {
            _Accion = __Accion;
            _Tipo = __Tipo;
            _Usuario = __Usuario;
            _Inicio = __Inicio;
            _Final = __Final;
            _ClaimNumber = __ClaimNumber;
        }

        public void Clear() {
            _Accion = decimal.MinValue;
            _Tipo = decimal.MinValue;
            _Usuario = decimal.MinValue;
            _Inicio = DateTime.MinValue;
            _Final = DateTime.MinValue;
            _ClaimNumber = int.MinValue;
            _Document = string.Empty;
            _Country = string.Empty;
            _Client = string.Empty;
        }
    }

    public class Acciones {
        public List<Object[]> Datos = new List<object[]>();

        private int _Id = int.MinValue;
        public int Id {
            get { return _Id; }
            set { _Id = value; }
        }

        private string _Nombre = string.Empty;
        public string Nombre {
            get { return _Nombre; }
            set { _Nombre = value; }
        }

        private int _Tipo = int.MinValue;
        public int Tipo {
            get { return _Tipo; }
            set { _Tipo = value; }
        }

        private int _MaxElapsed = int.MinValue;
        public int MaxElapsed {
            get { return _MaxElapsed; }
            set { _MaxElapsed = value; }
        }

        public Acciones() { }

        public Acciones(DataTable dt) {
            for (int a = 0; a < dt.Rows.Count; a++) {
                Datos.Add(dt.Rows[a].ItemArray);
            }
            dt.Dispose();
        }

        public void Obtener(int Id) {
            foreach (object[] dato in Datos) {
                if (Convert.ToInt32(dato[0]) == Id) {
                    _Id = Convert.ToInt32(dato[0]);
                    _Nombre = dato[1].ToString();
                    _Tipo = Convert.ToInt32(dato[2]);
                    break;
                }
            }
        }

        public void Obtener(String Busqueda) {
            foreach (object[] dato in Datos) {
                if (dato[1].ToString().ToLower().Contains(Busqueda.ToLower())) {
                    _Id = Convert.ToInt32(dato[0]);
                    _Nombre = dato[1].ToString();
                    _Tipo = Convert.ToInt32(dato[2]);
                    break;
                }
            }
        }
    }

    public class Tipos {
        public List<Object[]> Datos = new List<object[]>();

        private int _Id = int.MinValue;
        public int Id {
            get { return _Id; }
            set { _Id = value; }
        }

        private String _Nombre = string.Empty;
        public String Nombre {
            get { return _Nombre; }
            set { _Nombre = value; }
        }

        public Tipos() { }

        public Tipos(DataTable dt) {
            for (int a = 0; a < dt.Rows.Count; a++) {
                Datos.Add(dt.Rows[a].ItemArray);
            }
            dt.Dispose();
        }

        public void Obtener(int Id) {
            foreach (object[] dato in Datos) {
                if (Convert.ToInt32(dato[0]) == Id) {
                    _Id = Convert.ToInt32(dato[0]);
                    _Nombre = dato[1].ToString();
                    break;
                }
            }
        }

        public void Obtener(String Busqueda) {
            foreach (object[] dato in Datos) {
                if (dato[1].ToString().Contains(Busqueda)) {
                    _Id = Convert.ToInt32(dato[0]);
                    _Nombre = dato[1].ToString();
                    break;
                }
            }
        }
    }
}
