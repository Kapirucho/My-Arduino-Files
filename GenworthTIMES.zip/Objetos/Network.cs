using System;
using System.Collections.Generic;
using System.Text;
using System.Net.NetworkInformation;

namespace Objetos.Network {
    public class Network {
        public static bool ServerAvailable() {
            bool salida = false;
            try {
                Ping pinger = new Ping();
                PingReply reply = pinger.Send("AP003ALEO");

                if (reply.Status == IPStatus.Success) {
                    salida = true;
                }
            } catch (Exception) {
                salida = false;
            }
            return salida;
        }
    }
}
