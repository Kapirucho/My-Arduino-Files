using System;
using System.Collections.Generic;
using System.Text;
using System.Net.NetworkInformation;

namespace Objetos.Network {
    /// <summary>
    /// Look for network server availability
    /// </summary>
    public class Network {
        /// <summary>
        /// Is server available
        /// </summary>
        /// <returns>return true if server is found</returns>
        public static bool ServerAvailable() {
            bool salida = false;
            try {
                Ping pinger = new Ping();
                PingReply reply = pinger.Send("AP003ALEO");

                if (reply.Status == IPStatus.Success) {
                    salida = true;
                }
            } catch (Exception) {
                salida = false;
            }
            return salida;
        }
    }
}
